/* =========================================================
   Lotería Binaria - utils.js

   Archivo de utilidades globales del proyecto.

   Objetivo:
   Centralizar funciones reutilizables para evitar repetir código
   en auth.js, cliente.js, vendedor.js, admin.js, sorteos.js,
   wallets.js y solicitudes.js.

   Importante:
   - No usa backend.
   - No usa frameworks JavaScript.
   - Usa fetch para cargar archivos JSON simulados.
   - Usa localStorage para simular sesión.
   ========================================================= */


/* =========================================================
   1. Objeto global del proyecto

   Se crea un objeto llamado LB para agrupar las funciones
   de Lotería Binaria y evitar contaminar demasiado el espacio global.
   ========================================================= */

const LB = {};


/* =========================================================
   2. Constantes generales
   ========================================================= */

LB.STORAGE_KEYS = {
  USUARIO_ACTUAL: "loteriaBinaria_usuarioActual",
  ROL_ACTIVO: "loteriaBinaria_rolActivo"
};

LB.RUTAS = {
  INDEX: "index.html",
  LOGIN: "login.html",
  REGISTRO: "registro.html",
  ELEGIR_ROL: "elegir-rol.html",
  CLIENTE: "cliente.html",
  VENDEDOR: "vendedor.html",
  ADMIN: "admin.html"
};


/* =========================================================
   3. Validación segura de elementos HTML

   Esta función evita errores cuando un elemento no existe
   en una página específica.
   ========================================================= */

LB.obtenerElemento = function (selector) {
  if (!selector || typeof selector !== "string") {
    return null;
  }

  return document.querySelector(selector);
};


LB.obtenerElementos = function (selector) {
  if (!selector || typeof selector !== "string") {
    return [];
  }

  return Array.from(document.querySelectorAll(selector));
};


/* =========================================================
   4. Ejecutar función solo si existe un elemento

   Útil cuando un archivo JS se carga en varias páginas,
   pero ciertos elementos solo existen en una.
   ========================================================= */

LB.siExiste = function (selector, callback) {
  const elemento = LB.obtenerElemento(selector);

  if (elemento && typeof callback === "function") {
    callback(elemento);
  }
};


/* =========================================================
   5. Detectar si la página actual está en /pages/

   Esto sirve para construir rutas correctas hacia data/,
   index.html u otras páginas.
   ========================================================= */

LB.estaEnPages = function () {
  return window.location.pathname.includes("/pages/");
};


/* =========================================================
   6. Obtener prefijo de ruta

   Desde index.html:
   - data/usuarios.json
   - pages/login.html

   Desde pages/login.html:
   - ../data/usuarios.json
   - login.html, cliente.html, etc.
   ========================================================= */

LB.obtenerPrefijoRuta = function () {
  return LB.estaEnPages() ? "../" : "";
};


/* =========================================================
   7. Construir ruta hacia archivos JSON
   ========================================================= */

LB.rutaData = function (nombreArchivo) {
  return `${LB.obtenerPrefijoRuta()}data/${nombreArchivo}`;
};


/* =========================================================
   8. Construir ruta hacia páginas

   Si estoy en index.html:
   LB.rutaPagina("login.html") devuelve "pages/login.html"

   Si estoy dentro de pages/:
   LB.rutaPagina("login.html") devuelve "login.html"
   ========================================================= */

LB.rutaPagina = function (nombrePagina) {
  if (!nombrePagina) {
    return "#";
  }

  return LB.estaEnPages() ? nombrePagina : `pages/${nombrePagina}`;
};


/* =========================================================
   9. Construir ruta hacia index.html
   ========================================================= */

LB.rutaInicio = function () {
  return LB.estaEnPages() ? "../index.html" : "index.html";
};


/* =========================================================
   10. Validar rutas básicas

   Esta función no comprueba archivos en servidor.
   Solo ayuda a evitar rutas vacías o mal formadas.
   ========================================================= */

LB.validarRuta = function (ruta) {
  if (!ruta || typeof ruta !== "string") {
    console.warn("Ruta inválida:", ruta);
    return false;
  }

  if (ruta.includes("//")) {
    console.warn("La ruta contiene doble slash:", ruta);
    return false;
  }

  return true;
};


/* =========================================================
   11. Cargar JSON con fetch

   Recibe el nombre del archivo dentro de data/.
   Ejemplo:
   LB.cargarJSON("usuarios.json")
   ========================================================= */

LB.cargarJSON = async function (nombreArchivo) {
  try {
    const ruta = LB.rutaData(nombreArchivo);

    if (!LB.validarRuta(ruta)) {
      return [];
    }

    const respuesta = await fetch(ruta);

    if (!respuesta.ok) {
      throw new Error(`No se pudo cargar ${ruta}. Estado: ${respuesta.status}`);
    }

    const datos = await respuesta.json();
    return datos;
  } catch (error) {
    console.error("Error al cargar JSON:", error);
    return [];
  }
};


/* =========================================================
   12. Formatear moneda

   Usa formato USD porque el proyecto maneja dólares.
   ========================================================= */

LB.formatearMoneda = function (valor) {
  const numero = Number(valor);

  if (Number.isNaN(numero)) {
    return "$0.00";
  }

  return new Intl.NumberFormat("es-EC", {
    style: "currency",
    currency: "USD"
  }).format(numero);
};


/* =========================================================
   13. Formatear fecha y hora

   Convierte fechas ISO como:
   2026-06-19T12:00:00

   En una fecha legible para la interfaz.
   ========================================================= */

LB.formatearFecha = function (fechaISO) {
  if (!fechaISO) {
    return "Sin fecha";
  }

  const fecha = new Date(fechaISO);

  if (Number.isNaN(fecha.getTime())) {
    return "Fecha inválida";
  }

  return new Intl.DateTimeFormat("es-EC", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).format(fecha);
};


LB.formatearFechaHora = function (fechaISO) {
  if (!fechaISO) {
    return "Sin fecha";
  }

  const fecha = new Date(fechaISO);

  if (Number.isNaN(fecha.getTime())) {
    return "Fecha inválida";
  }

  return new Intl.DateTimeFormat("es-EC", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit"
  }).format(fecha);
};


/* =========================================================
   14. Obtener usuario actual desde localStorage
   ========================================================= */

LB.obtenerUsuarioActual = function () {
  try {
    const usuarioJSON = localStorage.getItem(LB.STORAGE_KEYS.USUARIO_ACTUAL);

    if (!usuarioJSON) {
      return null;
    }

    return JSON.parse(usuarioJSON);
  } catch (error) {
    console.error("Error al obtener usuario actual:", error);
    return null;
  }
};


/* =========================================================
   15. Guardar usuario actual en localStorage
   ========================================================= */

LB.guardarUsuarioActual = function (usuario) {
  if (!usuario || typeof usuario !== "object") {
    console.warn("No se puede guardar un usuario inválido.");
    return false;
  }

  localStorage.setItem(
    LB.STORAGE_KEYS.USUARIO_ACTUAL,
    JSON.stringify(usuario)
  );

  return true;
};


/* =========================================================
   16. Guardar y obtener rol activo

   Sirve para usuarios con múltiples roles:
   - Vendedor + Cliente financiero
   - Admin + Vendedor + Cliente financiero
   ========================================================= */

LB.guardarRolActivo = function (rol) {
  if (!rol) {
    return false;
  }

  localStorage.setItem(LB.STORAGE_KEYS.ROL_ACTIVO, rol);
  return true;
};


LB.obtenerRolActivo = function () {
  return localStorage.getItem(LB.STORAGE_KEYS.ROL_ACTIVO);
};


/* =========================================================
   17. Cerrar sesión

   Limpia la sesión simulada y redirige al inicio.
   ========================================================= */

LB.cerrarSesion = function () {
  localStorage.removeItem(LB.STORAGE_KEYS.USUARIO_ACTUAL);
  localStorage.removeItem(LB.STORAGE_KEYS.ROL_ACTIVO);

  window.location.href = LB.rutaInicio();
};


/* =========================================================
   18. Verificar si hay sesión activa
   ========================================================= */

LB.haySesionActiva = function () {
  return LB.obtenerUsuarioActual() !== null;
};


/* =========================================================
   19. Mostrar mensajes tipo alerta

   Puede usarse en contenedores como:
   <div id="mensaje"></div>

   Tipos sugeridos:
   - info
   - exito
   - error
   - advertencia
   ========================================================= */

LB.mostrarAlerta = function (selectorContenedor, mensaje, tipo = "info") {
  const contenedor = LB.obtenerElemento(selectorContenedor);

  if (!contenedor) {
    console.warn(`No existe el contenedor de alerta: ${selectorContenedor}`);
    return;
  }

  const clasesPermitidas = {
    info: "alerta alerta-info",
    exito: "alerta alerta-exito",
    error: "alerta alerta-error",
    advertencia: "alerta alerta-advertencia"
  };

  const clase = clasesPermitidas[tipo] || clasesPermitidas.info;

  contenedor.innerHTML = `
    <div class="${clase}" role="alert">
      ${LB.escaparHTML(mensaje)}
    </div>
  `;
};


/* =========================================================
   20. Limpiar mensaje de alerta
   ========================================================= */

LB.limpiarAlerta = function (selectorContenedor) {
  const contenedor = LB.obtenerElemento(selectorContenedor);

  if (contenedor) {
    contenedor.innerHTML = "";
  }
};


/* =========================================================
   21. Escapar HTML

   Evita que textos externos o simulados inserten etiquetas HTML
   no deseadas dentro de la página.
   ========================================================= */

LB.escaparHTML = function (texto) {
  if (texto === null || texto === undefined) {
    return "";
  }

  return String(texto)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
};


/* =========================================================
   22. Crear badge de estado

   Devuelve un string HTML.
   Se apoya en las clases definidas en styles.css.
   ========================================================= */

LB.crearBadgeEstado = function (estado) {
  if (!estado) {
    return `<span class="badge badge-info">Sin estado</span>`;
  }

  const estadoNormalizado = String(estado)
    .trim()
    .toUpperCase()
    .replaceAll(" ", "_");

  const mapaClases = {
    ACTIVO: "badge-activo",
    INACTIVO: "badge-inactivo",

    PENDIENTE: "badge-pendiente",
    EN_PROCESO: "badge-en-proceso",
    COMPLETADA: "badge-completada",
    COMPLETADO: "badge-completada",
    CANCELADA: "badge-cancelada",
    CANCELADO: "badge-cancelada",
    EXPIRADA: "badge-expirada",

    PROXIMO: "badge-proximo",
    CERRADO: "badge-cerrado",
    FINALIZADO: "badge-finalizado",

    PREMIADO: "badge-premiado",
    RECLAMADO: "badge-reclamado",
    PERDIDO: "badge-perdido",

    AUN_NO_PASA_EL_SORTEO: "badge-pendiente",
    SORTEO_CERRADO_ESPERANDO_RESULTADO: "badge-en-proceso",
    PREMIO_MAYOR: "badge-premiado",
    PREMIO_SECUNDARIO: "badge-premiado",
    NO_GANADOR: "badge-perdido"
  };

  const claseEstado = mapaClases[estadoNormalizado] || "badge-info";
  const texto = estadoNormalizado.replaceAll("_", " ");

  return `<span class="badge ${claseEstado}">${LB.escaparHTML(texto)}</span>`;
};


/* =========================================================
   23. Renderizar contenido HTML de forma segura

   Verifica si el contenedor existe antes de insertar.
   ========================================================= */

LB.renderizarHTML = function (selectorContenedor, html) {
  const contenedor = LB.obtenerElemento(selectorContenedor);

  if (!contenedor) {
    return false;
  }

  contenedor.innerHTML = html;
  return true;
};


/* =========================================================
   24. Agregar contenido HTML sin borrar lo anterior
   ========================================================= */

LB.agregarHTML = function (selectorContenedor, html) {
  const contenedor = LB.obtenerElemento(selectorContenedor);

  if (!contenedor) {
    return false;
  }

  contenedor.insertAdjacentHTML("beforeend", html);
  return true;
};


/* =========================================================
   25. Renderizar componente de carga
   ========================================================= */

LB.renderizarCargando = function (selectorContenedor, mensaje = "Cargando datos...") {
  return LB.renderizarHTML(
    selectorContenedor,
    `
      <div class="alerta alerta-info">
        ${LB.escaparHTML(mensaje)}
      </div>
    `
  );
};


/* =========================================================
   26. Renderizar componente cuando no hay datos
   ========================================================= */

LB.renderizarSinDatos = function (selectorContenedor, mensaje = "No hay datos disponibles.") {
  return LB.renderizarHTML(
    selectorContenedor,
    `
      <div class="alerta alerta-advertencia">
        ${LB.escaparHTML(mensaje)}
      </div>
    `
  );
};


/* =========================================================
   27. Renderizar tarjeta común

   Recibe un objeto con título, descripción, badge y enlace opcional.
   ========================================================= */

LB.crearTarjeta = function (opciones) {
  const config = {
    titulo: "Título",
    descripcion: "Descripción no disponible.",
    badge: "",
    enlace: "",
    textoEnlace: "Ver detalle",
    extraHTML: "",
    ...opciones
  };

  return `
    <article class="tarjeta">
      ${config.badge ? config.badge : ""}
      <h3>${LB.escaparHTML(config.titulo)}</h3>
      <p>${LB.escaparHTML(config.descripcion)}</p>
      ${config.extraHTML || ""}
      ${
        config.enlace
          ? `<a href="${LB.escaparHTML(config.enlace)}">${LB.escaparHTML(config.textoEnlace)}</a>`
          : ""
      }
    </article>
  `;
};


/* =========================================================
   28. Renderizar tabla común

   columnas:
   [
     { clave: "nombre", titulo: "Nombre" },
     { clave: "estado", titulo: "Estado", render: (valor, fila) => "..." }
   ]

   datos:
   [
     { nombre: "Ejemplo", estado: "ACTIVO" }
   ]
   ========================================================= */

LB.crearTabla = function (columnas, datos) {
  if (!Array.isArray(columnas) || !Array.isArray(datos)) {
    return `
      <div class="alerta alerta-error">
        No se pudo generar la tabla.
      </div>
    `;
  }

  if (datos.length === 0) {
    return `
      <div class="alerta alerta-advertencia">
        No hay registros para mostrar.
      </div>
    `;
  }

  const encabezados = columnas
    .map((columna) => `<th>${LB.escaparHTML(columna.titulo)}</th>`)
    .join("");

  const filas = datos
    .map((fila) => {
      const celdas = columnas
        .map((columna) => {
          const valor = fila[columna.clave];

          if (typeof columna.render === "function") {
            return `<td>${columna.render(valor, fila)}</td>`;
          }

          return `<td>${LB.escaparHTML(valor)}</td>`;
        })
        .join("");

      return `<tr>${celdas}</tr>`;
    })
    .join("");

  return `
    <div class="tabla-contenedor">
      <table>
        <thead>
          <tr>${encabezados}</tr>
        </thead>
        <tbody>
          ${filas}
        </tbody>
      </table>
    </div>
  `;
};


/* =========================================================
   29. Obtener parámetro de la URL

   Ejemplo:
   boleto-detalle.html?id=BOL-001

   LB.obtenerParametroURL("id") devuelve "BOL-001"
   ========================================================= */

LB.obtenerParametroURL = function (nombreParametro) {
  const parametros = new URLSearchParams(window.location.search);
  return parametros.get(nombreParametro);
};


/* =========================================================
   30. Redireccionar de forma segura
   ========================================================= */

LB.redireccionar = function (ruta) {
  if (!LB.validarRuta(ruta)) {
    return;
  }

  window.location.href = ruta;
};


/* =========================================================
   31. Proteger página simple

   Si no hay usuario en localStorage, manda al login.
   Esta función será útil en cliente.js, vendedor.js y admin.js.
   ========================================================= */

LB.protegerPagina = function () {
  if (!LB.haySesionActiva()) {
    LB.redireccionar(LB.rutaPagina("login.html"));
  }
};


/* =========================================================
   32. Verificar si el usuario tiene un rol específico
   ========================================================= */

LB.usuarioTieneRol = function (usuario, rol) {
  if (!usuario || !Array.isArray(usuario.roles)) {
    return false;
  }

  return usuario.roles.includes(rol);
};


/* =========================================================
   33. Crear saludo de usuario

   Renderiza un pequeño bloque con el usuario actual.
   ========================================================= */

LB.renderizarUsuarioActual = function (selectorContenedor) {
  const usuario = LB.obtenerUsuarioActual();

  if (!usuario) {
    return LB.renderizarHTML(
      selectorContenedor,
      `
        <div class="alerta alerta-advertencia">
          No hay usuario autenticado.
        </div>
      `
    );
  }

  return LB.renderizarHTML(
    selectorContenedor,
    `
      <div class="tarjeta">
        <h3>Usuario actual</h3>
        <p><strong>Nombre:</strong> ${LB.escaparHTML(usuario.nombres)} ${LB.escaparHTML(usuario.apellidos)}</p>
        <p><strong>Rol principal:</strong> ${LB.escaparHTML(usuario.rolPrincipal)}</p>
        <p><strong>Estado:</strong> ${LB.crearBadgeEstado(usuario.estado)}</p>
      </div>
    `
  );
};


/* =========================================================
   34. Crear botón de cierre de sesión

   Puede insertarse en headers, paneles o dashboards.
   ========================================================= */

LB.crearBotonCerrarSesion = function () {
  return `
    <button type="button" class="btn-peligro" data-accion="cerrar-sesion">
      Cerrar sesión
    </button>
  `;
};


/* =========================================================
   35. Activar botones comunes por data-accion
   ========================================================= */

LB.activarAccionesGlobales = function () {
  document.addEventListener("click", function (evento) {
    const botonCerrarSesion = evento.target.closest('[data-accion="cerrar-sesion"]');

    if (botonCerrarSesion) {
      LB.cerrarSesion();
    }
  });
};