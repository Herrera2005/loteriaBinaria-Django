/* =========================================================
   Lotería Binaria - wallets.js

   Objetivo:
   Centralizar funciones de wallet para clientes, vendedores
   y administrador dentro del frontend demostrativo.

   Este archivo permite:
   - Obtener wallets.
   - Consultar saldos.
   - Acreditar dinero real con tarjeta y comisión 5%.
   - Convertir real a virtual.
   - Convertir virtual a real con comisión 15%.
   - Comprar saldo virtual de vendedor con regla 0.90.
   - Enviar dinero entre clientes.
   - Registrar movimientos.
   - Validar saldos.
   - Evitar transferencias inválidas.
   - Guardar cambios simulados en localStorage.

   Importante:
   - No usa backend.
   - No modifica archivos JSON reales.
   - No mezcla usuarios, wallets y movimientos en un solo archivo.
   - Los datos se cargan desde archivos separados:
     data/usuarios.json
     data/wallets.json
     data/movimientos.json
   ========================================================= */


/* =========================================================
   1. Validación de dependencia

   Este archivo necesita utils.js porque usa:
   - LB.cargarJSON()
   - LB.formatearMoneda()
   - LB.escaparHTML()
   ========================================================= */

if (typeof LB === "undefined") {
  console.error("wallets.js necesita que utils.js se cargue primero.");
}


/* =========================================================
   2. Módulo global LBWallets

   Se usa una IIFE para encapsular variables internas y exponer
   solo las funciones necesarias.
   ========================================================= */

const LBWallets = (function () {

  /* =======================================================
     2.1 Estado interno del módulo
     ======================================================= */

  const estado = {
    usuarios: [],
    wallets: [],
    movimientos: [],
    cargado: false
  };


  /* =======================================================
     2.2 Claves de localStorage

     Se usan las mismas claves que cliente.js, vendedor.js
     y admin.js para mantener conectada la simulación.
     ======================================================= */

  const STORAGE = {
    USUARIOS: "loteriaBinaria_usuariosDemo",
    WALLETS: "loteriaBinaria_walletsDemo",
    MOVIMIENTOS: "loteriaBinaria_movimientosDemo"
  };


  /* =======================================================
     3. Inicializar módulo

     Carga usuarios, wallets y movimientos desde JSON.
     Si ya existen cambios simulados en localStorage,
     usa esos datos.
     ======================================================= */

  async function inicializar() {
    if (estado.cargado) {
      return true;
    }

    const usuariosJSON = await LB.cargarJSON("usuarios.json");
    const walletsJSON = await LB.cargarJSON("wallets.json");
    const movimientosJSON = await LB.cargarJSON("movimientos.json");

    estado.usuarios = obtenerDatosPersistidos(STORAGE.USUARIOS, usuariosJSON);
    estado.wallets = obtenerDatosPersistidos(STORAGE.WALLETS, walletsJSON);
    estado.movimientos = obtenerDatosPersistidos(STORAGE.MOVIMIENTOS, movimientosJSON);

    estado.cargado = true;

    return true;
  }


  /* =======================================================
     4. Obtener datos persistidos

     Mantiene separados:
     - usuarios
     - wallets
     - movimientos
     ======================================================= */

  function obtenerDatosPersistidos(clave, datosIniciales) {
    try {
      const datosGuardados = localStorage.getItem(clave);

      if (datosGuardados) {
        return JSON.parse(datosGuardados);
      }

      localStorage.setItem(clave, JSON.stringify(datosIniciales));
      return datosIniciales;
    } catch (error) {
      console.error("Error al leer localStorage:", error);
      return datosIniciales;
    }
  }


  /* =======================================================
     5. Guardar cambios simulados
     ======================================================= */

  function guardarCambios() {
    localStorage.setItem(STORAGE.USUARIOS, JSON.stringify(estado.usuarios));
    localStorage.setItem(STORAGE.WALLETS, JSON.stringify(estado.wallets));
    localStorage.setItem(STORAGE.MOVIMIENTOS, JSON.stringify(estado.movimientos));
  }


  /* =======================================================
     6. Obtener usuario por ID
     ======================================================= */

  function obtenerUsuario(usuarioId) {
    return estado.usuarios.find(function (usuario) {
      return usuario.id === usuarioId;
    }) || null;
  }


  /* =======================================================
     7. Obtener wallet de usuario

     Si no existe, se puede crear automáticamente.
     Esto sirve para la demo cuando un usuario no tiene wallet
     registrada en wallets.json.
     ======================================================= */

  function obtenerWalletUsuario(usuarioId, crearSiNoExiste = true) {
    let wallet = estado.wallets.find(function (item) {
      return item.usuarioId === usuarioId;
    });

    if (!wallet && crearSiNoExiste) {
      const usuario = obtenerUsuario(usuarioId);

      wallet = {
        id: generarId("WAL"),
        usuarioId: usuarioId,
        tipoUsuario: usuario ? usuario.rolPrincipal : "CLIENTE",
        saldoReal: 0,
        saldoVirtual: 0,
        saldoRealReservado: 0,
        saldoVirtualReservado: 0,
        gananciasGeneradas: 0,
        moneda: "USD",
        estado: "ACTIVA",
        ultimaActualizacion: new Date().toISOString()
      };

      estado.wallets.push(wallet);
      guardarCambios();
    }

    return wallet || null;
  }


  /* =======================================================
     8. Obtener saldo real
     ======================================================= */

  function obtenerSaldoReal(usuarioId) {
    const wallet = obtenerWalletUsuario(usuarioId, false);
    return wallet ? Number(wallet.saldoReal || 0) : 0;
  }


  /* =======================================================
     9. Obtener saldo virtual
     ======================================================= */

  function obtenerSaldoVirtual(usuarioId) {
    const wallet = obtenerWalletUsuario(usuarioId, false);
    return wallet ? Number(wallet.saldoVirtual || 0) : 0;
  }


  /* =======================================================
     10. Mostrar saldo real

     Devuelve HTML para usar en tarjetas o paneles.
     ======================================================= */

  function crearVistaSaldoReal(usuarioId) {
    const saldo = obtenerSaldoReal(usuarioId);

    return `
      <article class="resumen-card">
        <span>Saldo real</span>
        <strong>${LB.formatearMoneda(saldo)}</strong>
        <p>Dinero respaldado por pago o conversión.</p>
      </article>
    `;
  }


  /* =======================================================
     11. Mostrar saldo virtual

     Devuelve HTML para usar en tarjetas o paneles.
     ======================================================= */

  function crearVistaSaldoVirtual(usuarioId) {
    const saldo = obtenerSaldoVirtual(usuarioId);

    return `
      <article class="resumen-card">
        <span>Saldo virtual</span>
        <strong>${LB.formatearMoneda(saldo)}</strong>
        <p>Dinero usado para sorteos, solicitudes o transferencias.</p>
      </article>
    `;
  }


  /* =======================================================
     12. Validar saldo suficiente
     ======================================================= */

  function validarSaldoSuficiente(usuarioId, tipoSaldo, monto) {
    const wallet = obtenerWalletUsuario(usuarioId, false);

    if (!wallet) {
      return {
        ok: false,
        mensaje: "No se encontró la wallet del usuario."
      };
    }

    const montoNumerico = normalizarMonto(monto);

    if (montoNumerico <= 0) {
      return {
        ok: false,
        mensaje: "El monto debe ser mayor a cero."
      };
    }

    if (tipoSaldo === "REAL" && Number(wallet.saldoReal || 0) < montoNumerico) {
      return {
        ok: false,
        mensaje: "Saldo real insuficiente."
      };
    }

    if (tipoSaldo === "VIRTUAL" && Number(wallet.saldoVirtual || 0) < montoNumerico) {
      return {
        ok: false,
        mensaje: "Saldo virtual insuficiente."
      };
    }

    return {
      ok: true,
      mensaje: "Saldo suficiente."
    };
  }


  /* =======================================================
     13. Acreditar saldo real con tarjeta

     Regla:
     - Comisión 5%.
     - Si paga 100, comisión 5, saldo real acreditado 95.
     ======================================================= */

  function acreditarSaldoRealTarjeta(usuarioId, montoPagado) {
    const wallet = obtenerWalletUsuario(usuarioId, true);
    const monto = normalizarMonto(montoPagado);

    if (monto <= 0) {
      return respuesta(false, "Ingrese un monto válido para acreditar.");
    }

    const comision = redondearDinero(monto * 0.05);
    const montoNeto = redondearDinero(monto - comision);

    wallet.saldoReal = redondearDinero(Number(wallet.saldoReal || 0) + montoNeto);
    wallet.ultimaActualizacion = new Date().toISOString();

    registrarMovimiento({
      usuarioId: usuarioId,
      walletId: wallet.id,
      tipoMovimiento: "ACREDITACION_TARJETA",
      tipoDinero: "REAL",
      monto: monto,
      comision: comision,
      montoNeto: montoNeto,
      descripcion: "Acreditación simulada con tarjeta. Comisión del 5%.",
      estado: "COMPLETADO",
      referenciaId: null
    });

    guardarCambios();

    return respuesta(
      true,
      `Acreditación realizada. Comisión: ${LB.formatearMoneda(comision)}. Saldo real acreditado: ${LB.formatearMoneda(montoNeto)}.`,
      {
        montoPagado: monto,
        comision: comision,
        montoNeto: montoNeto,
        wallet: wallet
      }
    );
  }


  /* =======================================================
     14. Convertir dinero real a virtual

     Regla:
     - Conversión 1 a 1.
     - 100 real = 100 virtual.
     ======================================================= */

  function convertirRealAVirtual(usuarioId, montoConvertir) {
    const wallet = obtenerWalletUsuario(usuarioId, true);
    const monto = normalizarMonto(montoConvertir);

    const validacion = validarSaldoSuficiente(usuarioId, "REAL", monto);

    if (!validacion.ok) {
      return respuesta(false, validacion.mensaje);
    }

    wallet.saldoReal = redondearDinero(Number(wallet.saldoReal || 0) - monto);
    wallet.saldoVirtual = redondearDinero(Number(wallet.saldoVirtual || 0) + monto);
    wallet.ultimaActualizacion = new Date().toISOString();

    registrarMovimiento({
      usuarioId: usuarioId,
      walletId: wallet.id,
      tipoMovimiento: "CONVERSION_REAL_A_VIRTUAL",
      tipoDinero: "REAL_VIRTUAL",
      monto: monto,
      comision: 0,
      montoNeto: monto,
      descripcion: "Conversión de dinero real a dinero virtual con relación 1 a 1.",
      estado: "COMPLETADO",
      referenciaId: null
    });

    guardarCambios();

    return respuesta(
      true,
      `Conversión realizada: ${LB.formatearMoneda(monto)} real a virtual.`,
      {
        monto: monto,
        wallet: wallet
      }
    );
  }


  /* =======================================================
     15. Convertir virtual a real

     Regla:
     - Comisión 15%.
     - Si convierte 100 virtual, recibe 85 real.
     ======================================================= */

  function convertirVirtualAReal(usuarioId, montoConvertir) {
    const wallet = obtenerWalletUsuario(usuarioId, true);
    const monto = normalizarMonto(montoConvertir);

    const validacion = validarSaldoSuficiente(usuarioId, "VIRTUAL", monto);

    if (!validacion.ok) {
      return respuesta(false, validacion.mensaje);
    }

    const comision = redondearDinero(monto * 0.15);
    const montoNeto = redondearDinero(monto - comision);

    wallet.saldoVirtual = redondearDinero(Number(wallet.saldoVirtual || 0) - monto);
    wallet.saldoReal = redondearDinero(Number(wallet.saldoReal || 0) + montoNeto);
    wallet.ultimaActualizacion = new Date().toISOString();

    registrarMovimiento({
      usuarioId: usuarioId,
      walletId: wallet.id,
      tipoMovimiento: "CONVERSION_VIRTUAL_A_REAL",
      tipoDinero: "VIRTUAL_REAL",
      monto: monto,
      comision: comision,
      montoNeto: montoNeto,
      descripcion: "Conversión de dinero virtual a real con comisión antifraude del 15%.",
      estado: "COMPLETADO",
      referenciaId: null
    });

    guardarCambios();

    return respuesta(
      true,
      `Conversión realizada. Comisión: ${LB.formatearMoneda(comision)}. Recibes: ${LB.formatearMoneda(montoNeto)} reales.`,
      {
        monto: monto,
        comision: comision,
        montoNeto: montoNeto,
        wallet: wallet
      }
    );
  }


  /* =======================================================
     16. Comprar saldo virtual de vendedor

     Regla:
     - 1 dólar virtual cuesta 0.90 dólares reales.
     - Si compra 100 virtuales, paga 90 reales.
     - Ganancia potencial: 10.
     ======================================================= */

  function comprarSaldoVirtualVendedor(vendedorId, montoVirtualComprar) {
    const vendedor = obtenerUsuario(vendedorId);
    const wallet = obtenerWalletUsuario(vendedorId, true);
    const montoVirtual = normalizarMonto(montoVirtualComprar);

    if (!vendedor) {
      return respuesta(false, "No se encontró el vendedor.");
    }

    if (!usuarioTieneRol(vendedor, "VENDEDOR")) {
      return respuesta(false, "Solo un vendedor puede comprar saldo virtual con tarifa preferencial.");
    }

    if (montoVirtual <= 0) {
      return respuesta(false, "Ingrese un monto virtual válido.");
    }

    const costoReal = redondearDinero(montoVirtual * 0.90);
    const gananciaPotencial = redondearDinero(montoVirtual - costoReal);

    const validacion = validarSaldoSuficiente(vendedorId, "REAL", costoReal);

    if (!validacion.ok) {
      return respuesta(
        false,
        `Saldo real insuficiente. Necesitas ${LB.formatearMoneda(costoReal)} para comprar ${LB.formatearMoneda(montoVirtual)} virtuales.`
      );
    }

    wallet.saldoReal = redondearDinero(Number(wallet.saldoReal || 0) - costoReal);
    wallet.saldoVirtual = redondearDinero(Number(wallet.saldoVirtual || 0) + montoVirtual);
    wallet.gananciasGeneradas = redondearDinero(
      Number(wallet.gananciasGeneradas || 0) + gananciaPotencial
    );

    wallet.ultimaActualizacion = new Date().toISOString();

    registrarMovimiento({
      usuarioId: vendedorId,
      walletId: wallet.id,
      tipoMovimiento: "COMPRA_VIRTUAL_VENDEDOR",
      tipoDinero: "REAL_VIRTUAL",
      monto: montoVirtual,
      comision: 0,
      montoNeto: montoVirtual,
      costoRealVendedor: costoReal,
      gananciaPotencial: gananciaPotencial,
      descripcion: `Compra de saldo virtual de vendedor. Paga ${LB.formatearMoneda(costoReal)} real y recibe ${LB.formatearMoneda(montoVirtual)} virtual.`,
      estado: "COMPLETADO",
      referenciaId: null
    });

    guardarCambios();

    return respuesta(
      true,
      `Compra exitosa. Pagaste ${LB.formatearMoneda(costoReal)} reales y recibiste ${LB.formatearMoneda(montoVirtual)} virtuales.`,
      {
        montoVirtual: montoVirtual,
        costoReal: costoReal,
        gananciaPotencial: gananciaPotencial,
        wallet: wallet
      }
    );
  }


  /* =======================================================
     17. Enviar dinero entre clientes

     Reglas:
     - No puede enviarse a sí mismo.
     - El origen debe tener saldo virtual suficiente.
     - El destino debe ser cliente.
     - Si el destino es vendedor, no se permite salvo que se
       mande permitirEnvioAVendedor = true.
     ======================================================= */

  function enviarDineroEntreClientes(origenId, destinoId, montoEnviar, opciones = {}) {
    const permitirEnvioAVendedor = opciones.permitirEnvioAVendedor === true;

    const usuarioOrigen = obtenerUsuario(origenId);
    const usuarioDestino = obtenerUsuario(destinoId);

    const walletOrigen = obtenerWalletUsuario(origenId, true);
    const walletDestino = obtenerWalletUsuario(destinoId, true);

    const monto = normalizarMonto(montoEnviar);

    if (!usuarioOrigen) {
      return respuesta(false, "No se encontró el usuario origen.");
    }

    if (!usuarioDestino) {
      return respuesta(false, "No se encontró el usuario destino.");
    }

    if (origenId === destinoId) {
      return respuesta(false, "No se permite transferirse dinero a sí mismo.");
    }

    if (monto <= 0) {
      return respuesta(false, "Ingrese un monto válido para enviar.");
    }

    if (!usuarioTieneRol(usuarioOrigen, "CLIENTE") && !usuarioTieneRol(usuarioOrigen, "VENDEDOR")) {
      return respuesta(false, "El usuario origen no tiene permisos financieros para enviar dinero.");
    }

    if (!usuarioTieneRol(usuarioDestino, "CLIENTE")) {
      return respuesta(false, "Solo se permite enviar dinero a clientes.");
    }

    if (usuarioTieneRol(usuarioDestino, "VENDEDOR") && !permitirEnvioAVendedor) {
      return respuesta(false, "No se permite enviar dinero a un vendedor desde esta operación.");
    }

    const validacion = validarSaldoSuficiente(origenId, "VIRTUAL", monto);

    if (!validacion.ok) {
      return respuesta(false, validacion.mensaje);
    }

    walletOrigen.saldoVirtual = redondearDinero(Number(walletOrigen.saldoVirtual || 0) - monto);
    walletDestino.saldoVirtual = redondearDinero(Number(walletDestino.saldoVirtual || 0) + monto);

    walletOrigen.ultimaActualizacion = new Date().toISOString();
    walletDestino.ultimaActualizacion = new Date().toISOString();

    registrarMovimiento({
      usuarioId: origenId,
      walletId: walletOrigen.id,
      tipoMovimiento: "ENVIO_DINERO_VIRTUAL",
      tipoDinero: "VIRTUAL",
      monto: monto,
      comision: 0,
      montoNeto: monto,
      descripcion: `Envío de dinero virtual a ${usuarioDestino.usuario}.`,
      estado: "COMPLETADO",
      referenciaId: destinoId
    });

    registrarMovimiento({
      usuarioId: destinoId,
      walletId: walletDestino.id,
      tipoMovimiento: "RECEPCION_DINERO_VIRTUAL",
      tipoDinero: "VIRTUAL",
      monto: monto,
      comision: 0,
      montoNeto: monto,
      descripcion: `Recepción de dinero virtual desde ${usuarioOrigen.usuario}.`,
      estado: "COMPLETADO",
      referenciaId: origenId
    });

    guardarCambios();

    return respuesta(
      true,
      `Transferencia realizada correctamente por ${LB.formatearMoneda(monto)}.`,
      {
        monto: monto,
        walletOrigen: walletOrigen,
        walletDestino: walletDestino
      }
    );
  }


  /* =======================================================
     18. Registrar movimiento

     No mezcla datos: solo agrega registros al arreglo interno
     de movimientos y luego se guardan en localStorage.
     ======================================================= */

  function registrarMovimiento(datos) {
    const movimiento = {
      id: datos.id || generarId("MOV"),
      usuarioId: datos.usuarioId,
      walletId: datos.walletId,
      tipoMovimiento: datos.tipoMovimiento,
      tipoDinero: datos.tipoDinero,
      monto: redondearDinero(datos.monto || 0),
      comision: redondearDinero(datos.comision || 0),
      montoNeto: redondearDinero(datos.montoNeto || 0),
      descripcion: datos.descripcion || "Movimiento financiero simulado.",
      fecha: datos.fecha || new Date().toISOString(),
      estado: datos.estado || "COMPLETADO",
      referenciaId: datos.referenciaId || null
    };

    if (datos.costoRealVendedor !== undefined) {
      movimiento.costoRealVendedor = redondearDinero(datos.costoRealVendedor);
    }

    if (datos.gananciaPotencial !== undefined) {
      movimiento.gananciaPotencial = redondearDinero(datos.gananciaPotencial);
    }

    estado.movimientos.push(movimiento);

    return movimiento;
  }


  /* =======================================================
     19. Evitar que vendedor compre boletos

     Esta función puede usarse desde sorteos.js o cliente.js
     antes de permitir una compra.
     ======================================================= */

  function validarUsuarioPuedeComprarBoletos(usuarioId) {
    const usuario = obtenerUsuario(usuarioId);

    if (!usuario) {
      return respuesta(false, "No se encontró el usuario.");
    }

    const modo = String(localStorage.getItem("loteriaBinaria_modoAcceso") || "")
      .trim()
      .toUpperCase();

    if (modo !== "CLIENTE") {
      return respuesta(false, "Debes estar en modo cliente para comprar boletos.");
    }
    if (usuario.puedeComprarBoletos === false) {
      return respuesta(false, "Este usuario no tiene permiso para comprar boletos.");
    }

    return respuesta(true, "Usuario autorizado para comprar boletos.");
  }


  /* =======================================================
     20. Descontar boleto del saldo virtual

     Función útil para centralizar la compra de boletos
     desde cliente.js o sorteos.js.

     Esta función NO crea el boleto.
     Solo valida permisos, valida saldo y descuenta el precio.
     ======================================================= */

  function descontarPrecioBoleto(usuarioId, precioBoleto, referenciaId = null) {
    const permiso = validarUsuarioPuedeComprarBoletos(usuarioId);

    if (!permiso.ok) {
      return permiso;
    }

    const wallet = obtenerWalletUsuario(usuarioId, true);
    const precio = normalizarMonto(precioBoleto);

    const validacion = validarSaldoSuficiente(usuarioId, "VIRTUAL", precio);

    if (!validacion.ok) {
      return respuesta(false, validacion.mensaje);
    }

    wallet.saldoVirtual = redondearDinero(Number(wallet.saldoVirtual || 0) - precio);
    wallet.ultimaActualizacion = new Date().toISOString();

    registrarMovimiento({
      usuarioId: usuarioId,
      walletId: wallet.id,
      tipoMovimiento: "COMPRA_BOLETO",
      tipoDinero: "VIRTUAL",
      monto: precio,
      comision: 0,
      montoNeto: precio,
      descripcion: "Compra de boleto descontada del saldo virtual.",
      estado: "COMPLETADO",
      referenciaId: referenciaId
    });

    guardarCambios();

    return respuesta(
      true,
      `Compra procesada. Se descontó ${LB.formatearMoneda(precio)} del saldo virtual.`,
      {
        precio: precio,
        wallet: wallet
      }
    );
  }


  /* =======================================================
     21. Retirar dinero real

     Operación simulada.
     ======================================================= */

  function retirarDineroReal(usuarioId, montoRetirar) {
    const wallet = obtenerWalletUsuario(usuarioId, true);
    const monto = normalizarMonto(montoRetirar);

    const validacion = validarSaldoSuficiente(usuarioId, "REAL", monto);

    if (!validacion.ok) {
      return respuesta(false, validacion.mensaje);
    }

    wallet.saldoReal = redondearDinero(Number(wallet.saldoReal || 0) - monto);
    wallet.ultimaActualizacion = new Date().toISOString();

    registrarMovimiento({
      usuarioId: usuarioId,
      walletId: wallet.id,
      tipoMovimiento: "RETIRO_REAL",
      tipoDinero: "REAL",
      monto: monto,
      comision: 0,
      montoNeto: monto,
      descripcion: "Retiro simulado de dinero real.",
      estado: "COMPLETADO",
      referenciaId: null
    });

    guardarCambios();

    return respuesta(
      true,
      `Retiro simulado realizado por ${LB.formatearMoneda(monto)}.`,
      {
        monto: monto,
        wallet: wallet
      }
    );
  }


  /* =======================================================
     22. Obtener movimientos de un usuario
     ======================================================= */

  function obtenerMovimientosUsuario(usuarioId, tipoDinero = "TODOS") {
    let movimientos = estado.movimientos.filter(function (movimiento) {
      return movimiento.usuarioId === usuarioId;
    });

    if (tipoDinero !== "TODOS") {
      movimientos = movimientos.filter(function (movimiento) {
        return String(movimiento.tipoDinero).includes(tipoDinero);
      });
    }

    movimientos.sort(function (a, b) {
      return new Date(b.fecha) - new Date(a.fecha);
    });

    return movimientos;
  }


  /* =======================================================
     23. Obtener movimientos globales
     ======================================================= */

  function obtenerMovimientosGlobales(tipoDinero = "TODOS") {
    let movimientos = [...estado.movimientos];

    if (tipoDinero !== "TODOS") {
      movimientos = movimientos.filter(function (movimiento) {
        return String(movimiento.tipoDinero).includes(tipoDinero);
      });
    }

    movimientos.sort(function (a, b) {
      return new Date(b.fecha) - new Date(a.fecha);
    });

    return movimientos;
  }


  /* =======================================================
     24. Renderizar tabla simple de movimientos

     Usa LB.crearTabla() de utils.js.
     ======================================================= */

  function crearTablaMovimientos(movimientos) {
    return LB.crearTabla(
      [
        {
          clave: "fecha",
          titulo: "Fecha",
          render: function (valor) {
            return LB.formatearFechaHora(valor);
          }
        },
        {
          clave: "tipoMovimiento",
          titulo: "Movimiento",
          render: function (valor) {
            return LB.escaparHTML(String(valor).replaceAll("_", " "));
          }
        },
        {
          clave: "tipoDinero",
          titulo: "Tipo"
        },
        {
          clave: "monto",
          titulo: "Monto",
          render: function (valor) {
            return LB.formatearMoneda(valor);
          }
        },
        {
          clave: "comision",
          titulo: "Comisión",
          render: function (valor) {
            return LB.formatearMoneda(valor || 0);
          }
        },
        {
          clave: "montoNeto",
          titulo: "Neto",
          render: function (valor) {
            return LB.formatearMoneda(valor || 0);
          }
        },
        {
          clave: "estado",
          titulo: "Estado",
          render: function (valor) {
            return LB.crearBadgeEstado(valor);
          }
        }
      ],
      movimientos
    );
  }


  /* =======================================================
     25. Sincronizar datos desde localStorage

     Sirve cuando otra página modificó wallets o movimientos
     y esta página necesita recargar el estado sin hacer fetch.
     ======================================================= */

  function sincronizarDesdeLocalStorage() {
    estado.usuarios = obtenerDatosPersistidos(STORAGE.USUARIOS, estado.usuarios);
    estado.wallets = obtenerDatosPersistidos(STORAGE.WALLETS, estado.wallets);
    estado.movimientos = obtenerDatosPersistidos(STORAGE.MOVIMIENTOS, estado.movimientos);
  }


  /* =======================================================
     26. Obtener copias de datos

     Se devuelven copias para evitar que otros módulos alteren
     el estado interno sin pasar por funciones controladas.
     ======================================================= */

  function obtenerUsuarios() {
    return JSON.parse(JSON.stringify(estado.usuarios));
  }


  function obtenerWallets() {
    return JSON.parse(JSON.stringify(estado.wallets));
  }


  function obtenerMovimientos() {
    return JSON.parse(JSON.stringify(estado.movimientos));
  }


  /* =======================================================
     27. Utilidades internas
     ======================================================= */

  function usuarioTieneRol(usuario, rol) {
    return Array.isArray(usuario.roles) && usuario.roles.includes(rol);
  }


  function normalizarMonto(valor) {
    const numero = Number(valor);

    if (Number.isNaN(numero)) {
      return 0;
    }

    return redondearDinero(numero);
  }


  function redondearDinero(valor) {
    return Math.round(Number(valor) * 100) / 100;
  }


  function generarId(prefijo) {
    return `${prefijo}-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
  }


  function respuesta(ok, mensaje, datos = {}) {
    return {
      ok: ok,
      mensaje: mensaje,
      datos: datos
    };
  }


  /* =======================================================
     28. API pública del módulo

     Estas funciones pueden usarse desde:
     - cliente.js
     - vendedor.js
     - admin.js
     - sorteos.js
     - solicitudes.js
     ======================================================= */

  return {
    inicializar,
    guardarCambios,
    sincronizarDesdeLocalStorage,

    obtenerUsuario,
    obtenerUsuarios,
    obtenerWalletUsuario,
    obtenerWallets,
    obtenerMovimientos,

    obtenerSaldoReal,
    obtenerSaldoVirtual,
    crearVistaSaldoReal,
    crearVistaSaldoVirtual,

    acreditarSaldoRealTarjeta,
    convertirRealAVirtual,
    convertirVirtualAReal,
    comprarSaldoVirtualVendedor,
    enviarDineroEntreClientes,
    retirarDineroReal,

    registrarMovimiento,
    obtenerMovimientosUsuario,
    obtenerMovimientosGlobales,
    crearTablaMovimientos,

    validarSaldoSuficiente,
    validarUsuarioPuedeComprarBoletos,
    descontarPrecioBoleto
  };
})();