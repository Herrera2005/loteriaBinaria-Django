/* =========================================================
   Lotería Binaria - sorteos.js

   Archivo encargado de:
   - Mostrar detalle de sorteos/eventos.
   - Validar números Octales, Decimales y Hexadecimales.
   - Simular compra de boletos.
   - Descontar saldo virtual en localStorage.
   - Guardar boletos comprados en localStorage.
   - Mostrar detalle de boletos.

   Importante:
   - No usa backend.
   - No modifica archivos JSON.
   - Usa fetch para cargar datos separados.
   - Usa localStorage para persistencia demostrativa.
   ========================================================= */


/* =========================================================
   1. Validación de dependencia
   ========================================================= */

if (typeof LB === "undefined") {
  console.error("sorteos.js necesita que utils.js se cargue primero.");
}


/* =========================================================
   2. Estado global del módulo de sorteos
   ========================================================= */

const SorteosApp = {
  usuarioActual: null,
  rolActivo: null,
  modoAcceso: null,

  usuarios: [],
  sorteos: [],
  eventos: [],
  boletos: [],
  wallets: [],
  movimientos: [],

  sorteoActual: null,
  eventoActual: null,
  walletActual: null,

  intervaloTiempoRestante: null
};


/* =========================================================
   3. Claves de localStorage usadas por la demo

   Deben coincidir con las usadas en cliente.js para que
   los cambios se reflejen entre páginas.
   ========================================================= */

const SORTEOS_STORAGE = {
  WALLETS: "loteriaBinaria_walletsDemo",
  MOVIMIENTOS: "loteriaBinaria_movimientosDemo",
  BOLETOS: "loteriaBinaria_boletosDemo",
  ROL_ACTIVO: "loteriaBinaria_rolActivo",
  MODO_ACCESO: "loteriaBinaria_modoAcceso",
  SORTEOS: "loteriaBinaria_sorteosDemo",
  EVENTOS: "loteriaBinaria_eventosDemo"
};


/* =========================================================
   4. Inicialización automática
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {
  inicializarModuloSorteos();
});


async function inicializarModuloSorteos() {
  if (typeof LB === "undefined") {
    return;
  }

  SorteosApp.usuarioActual = LB.obtenerUsuarioActual();
  SorteosApp.rolActivo = localStorage.getItem(SORTEOS_STORAGE.ROL_ACTIVO);
  SorteosApp.modoAcceso = localStorage.getItem(SORTEOS_STORAGE.MODO_ACCESO);

  await cargarDatosSorteos();

  prepararWalletActual();

  if (document.querySelector("#detalleSorteo")) {
    inicializarPaginaDetalleSorteo();
  }

  if (document.querySelector("#detalleBoleto")) {
    inicializarPaginaDetalleBoleto();
  }
}


/* =========================================================
   5. Cargar datos desde archivos JSON separados
   ========================================================= */

async function cargarDatosSorteos() {
  const [
    usuariosJSON,
    sorteosJSON,
    eventosJSON,
    boletosJSON,
    walletsJSON,
    movimientosJSON
  ] = await Promise.all([
    LB.cargarJSON("usuarios.json"),
    LB.cargarJSON("sorteos.json"),
    LB.cargarJSON("eventos.json"),
    LB.cargarJSON("boletos.json"),
    LB.cargarJSON("wallets.json"),
    LB.cargarJSON("movimientos.json")
  ]);

  SorteosApp.usuarios = usuariosJSON;
  SorteosApp.sorteos = obtenerDatosPersistidos(
    SORTEOS_STORAGE.SORTEOS,
    sorteosJSON
  );

  SorteosApp.eventos = obtenerDatosPersistidos(
    SORTEOS_STORAGE.EVENTOS,
    eventosJSON
  );


  SorteosApp.boletos = obtenerDatosPersistidos(
    SORTEOS_STORAGE.BOLETOS,
    boletosJSON
  );

  SorteosApp.wallets = obtenerDatosPersistidos(
    SORTEOS_STORAGE.WALLETS,
    walletsJSON
  );

  SorteosApp.movimientos = obtenerDatosPersistidos(
    SORTEOS_STORAGE.MOVIMIENTOS,
    movimientosJSON
  );
}


/* =========================================================
   6. Obtener datos persistidos en localStorage
   ========================================================= */

function obtenerDatosPersistidos(clave, datosIniciales) {
  try {
    const datosGuardados = localStorage.getItem(clave);

    if (datosGuardados) {
      return JSON.parse(datosGuardados);
    }

    localStorage.setItem(clave, JSON.stringify(datosIniciales));
    return datosIniciales;
  } catch (error) {
    console.error("Error al leer localStorage:", error);
    return datosIniciales;
  }
}


/* =========================================================
   7. Guardar cambios simulados
   ========================================================= */

function guardarCambiosSorteos() {
  localStorage.setItem(SORTEOS_STORAGE.BOLETOS, JSON.stringify(SorteosApp.boletos));
  localStorage.setItem(SORTEOS_STORAGE.WALLETS, JSON.stringify(SorteosApp.wallets));
  localStorage.setItem(SORTEOS_STORAGE.MOVIMIENTOS, JSON.stringify(SorteosApp.movimientos));
}


/* =========================================================
   8. Preparar wallet del usuario actual
   ========================================================= */

function prepararWalletActual() {
  if (!SorteosApp.usuarioActual) {
    SorteosApp.walletActual = null;
    return;
  }

  SorteosApp.walletActual = SorteosApp.wallets.find(function (wallet) {
    return wallet.usuarioId === SorteosApp.usuarioActual.id;
  });

  if (!SorteosApp.walletActual) {
    SorteosApp.walletActual = {
      id: generarId("WAL"),
      usuarioId: SorteosApp.usuarioActual.id,
      tipoUsuario: SorteosApp.usuarioActual.rolPrincipal,
      saldoReal: 0,
      saldoVirtual: 0,
      saldoRealReservado: 0,
      saldoVirtualReservado: 0,
      gananciasGeneradas: 0,
      moneda: "USD",
      estado: "ACTIVA",
      ultimaActualizacion: new Date().toISOString()
    };

    SorteosApp.wallets.push(SorteosApp.walletActual);
    guardarCambiosSorteos();
  }
}


/* =========================================================
   9. Página: detalle de sorteo
   ========================================================= */

function inicializarPaginaDetalleSorteo() {
  const id = LB.obtenerParametroURL("id");

  resolverSorteoYEvento(id);

  if (!SorteosApp.sorteoActual || !SorteosApp.eventoActual) {
    LB.renderizarHTML(
      "#detalleSorteo",
      `
        <div class="alerta alerta-error">
          No se encontró el sorteo o evento solicitado.
        </div>
      `
    );

    deshabilitarFormularioCompra();
    return;
  }

  renderizarDetalleSorteo();
  renderizarReglasNumero();
  activarFormularioCompraSorteo();
  iniciarTiempoRestante();
}


/* =========================================================
   10. Resolver sorteo y evento desde parámetro URL

   Se aceptan dos casos:
   - id=EVE-001 para abrir un evento específico.
   - id=SOR-001 para buscar el próximo evento disponible
     de ese sorteo.
   ========================================================= */

function resolverSorteoYEvento(id) {
  if (!id) {
    SorteosApp.eventoActual = SorteosApp.eventos.find(function (evento) {
      return evento.estado === "PROXIMO";
    });

    if (SorteosApp.eventoActual) {
      SorteosApp.sorteoActual = SorteosApp.sorteos.find(function (sorteo) {
        return sorteo.id === SorteosApp.eventoActual.sorteoId;
      });
    }

    return;
  }

  const eventoPorId = SorteosApp.eventos.find(function (evento) {
    return evento.id === id;
  });

  if (eventoPorId) {
    SorteosApp.eventoActual = eventoPorId;
    SorteosApp.sorteoActual = SorteosApp.sorteos.find(function (sorteo) {
      return sorteo.id === eventoPorId.sorteoId;
    });
    return;
  }

  const sorteoPorId = SorteosApp.sorteos.find(function (sorteo) {
    return sorteo.id === id;
  });

  if (sorteoPorId) {
    SorteosApp.sorteoActual = sorteoPorId;

    SorteosApp.eventoActual = SorteosApp.eventos.find(function (evento) {
      return evento.sorteoId === sorteoPorId.id && evento.estado === "PROXIMO";
    });

    if (!SorteosApp.eventoActual) {
      SorteosApp.eventoActual = SorteosApp.eventos.find(function (evento) {
        return evento.sorteoId === sorteoPorId.id;
      });
    }
  }
}


/* =========================================================
   11. Renderizar detalle visual del sorteo
   ========================================================= */

function renderizarDetalleSorteo() {
  const sorteo = SorteosApp.sorteoActual;
  const evento = SorteosApp.eventoActual;
  const compraPermitida = puedeComprarEvento();

  const html = `
    <div class="grid-tarjetas">
      <article class="tarjeta">
        ${LB.crearBadgeEstado(evento.estado)}
        <h2>${LB.escaparHTML(evento.nombreEvento)}</h2>

        <p><strong>Nombre del sorteo:</strong> ${LB.escaparHTML(sorteo.nombre)}</p>
        <p><strong>Tipo:</strong> ${LB.escaparHTML(sorteo.tipo)}</p>
        <p><strong>Cantidad de dígitos:</strong> ${LB.escaparHTML(sorteo.digitos)}</p>
        <p><strong>Números permitidos:</strong> ${LB.escaparHTML(sorteo.numerosPermitidos)}</p>
      </article>

      <article class="tarjeta">
        <span class="badge badge-dorado">Premio</span>
        <h2>${LB.formatearMoneda(evento.premioActual)}</h2>

        <p><strong>Precio del boleto:</strong> ${LB.formatearMoneda(sorteo.precioBoleto)}</p>
        <p><strong>Premio base:</strong> ${LB.formatearMoneda(sorteo.premioBase)}</p>
        <p><strong>Acumulación:</strong> ${LB.escaparHTML(sorteo.porcentajeAcumulacion)}%</p>
      </article>

      <article class="tarjeta">
        <span class="badge badge-info">Fechas</span>
        <h2>Programación</h2>

        <p><strong>Fecha del sorteo:</strong> ${LB.formatearFechaHora(evento.fechaSorteo)}</p>
        <p><strong>Cierre de ventas:</strong> ${LB.formatearFechaHora(evento.fechaCierreVenta)}</p>
        <p><strong>Tiempo restante:</strong> <span id="tiempoRestanteSorteo">Calculando...</span></p>
      </article>

      <article class="tarjeta">
        <span class="badge ${compraPermitida ? "badge-premiado" : "badge-cancelada"}">
          ${compraPermitida ? "Compra disponible" : "Compra bloqueada"}
        </span>

        <h2>Estado de compra</h2>

        <p>
          ${
            compraPermitida
              ? "El evento está disponible para compra y aún no llega al cierre de ventas."
              : "No se puede comprar porque el evento está cerrado, finalizado o no disponible."
          }
        </p>

        <p>
          <strong>Saldo virtual actual:</strong>
          ${SorteosApp.walletActual ? LB.formatearMoneda(SorteosApp.walletActual.saldoVirtual) : "Sin sesión"}
        </p>
      </article>
    </div>
  `;

  LB.renderizarHTML("#detalleSorteo", html);

  if (!compraPermitida) {
    deshabilitarFormularioCompra();
  }
}


/* =========================================================
   12. Renderizar reglas del número según tipo
   ========================================================= */

function renderizarReglasNumero() {
  const sorteo = SorteosApp.sorteoActual;

  if (!sorteo) {
    return;
  }

  let regla = "";

  if (sorteo.tipo === "OCTAL") {
    regla = `Solo se aceptan ${sorteo.digitos} dígitos del 0 al 7.`;
  }

  if (sorteo.tipo === "DECIMAL") {
    regla = `Solo se aceptan ${sorteo.digitos} dígitos del 0 al 9.`;
  }

  if (sorteo.tipo === "HEXADECIMAL") {
    regla = `Se aceptan ${sorteo.digitos} caracteres: números del 0 al 9 y letras A, B, C, D, E, F.`;
  }

  LB.renderizarHTML(
    "#reglasNumero",
    `
      <div class="alerta alerta-info">
        ${LB.escaparHTML(regla)}
      </div>
    `
  );

  const input = document.querySelector("#numeroBoleto");

  if (input) {
    input.setAttribute("maxlength", sorteo.digitos);
    input.setAttribute("placeholder", obtenerPlaceholderPorTipo(sorteo.tipo, sorteo.digitos));

    input.addEventListener("input", function () {
      input.value = input.value.toUpperCase().trim();
    });
  }
}


/* =========================================================
   13. Placeholder según tipo de sorteo
   ========================================================= */

function obtenerPlaceholderPorTipo(tipo, digitos) {
  if (tipo === "OCTAL") {
    return "7".repeat(digitos);
  }

  if (tipo === "DECIMAL") {
    return "9".repeat(digitos);
  }

  if (tipo === "HEXADECIMAL") {
    return "A".repeat(digitos);
  }

  return "1234";
}


/* =========================================================
   14. Activar formulario de compra
   ========================================================= */

function activarFormularioCompraSorteo() {
  const form = document.querySelector("#formComprarSorteo");

  if (!form) {
    return;
  }

  form.addEventListener("submit", function (evento) {
    evento.preventDefault();

    const input = document.querySelector("#numeroBoleto");
    const numero = input ? input.value.trim().toUpperCase() : "";

    comprarBoletoDesdeDetalle(numero);
  });
}


/* =========================================================
   15. Comprar boleto desde detalle
   ========================================================= */

function comprarBoletoDesdeDetalle(numeroIngresado) {
  const sorteo = SorteosApp.sorteoActual;
  const evento = SorteosApp.eventoActual;

  if (!sorteo || !evento) {
    mostrarMensajeSorteo("No se pudo identificar el sorteo.", "error");
    return;
  }

  if (!SorteosApp.usuarioActual) {
    mostrarMensajeSorteo("Debe iniciar sesión para comprar boletos.", "advertencia");
    return;
  }

  if (!usuarioPuedeComprarBoletos()) {
    mostrarMensajeSorteo(
      "Tu rol o modo de acceso actual no permite comprar boletos.",
      "advertencia"
    );
    return;
  }

  if (!puedeComprarEvento()) {
    mostrarMensajeSorteo(
      "No se puede comprar porque el evento está cerrado o finalizado.",
      "error"
    );
    return;
  }

  const errores = validarNumeroBoleto(numeroIngresado, sorteo);

  if (errores.length > 0) {
    mostrarMensajeSorteo(errores.join(" "), "error");
    return;
  }

  if (!SorteosApp.walletActual) {
    mostrarMensajeSorteo("No se encontró la wallet del usuario.", "error");
    return;
  }

  if (SorteosApp.walletActual.saldoVirtual < sorteo.precioBoleto) {
    mostrarMensajeSorteo(
      `Saldo virtual insuficiente. Necesitas ${LB.formatearMoneda(sorteo.precioBoleto)}.`,
      "error"
    );
    return;
  }

  SorteosApp.walletActual.saldoVirtual = redondearDinero(
    SorteosApp.walletActual.saldoVirtual - sorteo.precioBoleto
  );

  SorteosApp.walletActual.ultimaActualizacion = new Date().toISOString();

  const nuevoBoleto = {
    id: generarId("BOL"),
    usuarioId: SorteosApp.usuarioActual.id,
    sorteoId: sorteo.id,
    eventoId: evento.id,
    numeroElegido: numeroIngresado,
    tipo: sorteo.tipo,
    precio: sorteo.precioBoleto,
    fechaCompra: new Date().toISOString(),
    estado: "PENDIENTE",
    resultado: "AUN_NO_PASA_EL_SORTEO",
    premioObtenido: 0,
    reclamado: false
  };

  SorteosApp.boletos.push(nuevoBoleto);

  agregarMovimientoCompra(nuevoBoleto, sorteo);

  guardarCambiosSorteos();

  renderizarDetalleSorteo();

  const form = document.querySelector("#formComprarSorteo");

  if (form) {
    form.reset();
  }

  mostrarMensajeSorteo(
    `Compra realizada correctamente. Boleto ${numeroIngresado} guardado en la demo.`,
    "exito"
  );
}


/* =========================================================
   16. Validar número de boleto
   ========================================================= */

function validarNumeroBoleto(numero, sorteo) {
  const errores = [];

  if (!numero) {
    errores.push("Debe ingresar un número de boleto.");
    return errores;
  }

  if (numero.length !== Number(sorteo.digitos)) {
    errores.push(`El boleto debe tener exactamente ${sorteo.digitos} caracteres.`);
  }

  if (sorteo.tipo === "OCTAL" && !/^[0-7]+$/.test(numero)) {
    errores.push("La lotería Octal solo acepta dígitos del 0 al 7.");
  }

  if (sorteo.tipo === "DECIMAL" && !/^[0-9]+$/.test(numero)) {
    errores.push("La lotería Decimal solo acepta dígitos del 0 al 9.");
  }

  if (sorteo.tipo === "HEXADECIMAL" && !/^[0-9A-F]+$/.test(numero)) {
    errores.push("La lotería Hexadecimal solo acepta números del 0 al 9 y letras A-F.");
  }

  return errores;
}


/* =========================================================
   17. Verificar si el evento permite compra
   ========================================================= */

function puedeComprarEvento() {
  const evento = SorteosApp.eventoActual;

  if (!evento) {
    return false;
  }

  const ahora = new Date();
  const cierre = new Date(evento.fechaCierreVenta);

  if (evento.estado !== "PROXIMO") {
    return false;
  }

  if (evento.disponibleCompra !== true) {
    return false;
  }

  if (Number.isNaN(cierre.getTime())) {
    return false;
  }

  return ahora < cierre;
}


/* =========================================================
   18. Validar si el usuario actual puede comprar boletos

   Regla actualizada:
   - Si el modo activo es CLIENTE, puede comprar boletos.
   - Esto permite que un usuario real VENDEDOR o ADMIN compre
     boletos solo cuando eligió entrar como CLIENTE.
   - Si está en modo VENDEDOR, ADMIN o PENDIENTE, no puede comprar.
   ========================================================= */

function usuarioPuedeComprarBoletos() {
  const usuario = SorteosApp.usuarioActual;

  if (!usuario) {
    return false;
  }

  const modoAcceso = localStorage.getItem("loteriaBinaria_modoAcceso");
  const rolActivo = localStorage.getItem("loteriaBinaria_rolActivo");

  const modo = String(modoAcceso || rolActivo || "")
    .trim()
    .toUpperCase();

  /*
    Nueva regla:
    La compra depende del modo elegido, no solo del rol real.
    Ejemplo:
    - vendedor_demo entrando como CLIENTE sí puede comprar.
    - admin_demo entrando como CLIENTE sí puede comprar.
    - vendedor_demo entrando como VENDEDOR no puede comprar.
    - admin_demo entrando como ADMIN no puede comprar.
  */
  if (modo === "CLIENTE") {
    return true;
  }

  return false;
}


/* =========================================================
   19. Deshabilitar formulario de compra
   ========================================================= */

function deshabilitarFormularioCompra() {
  const input = document.querySelector("#numeroBoleto");
  const boton = document.querySelector("#formComprarSorteo button[type='submit']");

  if (input) {
    input.disabled = true;
  }

  if (boton) {
    boton.disabled = true;
    boton.textContent = "Compra no disponible";
  }
}


/* =========================================================
   20. Agregar movimiento de compra
   ========================================================= */

function agregarMovimientoCompra(boleto, sorteo) {
  SorteosApp.movimientos.push({
    id: generarId("MOV"),
    usuarioId: SorteosApp.usuarioActual.id,
    walletId: SorteosApp.walletActual.id,
    tipoMovimiento: "COMPRA_BOLETO",
    tipoDinero: "VIRTUAL",
    monto: redondearDinero(sorteo.precioBoleto),
    comision: 0,
    montoNeto: redondearDinero(sorteo.precioBoleto),
    descripcion: `Compra de boleto ${boleto.numeroElegido} para ${sorteo.nombre}.`,
    fecha: new Date().toISOString(),
    estado: "COMPLETADO",
    referenciaId: boleto.id
  });
}


/* =========================================================
   21. Tiempo restante
   ========================================================= */

function iniciarTiempoRestante() {
  actualizarTiempoRestante();

  if (SorteosApp.intervaloTiempoRestante) {
    clearInterval(SorteosApp.intervaloTiempoRestante);
  }

  SorteosApp.intervaloTiempoRestante = setInterval(actualizarTiempoRestante, 1000);
}


function actualizarTiempoRestante() {
  const contenedor = document.querySelector("#tiempoRestanteSorteo");

  if (!contenedor || !SorteosApp.eventoActual) {
    return;
  }

  const ahora = new Date();
  const cierre = new Date(SorteosApp.eventoActual.fechaCierreVenta);
  const diferencia = cierre - ahora;

  if (diferencia <= 0) {
    contenedor.textContent = "Ventas cerradas";
    deshabilitarFormularioCompra();
    return;
  }

  const segundosTotales = Math.floor(diferencia / 1000);
  const dias = Math.floor(segundosTotales / 86400);
  const horas = Math.floor((segundosTotales % 86400) / 3600);
  const minutos = Math.floor((segundosTotales % 3600) / 60);
  const segundos = segundosTotales % 60;

  contenedor.textContent = `${dias}d ${horas}h ${minutos}m ${segundos}s`;
}


/* =========================================================
   22. Página: detalle de boleto
   ========================================================= */

function inicializarPaginaDetalleBoleto() {
  const id = LB.obtenerParametroURL("id");

  if (!id) {
    LB.renderizarHTML(
      "#detalleBoleto",
      `
        <div class="alerta alerta-error">
          No se recibió el identificador del boleto.
        </div>
      `
    );
    return;
  }

  const boleto = SorteosApp.boletos.find(function (item) {
    return item.id === id;
  });

  if (!boleto) {
    LB.renderizarHTML(
      "#detalleBoleto",
      `
        <div class="alerta alerta-error">
          No se encontró el boleto solicitado.
        </div>
      `
    );
    return;
  }

  renderizarDetalleBoleto(boleto);
  renderizarSorteoAsociadoBoleto(boleto);
}


/* =========================================================
   23. Renderizar detalle del boleto
   ========================================================= */

function renderizarDetalleBoleto(boleto) {
  const usuario = SorteosApp.usuarios.find(function (item) {
    return item.id === boleto.usuarioId;
  });

  const html = `
    <div class="grid-tarjetas">
      <article class="tarjeta">
        ${LB.crearBadgeEstado(obtenerEstadoVisualBoleto(boleto))}
        <h2>Boleto ${LB.escaparHTML(boleto.id)}</h2>

        <p class="numero-boleto">${LB.escaparHTML(boleto.numeroElegido)}</p>

        <p><strong>Tipo:</strong> ${LB.escaparHTML(boleto.tipo)}</p>
        <p><strong>Precio:</strong> ${LB.formatearMoneda(boleto.precio)}</p>
        <p><strong>Fecha de compra:</strong> ${LB.formatearFechaHora(boleto.fechaCompra)}</p>
      </article>

      <article class="tarjeta">
        <span class="badge badge-info">Resultado</span>
        <h2>Estado del boleto</h2>

        <p><strong>Estado:</strong> ${LB.crearBadgeEstado(boleto.estado)}</p>
        <p><strong>Resultado:</strong> ${LB.crearBadgeEstado(boleto.resultado)}</p>
        <p><strong>Premio obtenido:</strong> ${LB.formatearMoneda(boleto.premioObtenido || 0)}</p>
        <p><strong>Reclamado:</strong> ${boleto.reclamado ? "Sí" : "No"}</p>
      </article>

      <article class="tarjeta">
        <span class="badge badge-dorado">Cliente</span>
        <h2>Propietario</h2>

        <p><strong>Usuario:</strong> ${usuario ? LB.escaparHTML(usuario.usuario) : "No encontrado"}</p>
        <p><strong>Nombre:</strong> ${usuario ? `${LB.escaparHTML(usuario.nombres)} ${LB.escaparHTML(usuario.apellidos)}` : "No disponible"}</p>
        <p><strong>Correo:</strong> ${usuario ? LB.escaparHTML(usuario.correo) : "No disponible"}</p>
      </article>
    </div>
  `;

  LB.renderizarHTML("#detalleBoleto", html);
}


/* =========================================================
   24. Renderizar sorteo asociado al boleto
   ========================================================= */

function renderizarSorteoAsociadoBoleto(boleto) {
  const sorteo = SorteosApp.sorteos.find(function (item) {
    return item.id === boleto.sorteoId;
  });

  const evento = SorteosApp.eventos.find(function (item) {
    return item.id === boleto.eventoId;
  });

  if (!sorteo || !evento) {
    LB.renderizarHTML(
      "#detalleSorteoBoleto",
      `
        <div class="alerta alerta-advertencia">
          No se encontró información completa del sorteo asociado.
        </div>
      `
    );
    return;
  }

  const html = `
    <div class="grid-tarjetas">
      <article class="tarjeta">
        ${LB.crearBadgeEstado(evento.estado)}
        <h3>${LB.escaparHTML(evento.nombreEvento)}</h3>

        <p><strong>Sorteo:</strong> ${LB.escaparHTML(sorteo.nombre)}</p>
        <p><strong>Tipo:</strong> ${LB.escaparHTML(sorteo.tipo)}</p>
        <p><strong>Dígitos:</strong> ${LB.escaparHTML(sorteo.digitos)}</p>
        <p><strong>Números permitidos:</strong> ${LB.escaparHTML(sorteo.numerosPermitidos)}</p>
      </article>

      <article class="tarjeta">
        <span class="badge badge-dorado">Premio</span>
        <h3>Premio del evento</h3>

        <p><strong>Premio actual:</strong> ${LB.formatearMoneda(evento.premioActual)}</p>
        <p><strong>Precio del boleto:</strong> ${LB.formatearMoneda(sorteo.precioBoleto)}</p>
        <p><strong>Premio base:</strong> ${LB.formatearMoneda(sorteo.premioBase)}</p>
      </article>

      <article class="tarjeta">
        <span class="badge badge-info">Fechas</span>
        <h3>Programación</h3>

        <p><strong>Fecha del sorteo:</strong> ${LB.formatearFechaHora(evento.fechaSorteo)}</p>
        <p><strong>Cierre ventas:</strong> ${LB.formatearFechaHora(evento.fechaCierreVenta)}</p>
        <p><strong>Número ganador:</strong> ${evento.numeroGanador ? LB.escaparHTML(evento.numeroGanador) : "Pendiente"}</p>
      </article>
    </div>
  `;

  LB.renderizarHTML("#detalleSorteoBoleto", html);
}


/* =========================================================
   25. Estado visual normalizado para boleto
   ========================================================= */

function obtenerEstadoVisualBoleto(boleto) {
  if (boleto.estado === "RECLAMADO") {
    return "RECLAMADO";
  }

  if (boleto.estado === "PREMIADO") {
    return "PREMIADO";
  }

  if (boleto.estado === "PERDIDO") {
    return "PERDIDO";
  }

  if (boleto.resultado === "AUN_NO_PASA_EL_SORTEO") {
    return "AUN_NO_PASA_EL_SORTEO";
  }

  return boleto.estado || "PENDIENTE";
}


/* =========================================================
   26. Mensajes
   ========================================================= */

function mostrarMensajeSorteo(mensaje, tipo) {
  LB.mostrarAlerta("#mensajeSorteo", mensaje, tipo);

  window.scrollTo({
    top: 0,
    behavior: "smooth"
  });
}


/* =========================================================
   27. Utilidades internas
   ========================================================= */

function redondearDinero(valor) {
  return Math.round(Number(valor) * 100) / 100;
}


function generarId(prefijo) {
  return `${prefijo}-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
}