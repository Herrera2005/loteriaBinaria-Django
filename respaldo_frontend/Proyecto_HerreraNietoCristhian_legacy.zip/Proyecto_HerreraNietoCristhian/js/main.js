/* =========================================================
   Lotería Binaria - main.js

   Archivo principal del frontend.

   Objetivo:
   Ejecutar acciones comunes al cargar cualquier página:
   - Activar acciones globales.
   - Mostrar información básica de sesión si existe.
   - Marcar enlaces activos.
   - Preparar comportamiento general de componentes.
   - Evitar errores cuando un elemento no existe.
   ========================================================= */


/* =========================================================
   1. Esperar a que el DOM esté completamente cargado
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {
  inicializarLoteriaBinaria();
});


/* =========================================================
   2. Función principal de inicialización
   ========================================================= */

function inicializarLoteriaBinaria() {
  // Verifica que utils.js haya sido cargado antes de main.js.
  if (typeof LB === "undefined") {
    console.error("utils.js debe cargarse antes que main.js");
    return;
  }

  // Activa acciones comunes como cerrar sesión.
  LB.activarAccionesGlobales();

  // Marca visualmente el enlace correspondiente a la página actual.
  marcarEnlaceActivo();

  // Renderiza sesión si existe un contenedor preparado para eso.
  renderizarResumenSesion();

  // Renderiza botones comunes si existen contenedores específicos.
  renderizarAccionesSesion();

  // Inicializa elementos visuales comunes.
  inicializarComponentesComunes();

  // Mensaje de consola útil para presentación académica.
  console.log("Lotería Binaria inicializada correctamente.");
}


/* =========================================================
   3. Marcar enlace activo según la página actual

   Busca enlaces de navegación y agrega una clase al enlace
   que coincida con el archivo actual.
   ========================================================= */

function marcarEnlaceActivo() {
  const rutaActual = window.location.pathname;
  const archivoActual = rutaActual.substring(rutaActual.lastIndexOf("/") + 1) || "index.html";

  const enlaces = document.querySelectorAll("a[href]");

  enlaces.forEach(function (enlace) {
    const href = enlace.getAttribute("href");

    if (!href) {
      return;
    }

    const archivoHref = href.substring(href.lastIndexOf("/") + 1);

    if (archivoHref === archivoActual) {
      enlace.classList.add("link-activo");
    }
  });
}


/* =========================================================
   4. Renderizar resumen de sesión

   Para usarlo en HTML, basta con crear:
   <div id="resumenSesion"></div>

   Si el elemento no existe, no pasa nada.
   ========================================================= */

function renderizarResumenSesion() {
  const contenedor = document.querySelector("#resumenSesion");

  if (!contenedor) {
    return;
  }

  const usuario = LB.obtenerUsuarioActual();
  const rolActivo = LB.obtenerRolActivo();

  if (!usuario) {
    contenedor.innerHTML = `
      <div class="alerta alerta-info">
        No hay una sesión activa en este momento.
      </div>
    `;
    return;
  }

  contenedor.innerHTML = `
    <div class="tarjeta">
      <h3>Sesión activa</h3>
      <p>
        <strong>Usuario:</strong>
        ${LB.escaparHTML(usuario.nombres)} ${LB.escaparHTML(usuario.apellidos)}
      </p>
      <p>
        <strong>Rol principal:</strong>
        ${LB.escaparHTML(usuario.rolPrincipal)}
      </p>
      <p>
        <strong>Rol activo:</strong>
        ${LB.escaparHTML(rolActivo || usuario.rolPrincipal)}
      </p>
      <p>
        <strong>Estado:</strong>
        ${LB.crearBadgeEstado(usuario.estado)}
      </p>
    </div>
  `;
}


/* =========================================================
   5. Renderizar acciones de sesión

   Para usarlo en HTML:
   <div id="accionesSesion"></div>

   Si hay sesión, muestra botón de cerrar sesión.
   Si no hay sesión, muestra enlaces a login y registro.
   ========================================================= */

function renderizarAccionesSesion() {
  const contenedor = document.querySelector("#accionesSesion");

  if (!contenedor) {
    return;
  }

  const usuario = LB.obtenerUsuarioActual();

  if (usuario) {
    contenedor.innerHTML = `
      <div class="hero-botones">
        ${LB.crearBotonCerrarSesion()}
      </div>
    `;
    return;
  }

  contenedor.innerHTML = `
    <div class="hero-botones">
      <a class="btn-principal" href="${LB.rutaPagina("login.html")}">Iniciar sesión</a>
      <a class="btn-secundario" href="${LB.rutaPagina("registro.html")}">Registrarse</a>
    </div>
  `;
}


/* =========================================================
   6. Inicializar componentes comunes

   Aquí se pueden activar comportamientos visuales generales
   que no pertenecen a un módulo específico.
   ========================================================= */

function inicializarComponentesComunes() {
  inicializarTarjetasInteractuables();
  inicializarMensajesTemporales();
  inicializarConfirmacionesSimples();
}


/* =========================================================
   7. Tarjetas interactuables

   Si una tarjeta tiene data-href, se vuelve clickeable.
   Ejemplo:
   <article class="tarjeta" data-href="pages/login.html"></article>
   ========================================================= */

function inicializarTarjetasInteractuables() {
  const tarjetas = document.querySelectorAll(".tarjeta[data-href]");

  tarjetas.forEach(function (tarjeta) {
    tarjeta.style.cursor = "pointer";

    tarjeta.addEventListener("click", function () {
      const destino = tarjeta.getAttribute("data-href");

      if (destino) {
        window.location.href = destino;
      }
    });
  });
}


/* =========================================================
   8. Mensajes temporales

   Si un mensaje tiene data-auto-ocultar="true",
   se oculta después de unos segundos.

   Ejemplo:
   <div class="alerta alerta-info" data-auto-ocultar="true"></div>
   ========================================================= */

function inicializarMensajesTemporales() {
  const mensajes = document.querySelectorAll("[data-auto-ocultar='true']");

  mensajes.forEach(function (mensaje) {
    setTimeout(function () {
      mensaje.classList.add("oculto");
    }, 3500);
  });
}


/* =========================================================
   9. Confirmaciones simples

   Para botones o enlaces que necesiten confirmación visual:
   <button data-confirmar="¿Seguro?">Eliminar</button>
   ========================================================= */

function inicializarConfirmacionesSimples() {
  const elementos = document.querySelectorAll("[data-confirmar]");

  elementos.forEach(function (elemento) {
    elemento.addEventListener("click", function (evento) {
      const mensaje = elemento.getAttribute("data-confirmar") || "¿Está seguro?";

      const confirmado = window.confirm(mensaje);

      if (!confirmado) {
        evento.preventDefault();
      }
    });
  });
}


/* =========================================================
   10. Función auxiliar para cargar datos iniciales de landing

   Esta función es opcional.
   Si existe un contenedor #sorteosDestacados en index.html,
   carga sorteos.json y muestra tarjetas básicas.

   No falla si el contenedor no existe.
   ========================================================= */

async function cargarSorteosDestacados() {
  const contenedor = document.querySelector("#sorteosDestacados");

  if (!contenedor) {
    return;
  }

  LB.renderizarCargando("#sorteosDestacados", "Cargando sorteos destacados...");

  const sorteos = await LB.cargarJSON("sorteos.json");

  if (!sorteos || sorteos.length === 0) {
    LB.renderizarSinDatos("#sorteosDestacados", "No hay sorteos destacados disponibles.");
    return;
  }

  const sorteosActivos = sorteos.filter(function (sorteo) {
    return sorteo.estadoConfiguracion === "ACTIVO";
  });

  const html = sorteosActivos
    .map(function (sorteo) {
      return LB.crearTarjeta({
        titulo: sorteo.nombre,
        descripcion: `${sorteo.descripcion} Premio actual: ${LB.formatearMoneda(sorteo.premioActual)}.`,
        badge: LB.crearBadgeEstado(sorteo.estadoConfiguracion),
        enlace: LB.rutaPagina("sorteo-detalle.html") + `?id=${encodeURIComponent(sorteo.id)}`,
        textoEnlace: "Ver sorteo"
      });
    })
    .join("");

  contenedor.innerHTML = `
    <div class="grid-tarjetas">
      ${html}
    </div>
  `;
}


/* =========================================================
   11. Función auxiliar para mostrar premios destacados

   Si existe #premiosDestacados en index.html, se carga
   sorteos.json y se muestra el sorteo con mayor premio.
   ========================================================= */

async function cargarPremiosDestacados() {
  const contenedor = document.querySelector("#premiosDestacados");

  if (!contenedor) {
    return;
  }

  const sorteos = await LB.cargarJSON("sorteos.json");

  if (!sorteos || sorteos.length === 0) {
    LB.renderizarSinDatos("#premiosDestacados", "No hay premios disponibles.");
    return;
  }

  const sorteoMayorPremio = sorteos.reduce(function (mayor, actual) {
    return actual.premioActual > mayor.premioActual ? actual : mayor;
  }, sorteos[0]);

  contenedor.innerHTML = `
    <article class="premio-destacado">
      <h3>Premio destacado</h3>
      <p>${LB.escaparHTML(sorteoMayorPremio.nombre)}</p>
      <strong>${LB.formatearMoneda(sorteoMayorPremio.premioActual)}</strong>
    </article>
  `;
}


/* =========================================================
   12. Inicialización opcional de datos para landing

   Se ejecuta de forma segura:
   - Si los contenedores existen, renderiza.
   - Si no existen, no genera error.
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {
  if (typeof LB === "undefined") {
    return;
  }

  cargarSorteosDestacados();
  cargarPremiosDestacados();
});

/* =========================================================
   Menú móvil tipo overlay para paneles con sidebar

   Funciona en:
   - cliente.html
   - vendedor.html
   - admin.html

   Requiere:
   - .layout-app
   - .sidebar
   - enlaces con data-tab
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {
  inicializarMenuMovilApp();
});

function inicializarMenuMovilApp() {
  const layout = document.querySelector(".layout-app");
  const sidebar = document.querySelector(".layout-app .sidebar");

  document.body.classList.remove("menu-app-abierto");

  if (!layout || !sidebar) {
    return;
  }

  const enlaces = sidebar.querySelectorAll("[data-tab]");

  if (enlaces.length === 0) {
    return;
  }

  if (!sidebar.id) {
    sidebar.id = "menuLateralApp";
  }

  if (!document.querySelector(".overlay-menu-app")) {
    const overlay = document.createElement("div");
    overlay.className = "overlay-menu-app";
    overlay.setAttribute("aria-hidden", "true");
    document.body.appendChild(overlay);

    overlay.addEventListener("click", cerrarMenuMovilApp);
  }

  if (!document.querySelector(".menu-movil-app")) {
    const barra = document.createElement("div");
    barra.className = "menu-movil-app";

    barra.innerHTML = `
      <div class="menu-movil-info">
        <span class="menu-movil-label">Sección actual</span>
        <span class="menu-movil-titulo">Resumen</span>
      </div>

      <button
        type="button"
        class="btn-menu-movil"
        aria-label="Abrir menú de secciones"
        aria-controls="${sidebar.id}"
        aria-expanded="false"
      >
        <span></span>
        <span></span>
        <span></span>
      </button>
    `;

    layout.insertBefore(barra, sidebar);
  }

  const boton = document.querySelector(".btn-menu-movil");

  if (boton) {
    boton.addEventListener("click", function () {
      const estaAbierto = document.body.classList.toggle("menu-app-abierto");
      boton.setAttribute("aria-expanded", estaAbierto ? "true" : "false");
    });
  }

  enlaces.forEach(function (enlace) {
    enlace.addEventListener("click", function () {
      cerrarMenuMovilApp();

      setTimeout(function () {
        actualizarTituloMenuMovilApp();
      }, 60);
    });
  });

  document.addEventListener("keydown", function (evento) {
    if (evento.key === "Escape") {
      cerrarMenuMovilApp();
    }
  });

  window.addEventListener("resize", function () {
    if (window.innerWidth > 900) {
      cerrarMenuMovilApp();
    }
  });

  actualizarTituloMenuMovilApp();
}

function cerrarMenuMovilApp() {
  document.body.classList.remove("menu-app-abierto");

  const boton = document.querySelector(".btn-menu-movil");

  if (boton) {
    boton.setAttribute("aria-expanded", "false");
  }
}

function actualizarTituloMenuMovilApp() {
  const titulo = document.querySelector(".menu-movil-titulo");
  const activo = document.querySelector(".layout-app .sidebar [data-tab].activo");
  const primero = document.querySelector(".layout-app .sidebar [data-tab]");

  if (!titulo) {
    return;
  }

  const enlaceActual = activo || primero;

  if (!enlaceActual) {
    titulo.textContent = "Menú";
    return;
  }

  titulo.textContent = enlaceActual.textContent.trim();
}

/* =========================================================
   Funciones seguras para cerrar y actualizar menú móvil
   Usadas por cliente.js, vendedor.js y admin.js
   ========================================================= */

function cerrarMenuMovilAppSeguro() {
  if (typeof cerrarMenuMovilApp === "function") {
    cerrarMenuMovilApp();
    return;
  }

  document.body.classList.remove("menu-app-abierto");

  const botonMenu = document.querySelector(".btn-menu-movil");

  if (botonMenu) {
    botonMenu.setAttribute("aria-expanded", "false");
  }
}


function actualizarTituloMenuMovilAppSeguro() {
  if (typeof actualizarTituloMenuMovilApp === "function") {
    actualizarTituloMenuMovilApp();
    return;
  }

  const tituloMenu = document.querySelector(".menu-movil-titulo");
  const enlaceActivo = document.querySelector(".layout-app .sidebar [data-tab].activo");

  if (tituloMenu && enlaceActivo) {
    tituloMenu.textContent = enlaceActivo.textContent.trim();
  }
}