/* =========================================================
   Lotería Binaria - cliente.js

   Archivo encargado del dashboard del cliente.

   Funciones principales:
   - Cargar datos simulados desde JSON.
   - Mostrar saldo real y virtual.
   - Mostrar sorteos disponibles.
   - Comprar boletos de forma simulada.
   - Mostrar movimientos filtrables.
   - Simular acreditación con tarjeta.
   - Convertir dinero real a virtual.
   - Convertir dinero virtual a real con comisión 15%.
   - Enviar dinero virtual a otro cliente.
   - Mostrar boletos comprados con filtros.
   - Usar localStorage para cambios visuales.
   ========================================================= */


/* =========================================================
   1. Validación de dependencia
   ========================================================= */

if (typeof LB === "undefined") {
  console.error("cliente.js necesita que utils.js se cargue primero.");
}


/* =========================================================
   2. Estado global del dashboard cliente
   ========================================================= */

const ClienteApp = {
  usuarioActual: null,
  rolActivo: null,
  modoAcceso: null,

  usuarios: [],
  wallets: [],
  movimientos: [],
  sorteos: [],
  eventos: [],
  boletos: [],

  walletActual: null
};


/* =========================================================
   3. Claves de localStorage para datos simulados
   ========================================================= */

const CLIENTE_STORAGE = {
  WALLETS: "loteriaBinaria_walletsDemo",
  MOVIMIENTOS: "loteriaBinaria_movimientosDemo",
  BOLETOS: "loteriaBinaria_boletosDemo",
  ROL_ACTIVO: "loteriaBinaria_rolActivo",
  MODO_ACCESO: "loteriaBinaria_modoAcceso",
  SORTEOS: "loteriaBinaria_sorteosDemo",
  EVENTOS: "loteriaBinaria_eventosDemo",
};


/* =========================================================
   4. Inicialización
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {
  inicializarCliente();
});


async function inicializarCliente() {
  if (typeof LB === "undefined") {
    return;
  }

  ClienteApp.usuarioActual = LB.obtenerUsuarioActual();
  ClienteApp.rolActivo = localStorage.getItem(CLIENTE_STORAGE.ROL_ACTIVO);
  ClienteApp.modoAcceso = localStorage.getItem(CLIENTE_STORAGE.MODO_ACCESO);

  if (!ClienteApp.usuarioActual) {
    LB.mostrarAlerta(
      "#mensajeCliente",
      "No hay sesión activa. Redirigiendo al login...",
      "advertencia"
    );

    setTimeout(function () {
      window.location.href = "login.html";
    }, 900);

    return;
  }

  activarNavegacionInterna();

  await cargarDatosCliente();

  prepararWalletActual();
  poblarClientesDestinatarios();
  renderizarTodoCliente();
  activarEventosCliente();
}


/* =========================================================
   5. Cargar datos desde JSON y localStorage
   ========================================================= */

async function cargarDatosCliente() {
  LB.renderizarCargando("#resumenCliente", "Cargando información del cliente...");

  const [
    usuariosJSON,
    walletsJSON,
    movimientosJSON,
    sorteosJSON,
    eventosJSON,
    boletosJSON
  ] = await Promise.all([
    LB.cargarJSON("usuarios.json"),
    LB.cargarJSON("wallets.json"),
    LB.cargarJSON("movimientos.json"),
    LB.cargarJSON("sorteos.json"),
    LB.cargarJSON("eventos.json"),
    LB.cargarJSON("boletos.json")
  ]);

  ClienteApp.usuarios = usuariosJSON;
  ClienteApp.sorteos = obtenerDatosPersistidos(
    CLIENTE_STORAGE.SORTEOS,
    sorteosJSON
  );

  ClienteApp.eventos = obtenerDatosPersistidos(
    CLIENTE_STORAGE.EVENTOS,
    eventosJSON
  );

  ClienteApp.wallets = obtenerDatosPersistidos(
    CLIENTE_STORAGE.WALLETS,
    walletsJSON
  );

  ClienteApp.movimientos = obtenerDatosPersistidos(
    CLIENTE_STORAGE.MOVIMIENTOS,
    movimientosJSON
  );

  ClienteApp.boletos = obtenerDatosPersistidos(
    CLIENTE_STORAGE.BOLETOS,
    boletosJSON
  );
}


/* =========================================================
   6. Obtener datos persistidos en localStorage

   Si ya existen cambios simulados, se usan esos.
   Si no existen, se toman los datos originales del JSON.
   ========================================================= */

function obtenerDatosPersistidos(clave, datosIniciales) {
  try {
    const datosGuardados = localStorage.getItem(clave);

    if (datosGuardados) {
      return JSON.parse(datosGuardados);
    }

    localStorage.setItem(clave, JSON.stringify(datosIniciales));
    return datosIniciales;
  } catch (error) {
    console.error("Error al obtener datos persistidos:", error);
    return datosIniciales;
  }
}


/* =========================================================
   7. Guardar cambios visuales en localStorage
   ========================================================= */

function guardarDatosCliente() {
  localStorage.setItem(CLIENTE_STORAGE.WALLETS, JSON.stringify(ClienteApp.wallets));
  localStorage.setItem(CLIENTE_STORAGE.MOVIMIENTOS, JSON.stringify(ClienteApp.movimientos));
  localStorage.setItem(CLIENTE_STORAGE.BOLETOS, JSON.stringify(ClienteApp.boletos));
}


/* =========================================================
   8. Preparar wallet actual
   ========================================================= */

function prepararWalletActual() {
  ClienteApp.walletActual = ClienteApp.wallets.find(function (wallet) {
    return wallet.usuarioId === ClienteApp.usuarioActual.id;
  });

  if (!ClienteApp.walletActual) {
    ClienteApp.walletActual = {
      id: `WAL-${Date.now()}`,
      usuarioId: ClienteApp.usuarioActual.id,
      tipoUsuario: ClienteApp.usuarioActual.rolPrincipal,
      saldoReal: 0,
      saldoVirtual: 0,
      saldoRealReservado: 0,
      saldoVirtualReservado: 0,
      gananciasGeneradas: 0,
      moneda: "USD",
      estado: "ACTIVA",
      ultimaActualizacion: new Date().toISOString()
    };

    ClienteApp.wallets.push(ClienteApp.walletActual);
    guardarDatosCliente();
  }
}


/* =========================================================
   9. Navegación interna por pestañas/secciones
   ========================================================= */

function activarNavegacionInterna() {
  const enlaces = document.querySelectorAll("[data-tab]");
  const vistas = document.querySelectorAll(".vista-cliente");

  function mostrarVista(tab) {
    enlaces.forEach(function (item) {
      item.classList.toggle("activo", item.getAttribute("data-tab") === tab);
    });

    vistas.forEach(function (vista) {
      const vistaActual = vista.getAttribute("data-vista");
      vista.classList.toggle("oculto", vistaActual !== tab);
    });

    document.body.classList.remove("menu-app-abierto");

    const botonMenu = document.querySelector(".btn-menu-movil");
    if (botonMenu) {
      botonMenu.setAttribute("aria-expanded", "false");
    }

    const tituloMenu = document.querySelector(".menu-movil-titulo");
    const enlaceActivo = document.querySelector("[data-tab].activo");

    if (tituloMenu && enlaceActivo) {
      tituloMenu.textContent = enlaceActivo.textContent.trim();
    }
  }

  enlaces.forEach(function (enlace) {
    enlace.addEventListener("click", function (evento) {
      evento.preventDefault();

      const tab = enlace.getAttribute("data-tab");
      mostrarVista(tab);
    });
  });

  mostrarVista("resumen");
}

/* =========================================================
   10. Renderizar todas las secciones
   ========================================================= */

function renderizarTodoCliente() {
  renderizarResumenCliente();
  renderizarSorteosDisponibles();
  renderizarWalletCliente();
  renderizarMovimientos();
  renderizarBoletosComprados();
  renderizarInfoUsuario();
}


/* =========================================================
   11. Verificar si el usuario puede comprar boletos
   ========================================================= */

function usuarioPuedeComprarBoletos() {
  const usuario = ClienteApp.usuarioActual;

  if (!usuario) {
    return false;
  }

  const modo = String(
    ClienteApp.modoAcceso ||
    ClienteApp.rolActivo ||
    localStorage.getItem(CLIENTE_STORAGE.MODO_ACCESO) ||
    localStorage.getItem(CLIENTE_STORAGE.ROL_ACTIVO) ||
    ""
  )
    .trim()
    .toUpperCase();

  return modo === "CLIENTE";
}


/* =========================================================
   12. Renderizar resumen
   ========================================================= */

function renderizarResumenCliente() {
  const boletosUsuario = obtenerBoletosUsuario();
  const sorteosDisponibles = obtenerEventosDisponibles();

  const html = `
    <div class="resumen-grid">
      <article class="resumen-card">
        <span>Saldo real</span>
        <strong>${LB.formatearMoneda(ClienteApp.walletActual.saldoReal)}</strong>
        <p>Disponible para retirar o convertir.</p>
      </article>

      <article class="resumen-card">
        <span>Saldo virtual</span>
        <strong>${LB.formatearMoneda(ClienteApp.walletActual.saldoVirtual)}</strong>
        <p>Disponible para comprar boletos o enviar.</p>
      </article>

      <article class="resumen-card">
        <span>Boletos comprados</span>
        <strong>${boletosUsuario.length}</strong>
        <p>Incluye pendientes, premiados, reclamados y perdidos.</p>
      </article>

      <article class="resumen-card">
        <span>Sorteos disponibles</span>
        <strong>${sorteosDisponibles.length}</strong>
        <p>Eventos próximos habilitados para compra.</p>
      </article>
    </div>

    ${
      usuarioPuedeComprarBoletos()
        ? `<div class="alerta alerta-exito">Puedes comprar boletos usando tu saldo virtual.</div>`
        : `<div class="alerta alerta-advertencia">Estás en modo financiero o tu rol no permite comprar boletos.</div>`
    }
  `;

  LB.renderizarHTML("#resumenCliente", html);
}


/* =========================================================
   13. Obtener eventos disponibles para comprar
   ========================================================= */

function obtenerEventosDisponibles() {
  const ahora = new Date();

  return ClienteApp.eventos.filter(function (evento) {
    const cierre = new Date(evento.fechaCierreVenta);

    return (
      evento.estado === "PROXIMO" &&
      evento.disponibleCompra === true &&
      !Number.isNaN(cierre.getTime()) &&
      ahora < cierre
    );
  });
}


/* =========================================================
   14. Renderizar sorteos disponibles
   ========================================================= */

function renderizarSorteosDisponibles() {
  const eventosDisponibles = obtenerEventosDisponibles();

  if (eventosDisponibles.length === 0) {
    LB.renderizarSinDatos(
      "#listaSorteosDisponibles",
      "No hay sorteos disponibles para comprar en este momento."
    );
    return;
  }

  const html = eventosDisponibles
    .map(function (evento) {
      const sorteo = ClienteApp.sorteos.find(function (item) {
        return item.id === evento.sorteoId;
      });

      if (!sorteo) {
        return "";
      }

      const puedeComprar = usuarioPuedeComprarBoletos();

      return `
        <article class="tarjeta">
          ${LB.crearBadgeEstado(evento.estado)}
          <h3>${LB.escaparHTML(evento.nombreEvento)}</h3>

          <p><strong>Tipo:</strong> ${LB.escaparHTML(evento.tipo)}</p>
          <p><strong>Dígitos:</strong> ${LB.escaparHTML(sorteo.digitos)}</p>
          <p><strong>Números permitidos:</strong> ${LB.escaparHTML(sorteo.numerosPermitidos)}</p>
          <p><strong>Precio:</strong> ${LB.formatearMoneda(sorteo.precioBoleto)}</p>
          <p><strong>Premio actual:</strong> ${LB.formatearMoneda(evento.premioActual)}</p>
          <p><strong>Fecha sorteo:</strong> ${LB.formatearFechaHora(evento.fechaSorteo)}</p>
          <p><strong>Cierre ventas:</strong> ${LB.formatearFechaHora(evento.fechaCierreVenta)}</p>

          <button
            type="button"
            class="btn-principal"
            data-comprar-boleto="${LB.escaparHTML(evento.id)}"
            ${puedeComprar ? "" : "disabled"}
          >
            ${puedeComprar ? "Comprar boleto" : "Compra no permitida"}
          </button>
        </article>
      `;
    })
    .join("");

  LB.renderizarHTML(
    "#listaSorteosDisponibles",
    `<div class="grid-tarjetas">${html}</div>`
  );
}


/* =========================================================
   15. Comprar boleto de forma simulada
   ========================================================= */

function comprarBoleto(eventoId) {
  const evento = ClienteApp.eventos.find(function (item) {
    return item.id === eventoId;
  });

  if (!evento) {
    mostrarMensajeCliente("No se encontró el evento seleccionado.", "error");
    return;
  }

  const sorteo = ClienteApp.sorteos.find(function (item) {
    return item.id === evento.sorteoId;
  });

  if (!sorteo) {
    mostrarMensajeCliente("No se encontró la configuración del sorteo.", "error");
    return;
  }

  if (!usuarioPuedeComprarBoletos()) {
    mostrarMensajeCliente(
      "Tu modo de acceso actual no permite comprar boletos.",
      "advertencia"
    );
    return;
  }

  if (ClienteApp.walletActual.saldoVirtual < sorteo.precioBoleto) {
    mostrarMensajeCliente(
      "Saldo virtual insuficiente para comprar este boleto.",
      "error"
    );
    return;
  }

  const numeroElegido = generarNumeroBoleto(sorteo.tipo, sorteo.digitos);

  ClienteApp.walletActual.saldoVirtual = redondearDinero(
    ClienteApp.walletActual.saldoVirtual - sorteo.precioBoleto
  );

  ClienteApp.walletActual.ultimaActualizacion = new Date().toISOString();

  const nuevoBoleto = {
    id: generarId("BOL"),
    usuarioId: ClienteApp.usuarioActual.id,
    sorteoId: sorteo.id,
    eventoId: evento.id,
    numeroElegido: numeroElegido,
    tipo: sorteo.tipo,
    precio: sorteo.precioBoleto,
    fechaCompra: new Date().toISOString(),
    estado: "PENDIENTE",
    resultado: "AUN_NO_PASA_EL_SORTEO",
    premioObtenido: 0,
    reclamado: false
  };

  ClienteApp.boletos.push(nuevoBoleto);

  agregarMovimiento({
    tipoMovimiento: "COMPRA_BOLETO",
    tipoDinero: "VIRTUAL",
    monto: sorteo.precioBoleto,
    comision: 0,
    montoNeto: sorteo.precioBoleto,
    descripcion: `Compra de boleto ${numeroElegido} para ${sorteo.nombre}.`,
    estado: "COMPLETADO",
    referenciaId: nuevoBoleto.id
  });

  guardarDatosCliente();
  renderizarTodoCliente();

  mostrarMensajeCliente(
    `Boleto comprado correctamente. Número asignado: ${numeroElegido}`,
    "exito"
  );
}


/* =========================================================
   16. Generar número de boleto según tipo de sorteo
   ========================================================= */

function generarNumeroBoleto(tipo, digitos) {
  const caracteres = {
    OCTAL: "01234567",
    DECIMAL: "0123456789",
    HEXADECIMAL: "0123456789ABCDEF"
  };

  const permitidos = caracteres[tipo] || caracteres.DECIMAL;
  let numero = "";

  for (let i = 0; i < digitos; i++) {
    const posicion = Math.floor(Math.random() * permitidos.length);
    numero += permitidos[posicion];
  }

  return numero;
}


/* =========================================================
   17. Renderizar wallet
   ========================================================= */

function renderizarWalletCliente() {
  const html = `
    <div class="resumen-grid">
      <article class="resumen-card">
        <span>Saldo real</span>
        <strong>${LB.formatearMoneda(ClienteApp.walletActual.saldoReal)}</strong>
        <p>Dinero respaldado por pagos o conversiones.</p>
      </article>

      <article class="resumen-card">
        <span>Saldo virtual</span>
        <strong>${LB.formatearMoneda(ClienteApp.walletActual.saldoVirtual)}</strong>
        <p>Dinero usado para boletos y transferencias.</p>
      </article>

      <article class="resumen-card">
        <span>Saldo real reservado</span>
        <strong>${LB.formatearMoneda(ClienteApp.walletActual.saldoRealReservado || 0)}</strong>
        <p>Saldo bloqueado en solicitudes simuladas.</p>
      </article>

      <article class="resumen-card">
        <span>Última actualización</span>
        <strong>${LB.formatearFecha(ClienteApp.walletActual.ultimaActualizacion)}</strong>
        <p>Fecha de modificación visual.</p>
      </article>
    </div>
  `;

  LB.renderizarHTML("#walletCliente", html);
}


/* =========================================================
   18. Renderizar movimientos con filtro
   ========================================================= */

function renderizarMovimientos() {
  const filtro = document.querySelector("#filtroMovimientosDinero")?.value || "TODOS";

  let movimientosUsuario = ClienteApp.movimientos.filter(function (movimiento) {
    return movimiento.usuarioId === ClienteApp.usuarioActual.id;
  });

  if (filtro !== "TODOS") {
    movimientosUsuario = movimientosUsuario.filter(function (movimiento) {
      return String(movimiento.tipoDinero).includes(filtro);
    });
  }

  movimientosUsuario.sort(function (a, b) {
    return new Date(b.fecha) - new Date(a.fecha);
  });

  const tabla = LB.crearTabla(
    [
      {
        clave: "fecha",
        titulo: "Fecha",
        render: function (valor) {
          return LB.formatearFechaHora(valor);
        }
      },
      {
        clave: "tipoMovimiento",
        titulo: "Movimiento",
        render: function (valor) {
          return LB.escaparHTML(String(valor).replaceAll("_", " "));
        }
      },
      {
        clave: "tipoDinero",
        titulo: "Tipo"
      },
      {
        clave: "monto",
        titulo: "Monto",
        render: function (valor) {
          return LB.formatearMoneda(valor);
        }
      },
      {
        clave: "comision",
        titulo: "Comisión",
        render: function (valor) {
          return LB.formatearMoneda(valor || 0);
        }
      },
      {
        clave: "montoNeto",
        titulo: "Neto",
        render: function (valor) {
          return LB.formatearMoneda(valor || 0);
        }
      },
      {
        clave: "estado",
        titulo: "Estado",
        render: function (valor) {
          return LB.crearBadgeEstado(valor);
        }
      }
    ],
    movimientosUsuario
  );

  LB.renderizarHTML("#tablaMovimientos", tabla);
}


/* =========================================================
   19. Acreditar dinero real con tarjeta, comisión 5%
   ========================================================= */

function acreditarDineroReal(montoPagado) {
  const comision = redondearDinero(montoPagado * 0.05);
  const montoNeto = redondearDinero(montoPagado - comision);

  ClienteApp.walletActual.saldoReal = redondearDinero(
    ClienteApp.walletActual.saldoReal + montoNeto
  );

  ClienteApp.walletActual.ultimaActualizacion = new Date().toISOString();

  agregarMovimiento({
    tipoMovimiento: "ACREDITACION_TARJETA",
    tipoDinero: "REAL",
    monto: montoPagado,
    comision: comision,
    montoNeto: montoNeto,
    descripcion: "Acreditación simulada con tarjeta. Comisión del 5%.",
    estado: "COMPLETADO",
    referenciaId: null
  });

  guardarDatosCliente();
  renderizarTodoCliente();

  mostrarMensajeCliente(
    `Acreditación realizada. Comisión: ${LB.formatearMoneda(comision)}. Saldo real acreditado: ${LB.formatearMoneda(montoNeto)}.`,
    "exito"
  );
}


/* =========================================================
   20. Convertir real a virtual
   ========================================================= */




/* =========================================================
   21. Convertir virtual a real con comisión 15%
   ========================================================= */

function convertirVirtualAReal(monto) {
  if (ClienteApp.walletActual.saldoVirtual < monto) {
    mostrarMensajeCliente("Saldo virtual insuficiente.", "error");
    return;
  }

  const comision = redondearDinero(monto * 0.15);
  const montoNeto = redondearDinero(monto - comision);

  ClienteApp.walletActual.saldoVirtual = redondearDinero(
    ClienteApp.walletActual.saldoVirtual - monto
  );

  ClienteApp.walletActual.saldoReal = redondearDinero(
    ClienteApp.walletActual.saldoReal + montoNeto
  );

  ClienteApp.walletActual.ultimaActualizacion = new Date().toISOString();

  agregarMovimiento({
    tipoMovimiento: "CONVERSION_VIRTUAL_A_REAL",
    tipoDinero: "VIRTUAL_REAL",
    monto: monto,
    comision: comision,
    montoNeto: montoNeto,
    descripcion: "Conversión de dinero virtual a real con comisión antifraude del 15%.",
    estado: "COMPLETADO",
    referenciaId: null
  });

  guardarDatosCliente();
  renderizarTodoCliente();

  mostrarMensajeCliente(
    `Conversión realizada. Comisión: ${LB.formatearMoneda(comision)}. Recibes: ${LB.formatearMoneda(montoNeto)}.`,
    "exito"
  );
}


/* =========================================================
   22. Poblar clientes destinatarios
   ========================================================= */

function poblarClientesDestinatarios() {
  const select = document.querySelector("#destinatarioCliente");

  if (!select) {
    return;
  }

  const clientes = ClienteApp.usuarios.filter(function (usuario) {
    return (
      usuario.id !== ClienteApp.usuarioActual.id &&
      usuario.estado === "ACTIVO" &&
      Array.isArray(usuario.roles) &&
      usuario.roles.includes("CLIENTE")
    );
  });

  const opciones = clientes
    .map(function (cliente) {
      return `
        <option value="${LB.escaparHTML(cliente.id)}">
          ${LB.escaparHTML(cliente.nombres)} ${LB.escaparHTML(cliente.apellidos)} - ${LB.escaparHTML(cliente.usuario)}
        </option>
      `;
    })
    .join("");

  select.innerHTML = `
    <option value="">Seleccione un cliente</option>
    ${opciones}
  `;
}


/* =========================================================
   23. Enviar dinero virtual a otro cliente
   ========================================================= */

function enviarDineroACliente(destinatarioId, monto) {
  if (!destinatarioId) {
    mostrarMensajeCliente("Seleccione un cliente destinatario.", "error");
    return;
  }

  if (destinatarioId === ClienteApp.usuarioActual.id) {
    mostrarMensajeCliente("No puedes enviarte dinero a ti mismo.", "error");
    return;
  }

  if (ClienteApp.walletActual.saldoVirtual < monto) {
    mostrarMensajeCliente("Saldo virtual insuficiente para enviar.", "error");
    return;
  }

  const destinatario = ClienteApp.usuarios.find(function (usuario) {
    return usuario.id === destinatarioId;
  });

  if (!destinatario) {
    mostrarMensajeCliente("No se encontró el cliente destinatario.", "error");
    return;
  }

  let walletDestino = ClienteApp.wallets.find(function (wallet) {
    return wallet.usuarioId === destinatarioId;
  });

  if (!walletDestino) {
    walletDestino = {
      id: `WAL-${Date.now()}`,
      usuarioId: destinatarioId,
      tipoUsuario: "CLIENTE",
      saldoReal: 0,
      saldoVirtual: 0,
      saldoRealReservado: 0,
      saldoVirtualReservado: 0,
      gananciasGeneradas: 0,
      moneda: "USD",
      estado: "ACTIVA",
      ultimaActualizacion: new Date().toISOString()
    };

    ClienteApp.wallets.push(walletDestino);
  }

  ClienteApp.walletActual.saldoVirtual = redondearDinero(
    ClienteApp.walletActual.saldoVirtual - monto
  );

  walletDestino.saldoVirtual = redondearDinero(walletDestino.saldoVirtual + monto);

  ClienteApp.walletActual.ultimaActualizacion = new Date().toISOString();
  walletDestino.ultimaActualizacion = new Date().toISOString();

  agregarMovimiento({
    tipoMovimiento: "ENVIO_CLIENTE_A_CLIENTE",
    tipoDinero: "VIRTUAL",
    monto: monto,
    comision: 0,
    montoNeto: monto,
    descripcion: `Envío de dinero virtual a ${destinatario.nombres} ${destinatario.apellidos}.`,
    estado: "COMPLETADO",
    referenciaId: destinatarioId
  });

  ClienteApp.movimientos.push({
    id: generarId("MOV"),
    usuarioId: destinatarioId,
    walletId: walletDestino.id,
    tipoMovimiento: "RECEPCION_CLIENTE_A_CLIENTE",
    tipoDinero: "VIRTUAL",
    monto: monto,
    comision: 0,
    montoNeto: monto,
    descripcion: `Recepción de dinero virtual desde ${ClienteApp.usuarioActual.nombres} ${ClienteApp.usuarioActual.apellidos}.`,
    fecha: new Date().toISOString(),
    estado: "COMPLETADO",
    referenciaId: ClienteApp.usuarioActual.id
  });

  guardarDatosCliente();
  renderizarTodoCliente();

  mostrarMensajeCliente(
    `Envío realizado correctamente a ${destinatario.nombres}.`,
    "exito"
  );
}


/* =========================================================
   24. Obtener boletos del usuario actual
   ========================================================= */

function obtenerBoletosUsuario() {
  return ClienteApp.boletos.filter(function (boleto) {
    return boleto.usuarioId === ClienteApp.usuarioActual.id;
  });
}


/* =========================================================
   25. Renderizar boletos comprados con filtros
   ========================================================= */

function renderizarBoletosComprados() {
  const filtroAntiguedad = document.querySelector("#filtroAntiguedad")?.value || "TODOS";
  const filtroTipo = document.querySelector("#filtroTipoSorteo")?.value || "TODOS";
  const filtroEstado = document.querySelector("#filtroEstadoBoleto")?.value || "TODOS";

  let boletosUsuario = obtenerBoletosUsuario();

  if (filtroTipo !== "TODOS") {
    boletosUsuario = boletosUsuario.filter(function (boleto) {
      return boleto.tipo === filtroTipo;
    });
  }

  if (filtroEstado !== "TODOS") {
    boletosUsuario = boletosUsuario.filter(function (boleto) {
      return obtenerEstadoFiltroBoleto(boleto) === filtroEstado;
    });
  }

  boletosUsuario.sort(function (a, b) {
    const fechaA = new Date(a.fechaCompra);
    const fechaB = new Date(b.fechaCompra);

    if (filtroAntiguedad === "ANTIGUOS") {
      return fechaA - fechaB;
    }

    return fechaB - fechaA;
  });

  if (boletosUsuario.length === 0) {
    LB.renderizarSinDatos(
      "#contenedorBoletos",
      "No hay boletos que coincidan con los filtros seleccionados."
    );
    return;
  }

  const tabla = LB.crearTabla(
    [
      {
        clave: "numeroElegido",
        titulo: "Boleto",
        render: function (valor) {
          return `<span class="numero-boleto">${LB.escaparHTML(valor)}</span>`;
        }
      },
      {
        clave: "tipo",
        titulo: "Tipo"
      },
      {
        clave: "precio",
        titulo: "Precio",
        render: function (valor) {
          return LB.formatearMoneda(valor);
        }
      },
      {
        clave: "fechaCompra",
        titulo: "Fecha compra",
        render: function (valor) {
          return LB.formatearFechaHora(valor);
        }
      },
      {
        clave: "estado",
        titulo: "Estado",
        render: function (valor, fila) {
          return LB.crearBadgeEstado(obtenerEstadoFiltroBoleto(fila));
        }
      },
      {
        clave: "premioObtenido",
        titulo: "Premio",
        render: function (valor) {
          return LB.formatearMoneda(valor || 0);
        }
      },
      {
        clave: "id",
        titulo: "Detalle",
        render: function (valor) {
          return `<a href="boleto-detalle.html?id=${encodeURIComponent(valor)}">Ver</a>`;
        }
      }
    ],
    boletosUsuario
  );

  LB.renderizarHTML("#contenedorBoletos", tabla);
}


/* =========================================================
   26. Normalizar estado de boleto para filtros
   ========================================================= */

function obtenerEstadoFiltroBoleto(boleto) {
  if (boleto.estado === "RECLAMADO") {
    return "RECLAMADO";
  }

  if (boleto.estado === "PERDIDO") {
    return "PERDIDO";
  }

  if (boleto.estado === "PREMIADO") {
    return "PREMIADO";
  }

  if (boleto.resultado === "AUN_NO_PASA_EL_SORTEO") {
    return "AUN_NO_PASA_EL_SORTEO";
  }

  return boleto.estado;
}


/* =========================================================
   27. Renderizar información del usuario
   ========================================================= */

function renderizarInfoUsuario() {
  const usuario = ClienteApp.usuarioActual;
  const modo = ClienteApp.modoAcceso || ClienteApp.rolActivo || usuario.rolPrincipal;

  const html = `
    <div class="grid-tarjetas">
      <article class="tarjeta">
        <span class="badge badge-info">Datos personales</span>
        <h3>${LB.escaparHTML(usuario.nombres)} ${LB.escaparHTML(usuario.apellidos)}</h3>
        <p><strong>Documento:</strong> ${LB.escaparHTML(usuario.documento)}</p>
        <p><strong>Correo:</strong> ${LB.escaparHTML(usuario.correo)}</p>
        <p><strong>Teléfono:</strong> ${LB.escaparHTML(usuario.telefono)}</p>
      </article>

      <article class="tarjeta">
        <span class="badge badge-dorado">Acceso</span>
        <h3>Rol y modo</h3>
        <p><strong>Rol real:</strong> ${LB.escaparHTML(usuario.rolPrincipal)}</p>
        <p><strong>Modo actual:</strong> ${LB.escaparHTML(modo)}</p>
        <p><strong>Estado:</strong> ${LB.crearBadgeEstado(usuario.estado)}</p>
      </article>

      <article class="tarjeta">
        <span class="badge badge-reclamado">Reglas</span>
        <h3>Permisos</h3>
        <p><strong>Puede comprar boletos:</strong> ${usuarioPuedeComprarBoletos() ? "Sí" : "No"}</p>
        <p><strong>Puede usar wallet:</strong> Sí</p>
        <p><strong>Puede enviar dinero:</strong> Sí, solo a otros clientes.</p>
      </article>
    </div>
  `;

  LB.renderizarHTML("#infoUsuario", html);
}


/* =========================================================
   28. Activar eventos de formularios y filtros
   ========================================================= */

function activarEventosCliente() {
  document.addEventListener("click", function (evento) {
    const botonComprar = evento.target.closest("[data-comprar-boleto]");

    if (botonComprar) {
      const eventoId = botonComprar.getAttribute("data-comprar-boleto");
      comprarBoleto(eventoId);
    }
  });

  activarFormularioAcreditar();
  activarFormularioVirtualReal();
  activarFormularioEnviarDinero();
  activarFiltros();
  activarPreviewVirtualReal();
}


/* =========================================================
   29. Formulario: acreditar dinero real
   ========================================================= */

function activarFormularioAcreditar() {
  const form = document.querySelector("#formAcreditarReal");

  if (!form) {
    return;
  }

  form.addEventListener("submit", function (evento) {
    evento.preventDefault();

    const monto = obtenerMonto("#montoTarjeta");

    if (monto <= 0) {
      mostrarMensajeCliente("Ingrese un monto válido para acreditar.", "error");
      return;
    }

    acreditarDineroReal(monto);
    form.reset();
  });
}



/* =========================================================
   31. Formulario: virtual a real
   ========================================================= */

function activarFormularioVirtualReal() {
  const form = document.querySelector("#formVirtualReal");

  if (!form) {
    return;
  }

  form.addEventListener("submit", function (evento) {
    evento.preventDefault();

    const monto = obtenerMonto("#montoVirtualReal");

    if (monto <= 0) {
      mostrarMensajeCliente("Ingrese un monto válido para convertir.", "error");
      return;
    }

    convertirVirtualAReal(monto);
    form.reset();
    actualizarPreviewVirtualReal();
  });
}


/* =========================================================
   32. Preview de comisión virtual a real
   ========================================================= */

function activarPreviewVirtualReal() {
  const input = document.querySelector("#montoVirtualReal");

  if (!input) {
    return;
  }

  input.addEventListener("input", actualizarPreviewVirtualReal);
}


function actualizarPreviewVirtualReal() {
  const contenedor = document.querySelector("#previewVirtualReal");

  if (!contenedor) {
    return;
  }

  const monto = obtenerMonto("#montoVirtualReal");

  if (monto <= 0) {
    contenedor.innerHTML = "Ingresa un monto para ver la comisión.";
    return;
  }

  const comision = redondearDinero(monto * 0.15);
  const neto = redondearDinero(monto - comision);

  contenedor.innerHTML = `
    Monto solicitado: ${LB.formatearMoneda(monto)}<br>
    Comisión 15%: ${LB.formatearMoneda(comision)}<br>
    Recibirás en saldo real: ${LB.formatearMoneda(neto)}
  `;
}


/* =========================================================
   33. Formulario: enviar dinero
   ========================================================= */

function activarFormularioEnviarDinero() {
  const form = document.querySelector("#formEnviarDinero");

  if (!form) {
    return;
  }

  form.addEventListener("submit", function (evento) {
    evento.preventDefault();

    const destinatarioId = document.querySelector("#destinatarioCliente")?.value || "";
    const monto = obtenerMonto("#montoEnvio");

    if (monto <= 0) {
      mostrarMensajeCliente("Ingrese un monto válido para enviar.", "error");
      return;
    }

    enviarDineroACliente(destinatarioId, monto);
    form.reset();
  });
}


/* =========================================================
   34. Activar filtros
   ========================================================= */

function activarFiltros() {
  const filtroMovimientos = document.querySelector("#filtroMovimientosDinero");
  const filtroAntiguedad = document.querySelector("#filtroAntiguedad");
  const filtroTipo = document.querySelector("#filtroTipoSorteo");
  const filtroEstado = document.querySelector("#filtroEstadoBoleto");

  if (filtroMovimientos) {
    filtroMovimientos.addEventListener("change", renderizarMovimientos);
  }

  [filtroAntiguedad, filtroTipo, filtroEstado].forEach(function (filtro) {
    if (filtro) {
      filtro.addEventListener("change", renderizarBoletosComprados);
    }
  });
}


/* =========================================================
   35. Agregar movimiento
   ========================================================= */

function agregarMovimiento(datosMovimiento) {
  ClienteApp.movimientos.push({
    id: generarId("MOV"),
    usuarioId: ClienteApp.usuarioActual.id,
    walletId: ClienteApp.walletActual.id,
    tipoMovimiento: datosMovimiento.tipoMovimiento,
    tipoDinero: datosMovimiento.tipoDinero,
    monto: redondearDinero(datosMovimiento.monto),
    comision: redondearDinero(datosMovimiento.comision || 0),
    montoNeto: redondearDinero(datosMovimiento.montoNeto || datosMovimiento.monto),
    descripcion: datosMovimiento.descripcion,
    fecha: new Date().toISOString(),
    estado: datosMovimiento.estado || "COMPLETADO",
    referenciaId: datosMovimiento.referenciaId || null
  });
}


/* =========================================================
   36. Utilidades internas
   ========================================================= */

function obtenerMonto(selector) {
  const input = document.querySelector(selector);

  if (!input) {
    return 0;
  }

  const valor = Number(input.value);

  if (Number.isNaN(valor)) {
    return 0;
  }

  return redondearDinero(valor);
}


function redondearDinero(valor) {
  return Math.round(Number(valor) * 100) / 100;
}


function generarId(prefijo) {
  return `${prefijo}-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
}


function mostrarMensajeCliente(mensaje, tipo) {
  LB.mostrarAlerta("#mensajeCliente", mensaje, tipo);

  window.scrollTo({
    top: 0,
    behavior: "smooth"
  });
}