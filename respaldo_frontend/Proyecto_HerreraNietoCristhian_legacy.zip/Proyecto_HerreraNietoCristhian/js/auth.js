/* =========================================================
   Lotería Binaria - auth.js

   Archivo encargado de:
   - Login simulado con data/usuarios.json.
   - Registro simulado.
   - Selección de modo de acceso por rol.
   - Uso de localStorage para simular sesión.

   Importante:
   - No usa backend.
   - No usa base de datos real.
   - No modifica archivos JSON.
   - Usa JavaScript puro.
   ========================================================= */


/* =========================================================
   1. Validación inicial de dependencia

   Este archivo necesita que utils.js haya cargado antes,
   porque usa el objeto global LB.
   ========================================================= */

if (typeof LB === "undefined") {
  console.error("auth.js necesita que utils.js se cargue primero.");
}


/* =========================================================
   2. Claves adicionales para localStorage

   En utils.js ya existe:
   - loteriaBinaria_usuarioActual
   - loteriaBinaria_rolActivo

   Aquí se agregan:
   - rol real del usuario
   - modo de acceso elegido
   ========================================================= */

const AUTH_KEYS = {
  USUARIO_ACTUAL: "loteriaBinaria_usuarioActual",
  ROL_ACTIVO: "loteriaBinaria_rolActivo",
  ROL_REAL: "loteriaBinaria_rolReal",
  MODO_ACCESO: "loteriaBinaria_modoAcceso"
};


/* =========================================================
   3. Inicialización del archivo según la página actual
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {
  inicializarLogin();
  inicializarRegistro();
  inicializarElegirRol();
});


/* =========================================================
   4. LOGIN
   ========================================================= */

function inicializarLogin() {
  const formLogin = document.querySelector("#formLogin");

  // Evita errores si este archivo se carga en otra página.
  if (!formLogin) {
    return;
  }

  formLogin.addEventListener("submit", async function (evento) {
    evento.preventDefault();

    const usuarioCorreo = obtenerValorCampo("#usuarioCorreo");
    const password = obtenerValorCampo("#password");

    if (!usuarioCorreo || !password) {
      mostrarMensajeLogin("Ingrese usuario/correo y contraseña.", "error");
      return;
    }

    mostrarMensajeLogin("Validando credenciales...", "info");

    // Carga usuarios desde data/usuarios.json usando fetch.
    const usuarios = await LB.cargarJSON("usuarios.json");

    if (!Array.isArray(usuarios) || usuarios.length === 0) {
      mostrarMensajeLogin("No se pudieron cargar los usuarios simulados.", "error");
      return;
    }

    const usuarioEncontrado = usuarios.find(function (usuario) {
      const coincideUsuario = usuario.usuario === usuarioCorreo;
      const coincideCorreo = usuario.correo === usuarioCorreo;
      const coincidePassword = usuario.password === password;

      return (coincideUsuario || coincideCorreo) && coincidePassword;
    });

    if (!usuarioEncontrado) {
      mostrarMensajeLogin("Credenciales incorrectas.", "error");
      return;
    }

    if (usuarioEncontrado.estado !== "ACTIVO") {
      mostrarMensajeLogin("El usuario existe, pero está inactivo.", "advertencia");
      return;
    }

    guardarSesionInicial(usuarioEncontrado);
    redireccionarSegunRol(usuarioEncontrado);
  });
}


/* =========================================================
   5. Guardar sesión inicial

   Se guarda:
   - Usuario actual.
   - Rol real.
   - Rol activo inicial.
   - Modo de acceso inicial.

   Para cliente:
   - El modo se define automáticamente como CLIENTE.

   Para vendedor/admin:
   - El modo queda pendiente hasta elegir en elegir-rol.html.
   ========================================================= */

function guardarSesionInicial(usuario) {
  localStorage.setItem(AUTH_KEYS.USUARIO_ACTUAL, JSON.stringify(usuario));
  localStorage.setItem(AUTH_KEYS.ROL_REAL, usuario.rolPrincipal);

  if (usuario.rolPrincipal === "CLIENTE") {
    localStorage.setItem(AUTH_KEYS.ROL_ACTIVO, "CLIENTE");
    localStorage.setItem(AUTH_KEYS.MODO_ACCESO, "CLIENTE");
    return;
  }

  localStorage.setItem(AUTH_KEYS.ROL_ACTIVO, usuario.rolPrincipal);
  localStorage.setItem(AUTH_KEYS.MODO_ACCESO, "PENDIENTE");
}


/* =========================================================
   6. Redirección después del login
   ========================================================= */

function redireccionarSegunRol(usuario) {
  if (usuario.rolPrincipal === "CLIENTE") {
    window.location.href = "cliente.html";
    return;
  }

  if (usuario.rolPrincipal === "VENDEDOR" || usuario.rolPrincipal === "ADMIN") {
    window.location.href = "elegir-rol.html";
    return;
  }

  mostrarMensajeLogin("El rol del usuario no está permitido.", "error");
}


/* =========================================================
   7. Mensaje de login
   ========================================================= */

function mostrarMensajeLogin(mensaje, tipo) {
  LB.mostrarAlerta("#mensajeLogin", mensaje, tipo);
}


/* =========================================================
   8. REGISTRO SIMULADO
   ========================================================= */

function inicializarRegistro() {
  const formRegistro = document.querySelector("#formRegistro");

  // Evita errores si este archivo se carga en otra página.
  if (!formRegistro) {
    return;
  }

  formRegistro.addEventListener("submit", function (evento) {
    evento.preventDefault();

    const datos = {
      nombres: obtenerValorCampo("#nombres"),
      apellidos: obtenerValorCampo("#apellidos"),
      documento: obtenerValorCampo("#documento"),
      fechaNacimiento: obtenerValorCampo("#fechaNacimiento"),
      correo: obtenerValorCampo("#correo"),
      telefono: obtenerValorCampo("#telefono"),
      usuario: obtenerValorCampo("#usuario"),
      password: obtenerValorCampo("#password"),
      confirmarPassword: obtenerValorCampo("#confirmarPassword"),
      terminos: document.querySelector("#terminos")?.checked || false
    };

    const errores = validarRegistro(datos);

    if (errores.length > 0) {
      mostrarErroresRegistro(errores);
      return;
    }

    // Registro simulado: no se guarda en JSON ni en backend.
    LB.mostrarAlerta(
      "#mensajeRegistro",
      "Registro simulado exitoso. Ahora puede iniciar sesión con un usuario demo.",
      "exito"
    );

    formRegistro.reset();
  });
}


/* =========================================================
   9. Validaciones del registro
   ========================================================= */

function validarRegistro(datos) {
  const errores = [];

  if (!datos.nombres) {
    errores.push("El campo nombres es obligatorio.");
  }

  if (!datos.apellidos) {
    errores.push("El campo apellidos es obligatorio.");
  }

  if (!datos.documento) {
    errores.push("El documento es obligatorio.");
  }

  if (!datos.fechaNacimiento) {
    errores.push("La fecha de nacimiento es obligatoria.");
  } else if (!esMayorDeEdad(datos.fechaNacimiento)) {
    errores.push("Debe ser mayor de edad para registrarse.");
  }

  if (!datos.correo) {
    errores.push("El correo electrónico es obligatorio.");
  } else if (!correoValido(datos.correo)) {
    errores.push("Ingrese un correo electrónico válido.");
  }

  if (!datos.telefono) {
    errores.push("El teléfono es obligatorio.");
  } else if (!telefonoValido(datos.telefono)) {
    errores.push("Ingrese un teléfono válido. Use solo números y mínimo 7 dígitos.");
  }

  if (!datos.usuario) {
    errores.push("El usuario es obligatorio.");
  }

  if (!datos.password) {
    errores.push("La contraseña es obligatoria.");
  } else if (datos.password.length < 6) {
    errores.push("La contraseña debe tener al menos 6 caracteres.");
  }

  if (!datos.confirmarPassword) {
    errores.push("Debe confirmar la contraseña.");
  }

  if (datos.password && datos.confirmarPassword && datos.password !== datos.confirmarPassword) {
    errores.push("Las contraseñas no coinciden.");
  }

  if (!datos.terminos) {
    errores.push("Debe aceptar los términos y condiciones.");
  }

  return errores;
}


/* =========================================================
   10. Mostrar errores del registro
   ========================================================= */

function mostrarErroresRegistro(errores) {
  const listaErrores = errores
    .map(function (error) {
      return `<li>${LB.escaparHTML(error)}</li>`;
    })
    .join("");

  const contenedor = document.querySelector("#mensajeRegistro");

  if (!contenedor) {
    return;
  }

  contenedor.innerHTML = `
    <div class="alerta alerta-error" role="alert">
      <strong>Revise los siguientes campos:</strong>
      <ul>
        ${listaErrores}
      </ul>
    </div>
  `;
}


/* =========================================================
   11. Validar mayoría de edad

   Se calcula dinámicamente usando la fecha actual del navegador.
   ========================================================= */

function esMayorDeEdad(fechaNacimiento) {
  const nacimiento = new Date(fechaNacimiento);
  const hoy = new Date();

  if (Number.isNaN(nacimiento.getTime())) {
    return false;
  }

  let edad = hoy.getFullYear() - nacimiento.getFullYear();
  const mes = hoy.getMonth() - nacimiento.getMonth();

  if (mes < 0 || (mes === 0 && hoy.getDate() < nacimiento.getDate())) {
    edad--;
  }

  return edad >= 18;
}


/* =========================================================
   12. Validar correo
   ========================================================= */

function correoValido(correo) {
  const expresion = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return expresion.test(correo);
}


/* =========================================================
   13. Validar teléfono
   ========================================================= */

function telefonoValido(telefono) {
  const expresion = /^[0-9]{7,15}$/;
  return expresion.test(telefono);
}


/* =========================================================
   14. ELEGIR ROL
   ========================================================= */

function inicializarElegirRol() {
  const contenedorOpciones = document.querySelector("#opcionesRoles");

  // Si no existe este contenedor, no estamos en elegir-rol.html.
  if (!contenedorOpciones) {
    return;
  }

  const usuarioActual = obtenerUsuarioActualAuth();

  if (!usuarioActual) {
    LB.mostrarAlerta(
      "#mensajeElegirRol",
      "No hay una sesión activa. Redirigiendo al login...",
      "advertencia"
    );

    setTimeout(function () {
      window.location.href = "login.html";
    }, 900);

    return;
  }

  renderizarResumenUsuarioRol(usuarioActual);
  renderizarOpcionesDeAcceso(usuarioActual);
}


/* =========================================================
   15. Renderizar resumen de usuario en elegir-rol.html
   ========================================================= */

function renderizarResumenUsuarioRol(usuario) {
  const contenedor = document.querySelector("#resumenUsuarioRol");

  if (!contenedor) {
    return;
  }

  const rolesTexto = Array.isArray(usuario.roles)
    ? usuario.roles.join(", ")
    : usuario.rolPrincipal;

  contenedor.innerHTML = `
    <div class="tarjeta">
      <span class="badge badge-info">Sesión activa</span>
      <h3>${LB.escaparHTML(usuario.nombres)} ${LB.escaparHTML(usuario.apellidos)}</h3>
      <p><strong>Rol real:</strong> ${LB.escaparHTML(usuario.rolPrincipal)}</p>
      <p><strong>Roles disponibles:</strong> ${LB.escaparHTML(rolesTexto)}</p>
      <p><strong>Estado:</strong> ${LB.crearBadgeEstado(usuario.estado)}</p>
    </div>
  `;
}


/* =========================================================
   16. Renderizar opciones permitidas según rol real
   ========================================================= */

function renderizarOpcionesDeAcceso(usuario) {
  const contenedor = document.querySelector("#opcionesRoles");

  if (!contenedor) {
    return;
  }

  const opciones = obtenerOpcionesPermitidas(usuario);

  if (opciones.length === 0) {
    contenedor.innerHTML = `
      <div class="alerta alerta-error">
        Este usuario no tiene opciones de acceso disponibles.
      </div>
    `;
    return;
  }

  contenedor.innerHTML = opciones
    .map(function (opcion) {
      return crearTarjetaModoAcceso(opcion);
    })
    .join("");

  activarBotonesModoAcceso();
}


/* =========================================================
   17. Obtener opciones permitidas

   Reglas:
   - Vendedor: VENDEDOR y CLIENTE_FINANCIERO.
   - Admin: ADMIN, VENDEDOR y CLIENTE_FINANCIERO.
   - Cliente: normalmente no llega aquí, pero se contempla.
   ========================================================= */

function obtenerOpcionesPermitidas(usuario) {
  const rolPrincipal = usuario.rolPrincipal;

  if (rolPrincipal === "VENDEDOR") {
    return [
      {
        modo: "VENDEDOR",
        titulo: "Entrar como vendedor",
        badge: "Vendedor",
        claseBadge: "badge-info",
        descripcion: "Atiende solicitudes de clientes, revisa movimientos y gestiona su wallet.",
        destino: "vendedor.html"
      },
      {
        modo: "CLIENTE",
        titulo: "Entrar como cliente",
        badge: "Cliente",
        claseBadge: "badge-premiado",
        descripcion: "Compra boletos, crea solicitudes, gestiona wallet y revisa participaciones.",
        destino: "cliente.html"
      }
    ];
  }

  if (rolPrincipal === "ADMIN") {
    return [
      {
        modo: "ADMIN",
        titulo: "Entrar como administrador",
        badge: "Admin",
        claseBadge: "badge-dorado",
        descripcion: "Gestiona usuarios, sorteos, configuraciones, solicitudes y estadísticas.",
        destino: "admin.html"
      },
      {
        modo: "VENDEDOR",
        titulo: "Entrar como vendedor",
        badge: "Vendedor",
        claseBadge: "badge-info",
        descripcion: "Visualiza el flujo de vendedor y atiende solicitudes simuladas.",
        destino: "vendedor.html"
      },
      {
        modo: "CLIENTE",
        titulo: "Entrar como cliente",
        badge: "Cliente",
        claseBadge: "badge-premiado",
        descripcion: "Compra boletos, crea solicitudes, gestiona wallet y revisa participaciones.",
        destino: "cliente.html"
      }
    ];
  }

  if (rolPrincipal === "CLIENTE") {
    return [
      {
        modo: "CLIENTE",
        titulo: "Entrar como cliente",
        badge: "Cliente",
        claseBadge: "badge-premiado",
        descripcion: "Compra boletos, gestiona wallet y revisa resultados.",
        destino: "cliente.html"
      }
    ];
  }

  return [];
}


/* =========================================================
   18. Crear tarjeta visual para modo de acceso
   ========================================================= */

function crearTarjetaModoAcceso(opcion) {
  return `
    <article class="tarjeta">
      <span class="badge ${LB.escaparHTML(opcion.claseBadge)}">
        ${LB.escaparHTML(opcion.badge)}
      </span>

      <h2>${LB.escaparHTML(opcion.titulo)}</h2>

      <p>${LB.escaparHTML(opcion.descripcion)}</p>

      <button
        type="button"
        class="btn-principal"
        data-modo-acceso="${LB.escaparHTML(opcion.modo)}"
        data-destino="${LB.escaparHTML(opcion.destino)}"
      >
        Seleccionar
      </button>
    </article>
  `;
}


/* =========================================================
   19. Activar botones de modo de acceso
   ========================================================= */

function activarBotonesModoAcceso() {
  const botones = document.querySelectorAll("[data-modo-acceso]");

  botones.forEach(function (boton) {
    boton.addEventListener("click", function () {
      const modoAcceso = boton.getAttribute("data-modo-acceso");
      const destino = boton.getAttribute("data-destino");

      if (!modoAcceso || !destino) {
        LB.mostrarAlerta(
          "#mensajeElegirRol",
          "No se pudo determinar el modo de acceso.",
          "error"
        );
        return;
      }

      guardarModoAcceso(modoAcceso);

      LB.mostrarAlerta(
        "#mensajeElegirRol",
        `Modo de acceso seleccionado: ${modoAcceso}. Redirigiendo...`,
        "exito"
      );

      setTimeout(function () {
        window.location.href = destino;
      }, 600);
    });
  });
}


/* =========================================================
   20. Guardar modo de acceso elegido
   ========================================================= */

function guardarModoAcceso(modoAcceso) {
  localStorage.setItem(AUTH_KEYS.MODO_ACCESO, modoAcceso);
  localStorage.setItem(AUTH_KEYS.ROL_ACTIVO, modoAcceso);

  // Compatibilidad con utils.js si se usa LB.obtenerRolActivo().
  if (typeof LB.guardarRolActivo === "function") {
    LB.guardarRolActivo(modoAcceso);
  }
}


/* =========================================================
   21. Obtener usuario actual para auth.js
   ========================================================= */

function obtenerUsuarioActualAuth() {
  try {
    const usuarioJSON = localStorage.getItem(AUTH_KEYS.USUARIO_ACTUAL);

    if (!usuarioJSON) {
      return null;
    }

    return JSON.parse(usuarioJSON);
  } catch (error) {
    console.error("Error al leer usuario actual:", error);
    return null;
  }
}


/* =========================================================
   22. Obtener valor de campo de forma segura
   ========================================================= */

function obtenerValorCampo(selector) {
  const campo = document.querySelector(selector);

  if (!campo) {
    return "";
  }

  return campo.value.trim();
}