/* =========================================================
   Lotería Binaria - vendedor.js

   Archivo encargado del dashboard del vendedor.

   Funciones principales:
   - Cargar datos simulados desde JSON.
   - Mostrar wallet del vendedor.
   - Acreditar dinero real con tarjeta, comisión 5%.
   - Comprar dinero virtual con regla 0.90 real = 1 virtual.
   - Convertir virtual a real con comisión 15%.
   - Retirar dinero real.
   - Ver solicitudes de clientes.
   - Tomar, confirmar y cancelar solicitudes.
   - Enviar dinero virtual permitido a clientes.
   - Guardar cambios visuales en localStorage.

   Importante:
   - No usa backend.
   - No modifica archivos JSON.
   - No permite compra de boletos.
   - No muestra gestión de boletos comprados.
   - No permite participar en sorteos.
   ========================================================= */

/* =========================================================
   Contador visual de caducidad de solicitudes
   ========================================================= */
/* =========================================================
   Compatibilidad menú móvil
   Evita que el panel vendedor se rompa si se llama
   cerrarMenuMovilAppSeguro() desde una versión anterior.
   ========================================================= */

function cerrarMenuMovilAppSeguro() {
  if (typeof cerrarMenuMovilApp === "function") {
    cerrarMenuMovilApp();
    return;
  }

  document.body.classList.remove("menu-app-abierto");

  const botonMenu = document.querySelector(".btn-menu-movil");

  if (botonMenu) {
    botonMenu.setAttribute("aria-expanded", "false");
  }
}

function actualizarTituloMenuMovilAppSeguro() {
  if (typeof actualizarTituloMenuMovilApp === "function") {
    actualizarTituloMenuMovilApp();
    return;
  }

  const tituloMenu = document.querySelector(".menu-movil-titulo");
  const enlaceActivo = document.querySelector(".layout-app .sidebar [data-tab].activo");

  if (tituloMenu && enlaceActivo) {
    tituloMenu.textContent = enlaceActivo.textContent.trim();
  }
}

function iniciarContadorCaducidadSolicitudes() {
  actualizarContadoresCaducidadSolicitudes();

  if (VendedorApp.intervaloCaducidadSolicitudes) {
    clearInterval(VendedorApp.intervaloCaducidadSolicitudes);
  }

  VendedorApp.intervaloCaducidadSolicitudes = setInterval(function () {
    actualizarContadoresCaducidadSolicitudes();

    const huboCambios = simularConversionAutomaticaSolicitudes();

    if (huboCambios) {
      guardarDatosVendedor();
      renderizarTodoVendedor();
    }
  }, 1000);
}


function actualizarContadoresCaducidadSolicitudes() {
  const contadores = document.querySelectorAll(".contador-caducidad-solicitud");

  contadores.forEach(function (contador) {
    const fechaExpira = new Date(contador.getAttribute("data-expira"));

    if (Number.isNaN(fechaExpira.getTime())) {
      contador.textContent = "Sin fecha";
      return;
    }

    const ahora = new Date();
    const diferencia = Math.max(0, Math.floor((fechaExpira - ahora) / 1000));

    const minutos = Math.floor(diferencia / 60);
    const segundos = diferencia % 60;

    contador.textContent =
      String(minutos).padStart(2, "0") +
      ":" +
      String(segundos).padStart(2, "0");

    if (diferencia <= 0) {
      contador.textContent = "Procesando...";
    }
  });
}
/* =========================================================
   1. Validación de dependencia
   ========================================================= */

if (typeof LB === "undefined") {
  console.error("vendedor.js necesita que utils.js se cargue primero.");
}
/* =========================================================
   Funciones seguras para menú móvil
   Evitan errores si algún archivo llama las versiones "Seguro"
   ========================================================= */

function cerrarMenuMovilAppSeguro() {
  if (typeof cerrarMenuMovilApp === "function") {
    cerrarMenuMovilApp();
    return;
  }

  document.body.classList.remove("menu-app-abierto");

  const botonMenu = document.querySelector(".btn-menu-movil");

  if (botonMenu) {
    botonMenu.setAttribute("aria-expanded", "false");
  }
}


function actualizarTituloMenuMovilAppSeguro() {
  if (typeof actualizarTituloMenuMovilApp === "function") {
    actualizarTituloMenuMovilApp();
    return;
  }

  const tituloMenu = document.querySelector(".menu-movil-titulo");
  const enlaceActivo = document.querySelector(".layout-app .sidebar [data-tab].activo");

  if (tituloMenu && enlaceActivo) {
    tituloMenu.textContent = enlaceActivo.textContent.trim();
  }
}

/* =========================================================
   2. Estado global del dashboard vendedor
   ========================================================= */

const VendedorApp = {
  usuarioActual: null,
  rolActivo: null,
  modoAcceso: null,

  usuarios: [],
  wallets: [],
  movimientos: [],
  solicitudes: [],

  walletActual: null,
  temporizadoresSolicitudes: {}
};


/* =========================================================
   3. Claves de localStorage para persistencia de la demo
   ========================================================= */

const VENDEDOR_STORAGE = {
  WALLETS: "loteriaBinaria_walletsDemo",
  MOVIMIENTOS: "loteriaBinaria_movimientosDemo",
  SOLICITUDES: "loteriaBinaria_solicitudesDemo",
  ROL_ACTIVO: "loteriaBinaria_rolActivo",
  MODO_ACCESO: "loteriaBinaria_modoAcceso"
};


/* =========================================================
   4. Inicialización
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {
  inicializarVendedor();
});


async function inicializarVendedor() {
  if (typeof LB === "undefined") {
    console.error("No existe LB. Revisa que utils.js cargue antes de vendedor.js.");
    return;
  }

  VendedorApp.usuarioActual = LB.obtenerUsuarioActual();
  VendedorApp.rolActivo = localStorage.getItem(VENDEDOR_STORAGE.ROL_ACTIVO);
  VendedorApp.modoAcceso = localStorage.getItem(VENDEDOR_STORAGE.MODO_ACCESO);

  if (!VendedorApp.usuarioActual) {
    LB.mostrarAlerta(
      "#mensajeVendedor",
      "No hay sesión activa. Redirigiendo al login...",
      "advertencia"
    );

    setTimeout(function () {
      window.location.href = "login.html";
    }, 900);

    return;
  }

  if (!usuarioTieneAccesoVendedor()) {
    LB.mostrarAlerta(
      "#mensajeVendedor",
      "Tu usuario no tiene permisos para acceder al panel de vendedor.",
      "error"
    );

    setTimeout(function () {
      window.location.href = "elegir-rol.html";
    }, 1200);

    return;
  }

  activarNavegacionVendedor();

  try {
    await cargarDatosVendedor();

    prepararWalletActual();
    poblarClientesDestino();

    renderizarTodoVendedor();
    activarEventosVendedor();

    console.log("Panel vendedor inicializado correctamente.", VendedorApp);
  } catch (error) {
    console.error("Error inicializando vendedor:", error);

    LB.mostrarAlerta(
      "#mensajeVendedor",
      "Ocurrió un error cargando el panel vendedor. Revisa consola y rutas JSON.",
      "error"
    );
  }
}

/* =========================================================
   5. Validar acceso al módulo vendedor
   ========================================================= */

function usuarioTieneAccesoVendedor() {
  const usuario = VendedorApp.usuarioActual;

  if (!usuario || !Array.isArray(usuario.roles)) {
    return false;
  }

  return usuario.roles.includes("VENDEDOR");
}


/* =========================================================
   6. Cargar datos desde JSON y localStorage
   ========================================================= */

async function cargarDatosVendedor() {
  LB.renderizarCargando("#resumenVendedor", "Cargando información del vendedor...");

  const usuariosJSON = await cargarJSONSeguro("usuarios.json");
  const walletsJSON = await cargarJSONSeguro("wallets.json");
  const movimientosJSON = await cargarJSONSeguro("movimientos.json");
  const solicitudesJSON = await cargarJSONSeguro("solicitudes.json");

  VendedorApp.usuarios = asegurarArray(usuariosJSON);

  VendedorApp.wallets = obtenerDatosPersistidos(
    VENDEDOR_STORAGE.WALLETS,
    asegurarArray(walletsJSON)
  );

  VendedorApp.movimientos = obtenerDatosPersistidos(
    VENDEDOR_STORAGE.MOVIMIENTOS,
    asegurarArray(movimientosJSON)
  );

  VendedorApp.solicitudes = obtenerDatosPersistidos(
    VENDEDOR_STORAGE.SOLICITUDES,
    asegurarArray(solicitudesJSON)
  ).map(normalizarSolicitudVendedor);

  simularConversionAutomaticaSolicitudes();
  guardarDatosVendedor();

  console.log("Datos cargados para vendedor:", {
    usuarios: VendedorApp.usuarios.length,
    wallets: VendedorApp.wallets.length,
    movimientos: VendedorApp.movimientos.length,
    solicitudes: VendedorApp.solicitudes.length
  });
}

/* =========================================================
   7. Obtener datos persistidos en localStorage
   ========================================================= */

function obtenerDatosPersistidos(clave, datosIniciales) {
  try {
    const datosGuardados = localStorage.getItem(clave);

    if (datosGuardados) {
      const parseado = JSON.parse(datosGuardados);

      if (Array.isArray(parseado)) {
        return parseado;
      }

      console.warn(`La clave ${clave} no contiene un arreglo. Se reiniciará.`);
    }

    const datosSeguros = asegurarArray(datosIniciales);
    localStorage.setItem(clave, JSON.stringify(datosSeguros));
    return datosSeguros;
  } catch (error) {
    console.error("Error al obtener datos persistidos:", error);

    const datosSeguros = asegurarArray(datosIniciales);
    localStorage.setItem(clave, JSON.stringify(datosSeguros));
    return datosSeguros;
  }
}


function asegurarArray(datos) {
  return Array.isArray(datos) ? datos : [];
}


async function cargarJSONSeguro(nombreArchivo) {
  try {
    const datos = await LB.cargarJSON(nombreArchivo);

    if (!Array.isArray(datos)) {
      console.warn(`El archivo ${nombreArchivo} no devolvió un arreglo.`);
      return [];
    }

    return datos;
  } catch (error) {
    console.error(`No se pudo cargar data/${nombreArchivo}:`, error);
    return [];
  }
}


function leerArrayLocalStorage(clave, valorDefecto = []) {
  try {
    const datos = localStorage.getItem(clave);

    if (!datos) {
      return valorDefecto;
    }

    const parseado = JSON.parse(datos);

    return Array.isArray(parseado) ? parseado : valorDefecto;
  } catch (error) {
    console.error(`Error leyendo ${clave}:`, error);
    return valorDefecto;
  }
}
/* =========================================================
   Normalizar solicitud para vendedor

   Si no tiene fechaExpiracion, se calcula:
   fechaCreacion + 10 minutos.
   ========================================================= */

function normalizarSolicitudVendedor(solicitud) {
  return {
    ...solicitud,
    fechaExpiracion:
      solicitud.fechaExpiracion ||
      calcularFechaExpiracionDesdeFecha(solicitud.fechaCreacion),
    saldoRealReservado:
      solicitud.saldoRealReservado !== undefined
        ? solicitud.saldoRealReservado
        : true
  };
}


function calcularFechaExpiracionDesdeFecha(fechaBase) {
  const fecha = new Date(fechaBase);

  if (Number.isNaN(fecha.getTime())) {
    const ahora = new Date();
    ahora.setMinutes(ahora.getMinutes() + 10);
    return ahora.toISOString();
  }

  fecha.setMinutes(fecha.getMinutes() + 10);
  return fecha.toISOString();
}

/* =========================================================
   Conversión automática por sistema

   Si una solicitud PENDIENTE pasa de 10 minutos:
   - desaparece de la lista de vendedores
   - cliente recibe saldo virtual
   - se consume saldo real reservado
   - se registra movimiento
   ========================================================= */

function simularConversionAutomaticaSolicitudes() {
  const ahora = new Date();
  let huboCambios = false;

  VendedorApp.solicitudes.forEach(function (solicitud) {
    if (solicitud.estado !== "PENDIENTE") {
      return;
    }

    const fechaExpiracion = new Date(
      solicitud.fechaExpiracion ||
      calcularFechaExpiracionDesdeFecha(solicitud.fechaCreacion)
    );

    if (Number.isNaN(fechaExpiracion.getTime())) {
      return;
    }

    if (ahora < fechaExpiracion) {
      return;
    }

    completarSolicitudPorSistemaVendedor(solicitud);
    huboCambios = true;
  });

  if (huboCambios) {
    guardarDatosVendedor();
  }

  return huboCambios;
}


function completarSolicitudPorSistemaVendedor(solicitud) {
  const walletCliente = obtenerOCrearWalletCliente(solicitud.clienteId);
  const monto = redondearDinero(solicitud.montoSolicitado);

  walletCliente.saldoRealReservado = redondearDinero(
    Math.max(0, Number(walletCliente.saldoRealReservado || 0) - monto)
  );

  walletCliente.saldoVirtual = redondearDinero(
    Number(walletCliente.saldoVirtual || 0) + monto
  );

  walletCliente.ultimaActualizacion = new Date().toISOString();

  solicitud.estado = "COMPLETADA_SISTEMA";
  solicitud.vendedorId = "SISTEMA";
  solicitud.fechaResolucion = new Date().toISOString();
  solicitud.saldoRealReservado = false;
  solicitud.observacion =
    "Solicitud completada automáticamente por el sistema al pasar 10 minutos sin vendedor.";

  VendedorApp.movimientos.push({
    id: generarId("MOV"),
    usuarioId: solicitud.clienteId,
    walletId: walletCliente.id,
    tipoMovimiento: "CONVERSION_AUTOMATICA_SISTEMA",
    tipoDinero: "REAL_VIRTUAL",
    monto: monto,
    comision: 0,
    montoNeto: monto,
    descripcion: `Conversión automática por sistema de la solicitud ${solicitud.id}.`,
    fecha: new Date().toISOString(),
    estado: "COMPLETADO",
    referenciaId: solicitud.id
  });
}

/* =========================================================
   8. Guardar cambios de la demo
   ========================================================= */

function guardarDatosVendedor() {
  localStorage.setItem(VENDEDOR_STORAGE.WALLETS, JSON.stringify(VendedorApp.wallets));
  localStorage.setItem(VENDEDOR_STORAGE.MOVIMIENTOS, JSON.stringify(VendedorApp.movimientos));
  localStorage.setItem(VENDEDOR_STORAGE.SOLICITUDES, JSON.stringify(VendedorApp.solicitudes));
}


/* =========================================================
   9. Preparar wallet del vendedor actual
   ========================================================= */

function prepararWalletActual() {
  VendedorApp.walletActual = VendedorApp.wallets.find(function (wallet) {
    return wallet.usuarioId === VendedorApp.usuarioActual.id;
  });

  if (!VendedorApp.walletActual) {
    VendedorApp.walletActual = {
      id: generarId("WAL"),
      usuarioId: VendedorApp.usuarioActual.id,
      tipoUsuario: "VENDEDOR",
      saldoReal: 0,
      saldoVirtual: 0,
      saldoRealReservado: 0,
      saldoVirtualReservado: 0,
      gananciasGeneradas: 0,
      moneda: "USD",
      estado: "ACTIVA",
      ultimaActualizacion: new Date().toISOString()
    };

    VendedorApp.wallets.push(VendedorApp.walletActual);
    guardarDatosVendedor();
  }
}


/* =========================================================
   10. Navegación interna por secciones
   ========================================================= */

function activarNavegacionVendedor() {
  const enlaces = document.querySelectorAll("[data-tab]");
  const vistas = document.querySelectorAll(".vista-vendedor");

  function mostrarVistaVendedor(tab) {
    enlaces.forEach(function (item) {
      item.classList.toggle("activo", item.getAttribute("data-tab") === tab);
    });

    vistas.forEach(function (vista) {
      const vistaActual = vista.getAttribute("data-vista");
      vista.classList.toggle("oculto", vistaActual !== tab);
    });

    /*
      Cierre seguro del menú móvil.
      Si main.js tiene funciones de overlay, se usan.
      Si no existen, no rompe el panel.
    */
    if (typeof cerrarMenuMovilApp === "function") {
      cerrarMenuMovilApp();
    } else {
      document.body.classList.remove("menu-app-abierto");

      const botonMenu = document.querySelector(".btn-menu-movil");
      if (botonMenu) {
        botonMenu.setAttribute("aria-expanded", "false");
      }
    }

    if (typeof actualizarTituloMenuMovilApp === "function") {
      actualizarTituloMenuMovilApp();
    } else {
      const tituloMenu = document.querySelector(".menu-movil-titulo");
      const enlaceActivo = document.querySelector(".layout-app .sidebar [data-tab].activo");

      if (tituloMenu && enlaceActivo) {
        tituloMenu.textContent = enlaceActivo.textContent.trim();
      }
    }
  }

  enlaces.forEach(function (enlace) {
    enlace.addEventListener("click", function (evento) {
      evento.preventDefault();

      const tab = enlace.getAttribute("data-tab");
      mostrarVistaVendedor(tab);
    });
  });

  mostrarVistaVendedor("resumen");
}


/* =========================================================
   11. Renderizar todo
   ========================================================= */

function renderizarTodoVendedor() {
  renderizarSeguro(renderizarResumenVendedor, "Resumen vendedor");
  renderizarSeguro(renderizarWalletVendedor, "Wallet vendedor");
  renderizarSeguro(renderizarMovimientosVendedor, "Movimientos vendedor");
  renderizarSeguro(renderizarSolicitudesVendedor, "Solicitudes vendedor");
  renderizarSeguro(renderizarInfoUsuarioVendedor, "Información vendedor");
  renderizarSeguro(poblarClientesDestino, "Clientes destino");
}


function renderizarSeguro(callback, nombre) {
  try {
    callback();
  } catch (error) {
    console.error(`Error renderizando ${nombre}:`, error);
  }
}


/* =========================================================
   12. Renderizar resumen
   ========================================================= */

function renderizarResumenVendedor() {
  const solicitudesVisibles = obtenerSolicitudesVisibles();
  const solicitudesPendientes = solicitudesVisibles.filter(function (solicitud) {
    return solicitud.estado === "PENDIENTE";
  });

  const solicitudesEnProceso = solicitudesVisibles.filter(function (solicitud) {
    return solicitud.estado === "EN_PROCESO" &&
      solicitud.vendedorId === VendedorApp.usuarioActual.id;
  });

  const gananciaPotencial = Number(VendedorApp.walletActual.gananciasGeneradas || 0);

  const html = `
    <div class="resumen-grid">
      <article class="resumen-card">
        <span>Saldo real</span>
        <strong>${LB.formatearMoneda(VendedorApp.walletActual.saldoReal)}</strong>
        <p>Disponible para comprar virtual o retirar.</p>
      </article>

      <article class="resumen-card">
        <span>Saldo virtual</span>
        <strong>${LB.formatearMoneda(VendedorApp.walletActual.saldoVirtual)}</strong>
        <p>Disponible para atender solicitudes.</p>
      </article>

      <article class="resumen-card">
        <span>Solicitudes disponibles</span>
        <strong>${solicitudesPendientes.length}</strong>
        <p>Filtradas por saldo virtual suficiente.</p>
      </article>

      <article class="resumen-card">
        <span>Ganancia potencial</span>
        <strong>${LB.formatearMoneda(gananciaPotencial)}</strong>
        <p>Generada por la compra virtual 0.90 a 1.</p>
      </article>
    </div>

    <div class="alerta alerta-advertencia">
      Regla antifraude: el vendedor no puede comprar boletos, no puede participar
      en sorteos y no puede atender solicitudes propias.
    </div>

    ${
      solicitudesEnProceso.length > 0
        ? `<div class="alerta alerta-info">Tienes ${solicitudesEnProceso.length} solicitud(es) en proceso.</div>`
        : ""
    }
  `;

  LB.renderizarHTML("#resumenVendedor", html);
}


/* =========================================================
   13. Renderizar wallet
   ========================================================= */

function renderizarWalletVendedor() {
  const html = `
    <div class="resumen-grid">
      <article class="resumen-card">
        <span>Saldo real</span>
        <strong>${LB.formatearMoneda(VendedorApp.walletActual.saldoReal)}</strong>
        <p>Dinero real disponible.</p>
      </article>

      <article class="resumen-card">
        <span>Saldo virtual</span>
        <strong>${LB.formatearMoneda(VendedorApp.walletActual.saldoVirtual)}</strong>
        <p>Dinero virtual para atender clientes.</p>
      </article>

      <article class="resumen-card">
        <span>Virtual reservado</span>
        <strong>${LB.formatearMoneda(VendedorApp.walletActual.saldoVirtualReservado || 0)}</strong>
        <p>Saldo comprometido en procesos simulados.</p>
      </article>

      <article class="resumen-card">
        <span>Última actualización</span>
        <strong>${LB.formatearFecha(VendedorApp.walletActual.ultimaActualizacion)}</strong>
        <p>Último cambio visual.</p>
      </article>
    </div>
  `;

  LB.renderizarHTML("#walletVendedor", html);
}


/* =========================================================
   14. Renderizar movimientos
   ========================================================= */

function renderizarMovimientosVendedor() {
  const filtro = document.querySelector("#filtroMovimientoVendedor")?.value || "TODOS";

  let movimientos = VendedorApp.movimientos.filter(function (movimiento) {
    return movimiento.usuarioId === VendedorApp.usuarioActual.id;
  });

  if (filtro !== "TODOS") {
    movimientos = movimientos.filter(function (movimiento) {
      return String(movimiento.tipoDinero).includes(filtro);
    });
  }

  movimientos.sort(function (a, b) {
    return new Date(b.fecha) - new Date(a.fecha);
  });

  const tabla = LB.crearTabla(
    [
      {
        clave: "fecha",
        titulo: "Fecha",
        render: function (valor) {
          return LB.formatearFechaHora(valor);
        }
      },
      {
        clave: "tipoMovimiento",
        titulo: "Movimiento",
        render: function (valor) {
          return LB.escaparHTML(String(valor).replaceAll("_", " "));
        }
      },
      {
        clave: "tipoDinero",
        titulo: "Tipo"
      },
      {
        clave: "monto",
        titulo: "Monto",
        render: function (valor) {
          return LB.formatearMoneda(valor);
        }
      },
      {
        clave: "comision",
        titulo: "Comisión",
        render: function (valor) {
          return LB.formatearMoneda(valor || 0);
        }
      },
      {
        clave: "montoNeto",
        titulo: "Neto",
        render: function (valor) {
          return LB.formatearMoneda(valor || 0);
        }
      },
      {
        clave: "estado",
        titulo: "Estado",
        render: function (valor) {
          return LB.crearBadgeEstado(valor);
        }
      }
    ],
    movimientos
  );

  LB.renderizarHTML("#tablaMovimientosVendedor", tabla);
}


/* =========================================================
   15. Acreditar dinero real con tarjeta, comisión 5%
   ========================================================= */

function acreditarDineroRealVendedor(montoPagado) {
  const comision = redondearDinero(montoPagado * 0.05);
  const montoNeto = redondearDinero(montoPagado - comision);

  VendedorApp.walletActual.saldoReal = redondearDinero(
    VendedorApp.walletActual.saldoReal + montoNeto
  );

  VendedorApp.walletActual.ultimaActualizacion = new Date().toISOString();

  agregarMovimientoVendedor({
    tipoMovimiento: "ACREDITACION_TARJETA",
    tipoDinero: "REAL",
    monto: montoPagado,
    comision: comision,
    montoNeto: montoNeto,
    descripcion: "Acreditación simulada con tarjeta para vendedor. Comisión del 5%.",
    estado: "COMPLETADO",
    referenciaId: null
  });

  guardarDatosVendedor();
  renderizarTodoVendedor();

  mostrarMensajeVendedor(
    `Acreditación realizada. Comisión: ${LB.formatearMoneda(comision)}. Saldo real acreditado: ${LB.formatearMoneda(montoNeto)}.`,
    "exito"
  );
}


/* =========================================================
   16. Comprar dinero virtual con regla 0.90
   ========================================================= */

function comprarDineroVirtualVendedor(montoVirtual) {
  const costoReal = redondearDinero(montoVirtual * 0.90);
  const gananciaPotencial = redondearDinero(montoVirtual - costoReal);

  if (VendedorApp.walletActual.saldoReal < costoReal) {
    mostrarMensajeVendedor(
      `Saldo real insuficiente. Necesitas ${LB.formatearMoneda(costoReal)} para comprar ${LB.formatearMoneda(montoVirtual)} virtuales.`,
      "error"
    );
    return;
  }

  VendedorApp.walletActual.saldoReal = redondearDinero(
    VendedorApp.walletActual.saldoReal - costoReal
  );

  VendedorApp.walletActual.saldoVirtual = redondearDinero(
    VendedorApp.walletActual.saldoVirtual + montoVirtual
  );

  VendedorApp.walletActual.gananciasGeneradas = redondearDinero(
    Number(VendedorApp.walletActual.gananciasGeneradas || 0) + gananciaPotencial
  );

  VendedorApp.walletActual.ultimaActualizacion = new Date().toISOString();

  agregarMovimientoVendedor({
    tipoMovimiento: "COMPRA_VIRTUAL_VENDEDOR",
    tipoDinero: "REAL_VIRTUAL",
    monto: montoVirtual,
    comision: 0,
    montoNeto: montoVirtual,
    costoRealVendedor: costoReal,
    gananciaPotencial: gananciaPotencial,
    descripcion: `Compra de ${LB.formatearMoneda(montoVirtual)} virtuales pagando ${LB.formatearMoneda(costoReal)} reales.`,
    estado: "COMPLETADO",
    referenciaId: null
  });

  guardarDatosVendedor();
  renderizarTodoVendedor();

  mostrarMensajeVendedor(
    `Compra exitosa. Pagaste ${LB.formatearMoneda(costoReal)} reales y recibiste ${LB.formatearMoneda(montoVirtual)} virtuales.`,
    "exito"
  );
}


/* =========================================================
   17. Convertir virtual a real con comisión 15%
   ========================================================= */

function convertirVirtualARealVendedor(monto) {
  if (VendedorApp.walletActual.saldoVirtual < monto) {
    mostrarMensajeVendedor("Saldo virtual insuficiente para convertir.", "error");
    return;
  }

  const comision = redondearDinero(monto * 0.15);
  const montoNeto = redondearDinero(monto - comision);

  VendedorApp.walletActual.saldoVirtual = redondearDinero(
    VendedorApp.walletActual.saldoVirtual - monto
  );

  VendedorApp.walletActual.saldoReal = redondearDinero(
    VendedorApp.walletActual.saldoReal + montoNeto
  );

  VendedorApp.walletActual.ultimaActualizacion = new Date().toISOString();

  agregarMovimientoVendedor({
    tipoMovimiento: "CONVERSION_VIRTUAL_A_REAL",
    tipoDinero: "VIRTUAL_REAL",
    monto: monto,
    comision: comision,
    montoNeto: montoNeto,
    descripcion: "Conversión de virtual a real con comisión del 15%.",
    estado: "COMPLETADO",
    referenciaId: null
  });

  guardarDatosVendedor();
  renderizarTodoVendedor();

  mostrarMensajeVendedor(
    `Conversión realizada. Comisión: ${LB.formatearMoneda(comision)}. Recibes: ${LB.formatearMoneda(montoNeto)} reales.`,
    "exito"
  );
}


/* =========================================================
   18. Retirar dinero real
   ========================================================= */

function retirarDineroRealVendedor(monto) {
  if (VendedorApp.walletActual.saldoReal < monto) {
    mostrarMensajeVendedor("Saldo real insuficiente para retirar.", "error");
    return;
  }

  VendedorApp.walletActual.saldoReal = redondearDinero(
    VendedorApp.walletActual.saldoReal - monto
  );

  VendedorApp.walletActual.ultimaActualizacion = new Date().toISOString();

  agregarMovimientoVendedor({
    tipoMovimiento: "RETIRO_REAL_VENDEDOR",
    tipoDinero: "REAL",
    monto: monto,
    comision: 0,
    montoNeto: monto,
    descripcion: "Retiro simulado de dinero real del vendedor.",
    estado: "COMPLETADO",
    referenciaId: null
  });

  guardarDatosVendedor();
  renderizarTodoVendedor();

  mostrarMensajeVendedor(
    `Retiro simulado realizado por ${LB.formatearMoneda(monto)}.`,
    "exito"
  );
}


/* =========================================================
   19. Obtener solicitudes visibles para el vendedor
   ========================================================= */

function obtenerSolicitudesVisibles() {
  const ahora = new Date();

  return VendedorApp.solicitudes.filter(function (solicitud) {
    const esPropia = solicitud.clienteId === VendedorApp.usuarioActual.id;
    const asignadaAlVendedor = solicitud.vendedorId === VendedorApp.usuarioActual.id;

    const fechaExpiracion = new Date(
      solicitud.fechaExpiracion ||
      calcularFechaExpiracionDesdeFecha(solicitud.fechaCreacion)
    );

    const noExpirada =
      !Number.isNaN(fechaExpiracion.getTime()) &&
      ahora < fechaExpiracion;

    if (esPropia) {
      return false;
    }

    if (solicitud.estado === "COMPLETADA_SISTEMA") {
      return false;
    }

    if (asignadaAlVendedor && solicitud.estado === "EN_PROCESO") {
      return true;
    }

    if (solicitud.estado === "PENDIENTE") {
      return (
        noExpirada &&
        Number(solicitud.montoSolicitado || 0) <=
          Number(VendedorApp.walletActual.saldoVirtual || 0)
      );
    }

    return false;
  });
}


/* =========================================================
   20. Renderizar solicitudes
   ========================================================= */

function renderizarSolicitudesVendedor() {
  simularConversionAutomaticaSolicitudes();
  guardarDatosVendedor();

  const filtro = document.querySelector("#filtroEstadoSolicitudVendedor")?.value || "TODOS";

  let solicitudes = obtenerSolicitudesVisibles();

  if (filtro !== "TODOS") {
    solicitudes = solicitudes.filter(function (solicitud) {
      return solicitud.estado === filtro;
    });
  }

  solicitudes.sort(function (a, b) {
    return new Date(a.fechaExpiracion) - new Date(b.fechaExpiracion);
  });

  if (solicitudes.length === 0) {
    LB.renderizarSinDatos(
      "#listaSolicitudesVendedor",
      "No hay solicitudes disponibles para tu saldo virtual actual."
    );
    return;
  }

  const html = solicitudes
    .map(function (solicitud) {
      return crearTarjetaSolicitud(solicitud);
    })
    .join("");

  LB.renderizarHTML(
    "#listaSolicitudesVendedor",
    `<div class="grid-tarjetas">${html}</div>`
  );

  activarBloqueosSolicitudes();
  iniciarContadorCaducidadSolicitudes();
}


/* =========================================================
   21. Crear tarjeta de solicitud
   ========================================================= */

function crearTarjetaSolicitud(solicitud) {
  const cliente = VendedorApp.usuarios.find(function (usuario) {
    return usuario.id === solicitud.clienteId;
  });

  const clienteNombre = cliente
    ? `${cliente.nombres} ${cliente.apellidos}`
    : "Cliente no encontrado";

  const asignadaAlActual = solicitud.vendedorId === VendedorApp.usuarioActual.id;

  let acciones = "";

  if (solicitud.estado === "PENDIENTE") {
    acciones = `
      <button
        type="button"
        class="btn-principal"
        data-tomar-solicitud="${LB.escaparHTML(solicitud.id)}"
      >
        Tomar solicitud
      </button>
    `;
  }

  if (solicitud.estado === "EN_PROCESO" && asignadaAlActual) {
    acciones = `
      <div class="alerta alerta-info" id="bloqueo-${LB.escaparHTML(solicitud.id)}">
        Seguridad visual: espere 10 segundos para confirmar o cancelar.
      </div>

      <button
        type="button"
        class="btn-exito"
        data-confirmar-solicitud="${LB.escaparHTML(solicitud.id)}"
        disabled
      >
        Confirmar
      </button>

      <button
        type="button"
        class="btn-peligro"
        data-cancelar-solicitud="${LB.escaparHTML(solicitud.id)}"
        disabled
      >
        Cancelar
      </button>
    `;
  }

  return `
    <article class="tarjeta">
      ${LB.crearBadgeEstado(solicitud.estado)}

      <h3>Solicitud ${LB.escaparHTML(solicitud.id)}</h3>

      <p><strong>Cliente:</strong> ${LB.escaparHTML(clienteNombre)}</p>
      <p><strong>Monto solicitado:</strong> ${LB.formatearMoneda(solicitud.montoSolicitado)}</p>
      <p><strong>Fecha creación:</strong> ${LB.formatearFechaHora(solicitud.fechaCreacion)}</p>
      <p><strong>Expira:</strong> ${LB.formatearFechaHora(solicitud.fechaExpiracion)}</p>
      <p>
        <strong>Caduca en:</strong>
        <span
          class="contador-caducidad-solicitud"
          data-expira="${LB.escaparHTML(solicitud.fechaExpiracion)}"
        >
          Calculando...
        </span>
      </p><p><strong>Tiempo de seguridad:</strong> ${solicitud.segundosBloqueoBotones || 10} segundos</p>

      ${
        solicitud.vendedorId
          ? `<p><strong>Vendedor asignado:</strong> ${LB.escaparHTML(solicitud.vendedorId)}</p>`
          : `<p><strong>Vendedor asignado:</strong> Ninguno</p>`
      }

      <p>${LB.escaparHTML(solicitud.observacion || "Sin observación.")}</p>

      <div class="hero-botones">
        ${acciones}
      </div>
    </article>
  `;
}


/* =========================================================
   22. Tomar solicitud
   ========================================================= */

function tomarSolicitud(solicitudId) {
  const solicitud = buscarSolicitud(solicitudId);

  if (!solicitud) {
    mostrarMensajeVendedor("No se encontró la solicitud.", "error");
    return;
  }

  if (solicitud.estado !== "PENDIENTE") {
    mostrarMensajeVendedor("La solicitud ya no está pendiente.", "advertencia");
    return;
  }

  if (solicitud.clienteId === VendedorApp.usuarioActual.id) {
    mostrarMensajeVendedor("No puedes atender una solicitud propia.", "error");
    return;
  }

  if (solicitud.montoSolicitado > VendedorApp.walletActual.saldoVirtual) {
    mostrarMensajeVendedor("Saldo virtual insuficiente para tomar esta solicitud.", "error");
    return;
  }

  solicitud.estado = "EN_PROCESO";
  solicitud.vendedorId = VendedorApp.usuarioActual.id;
  solicitud.fechaAsignacion = new Date().toISOString();
  solicitud.timerAtencionInicio = new Date().toISOString();
  solicitud.bloqueoBotonesInicio = new Date().toISOString();
  solicitud.fechaResolucion = null;
  solicitud.observacion = "Solicitud tomada por vendedor. Botones bloqueados temporalmente por seguridad visual.";

  guardarDatosVendedor();
  renderizarTodoVendedor();

  mostrarMensajeVendedor(
    "Solicitud tomada correctamente. Espere 10 segundos para confirmar o cancelar.",
    "exito"
  );
}


/* =========================================================
   23. Confirmar solicitud

   Regla:
   saldoVirtualVendedor -= monto
   saldoVirtualCliente += monto
   saldoRealVendedor += monto
   solicitud pasa a COMPLETADA
   ========================================================= */

function confirmarSolicitud(solicitudId) {
  const solicitud = buscarSolicitud(solicitudId);

  if (!validarSolicitudEnProceso(solicitud)) {
    return;
  }

  const monto = redondearDinero(solicitud.montoSolicitado);

  if (VendedorApp.walletActual.saldoVirtual < monto) {
    mostrarMensajeVendedor("Saldo virtual insuficiente para confirmar.", "error");
    return;
  }

  const walletCliente = obtenerOCrearWalletCliente(solicitud.clienteId);

  VendedorApp.walletActual.saldoVirtual = redondearDinero(
    VendedorApp.walletActual.saldoVirtual - monto
  );

  VendedorApp.walletActual.saldoReal = redondearDinero(
    VendedorApp.walletActual.saldoReal + monto
  );

  walletCliente.saldoVirtual = redondearDinero(
    walletCliente.saldoVirtual + monto
  );

  if (walletCliente.saldoRealReservado && walletCliente.saldoRealReservado > 0) {
    walletCliente.saldoRealReservado = redondearDinero(
      Math.max(0, walletCliente.saldoRealReservado - monto)
    );
  }

  VendedorApp.walletActual.ultimaActualizacion = new Date().toISOString();
  walletCliente.ultimaActualizacion = new Date().toISOString();

  solicitud.estado = "COMPLETADA";
  solicitud.fechaResolucion = new Date().toISOString();
  solicitud.saldoRealReservado = false;
  solicitud.observacion = "Solicitud completada. El vendedor entregó virtual y recibió real equivalente.";

  agregarMovimientoVendedor({
    tipoMovimiento: "ATENCION_SOLICITUD_CLIENTE",
    tipoDinero: "VIRTUAL_REAL",
    monto: monto,
    comision: 0,
    montoNeto: monto,
    descripcion: `Atención completada de solicitud ${solicitud.id}.`,
    estado: "COMPLETADO",
    referenciaId: solicitud.id
  });

  VendedorApp.movimientos.push({
    id: generarId("MOV"),
    usuarioId: solicitud.clienteId,
    walletId: walletCliente.id,
    tipoMovimiento: "RECEPCION_VIRTUAL_SOLICITUD",
    tipoDinero: "VIRTUAL",
    monto: monto,
    comision: 0,
    montoNeto: monto,
    descripcion: `Recepción de dinero virtual por solicitud ${solicitud.id}.`,
    fecha: new Date().toISOString(),
    estado: "COMPLETADO",
    referenciaId: solicitud.id
  });

  guardarDatosVendedor();
  renderizarTodoVendedor();

  mostrarMensajeVendedor(
    `Solicitud confirmada. Entregaste ${LB.formatearMoneda(monto)} virtuales y recibiste ${LB.formatearMoneda(monto)} reales.`,
    "exito"
  );
}


/* =========================================================
   24. Cancelar solicitud

   Regla:
   - solicitud vuelve a PENDIENTE
   - vendedorId se limpia
   ========================================================= */

function cancelarSolicitud(solicitudId) {
  const solicitud = buscarSolicitud(solicitudId);

  if (!validarSolicitudEnProceso(solicitud)) {
    return;
  }

  solicitud.estado = "PENDIENTE";
  solicitud.vendedorId = null;
  solicitud.fechaAsignacion = null;
  solicitud.fechaResolucion = null;
  solicitud.observacion = "Solicitud cancelada por el vendedor. Vuelve a estar pendiente para otro vendedor.";

  agregarMovimientoVendedor({
    tipoMovimiento: "SOLICITUD_CANCELADA",
    tipoDinero: "VIRTUAL",
    monto: solicitud.montoSolicitado,
    comision: 0,
    montoNeto: 0,
    descripcion: `Cancelación de solicitud ${solicitud.id}. No se realizó transferencia.`,
    estado: "CANCELADO",
    referenciaId: solicitud.id
  });

  guardarDatosVendedor();
  renderizarTodoVendedor();

  mostrarMensajeVendedor(
    "Solicitud cancelada. La solicitud vuelve a estar pendiente.",
    "advertencia"
  );
}


/* =========================================================
   25. Validar solicitud en proceso
   ========================================================= */

function validarSolicitudEnProceso(solicitud) {
  if (!solicitud) {
    mostrarMensajeVendedor("No se encontró la solicitud.", "error");
    return false;
  }

  if (solicitud.estado !== "EN_PROCESO") {
    mostrarMensajeVendedor("La solicitud no está en proceso.", "advertencia");
    return false;
  }

  if (solicitud.vendedorId !== VendedorApp.usuarioActual.id) {
    mostrarMensajeVendedor("Esta solicitud está asignada a otro vendedor.", "error");
    return false;
  }

  return true;
}


/* =========================================================
   26. Activar bloqueo visual de 10 segundos
   ========================================================= */

function activarBloqueosSolicitudes() {
  const botonesConfirmar = document.querySelectorAll("[data-confirmar-solicitud]");

  botonesConfirmar.forEach(function (boton) {
    const solicitudId = boton.getAttribute("data-confirmar-solicitud");
    const solicitud = buscarSolicitud(solicitudId);

    if (!solicitud || solicitud.estado !== "EN_PROCESO") {
      return;
    }

    const botonCancelar = document.querySelector(`[data-cancelar-solicitud="${solicitudId}"]`);
    const contenedorBloqueo = document.getElementById(`bloqueo-${solicitudId}`);

    let segundos = Number(solicitud.segundosBloqueoBotones || 10);

    boton.disabled = true;

    if (botonCancelar) {
      botonCancelar.disabled = true;
    }

    if (VendedorApp.temporizadoresSolicitudes[solicitudId]) {
      clearInterval(VendedorApp.temporizadoresSolicitudes[solicitudId]);
    }

    VendedorApp.temporizadoresSolicitudes[solicitudId] = setInterval(function () {
      segundos--;

      if (contenedorBloqueo) {
        contenedorBloqueo.innerHTML = `Seguridad visual: botones disponibles en ${segundos} segundos.`;
      }

      if (segundos <= 0) {
        clearInterval(VendedorApp.temporizadoresSolicitudes[solicitudId]);

        boton.disabled = false;

        if (botonCancelar) {
          botonCancelar.disabled = false;
        }

        if (contenedorBloqueo) {
          contenedorBloqueo.className = "alerta alerta-exito";
          contenedorBloqueo.innerHTML = "Validación visual completada. Ya puede confirmar o cancelar.";
        }
      }
    }, 1000);
  });
}


/* =========================================================
   27. Enviar dinero virtual permitido a cliente
   ========================================================= */

function enviarVirtualACliente(clienteId, monto) {
  if (!clienteId) {
    mostrarMensajeVendedor("Seleccione un cliente destinatario.", "error");
    return;
  }

  if (clienteId === VendedorApp.usuarioActual.id) {
    mostrarMensajeVendedor("No puedes enviarte dinero a ti mismo.", "error");
    return;
  }

  if (VendedorApp.walletActual.saldoVirtual < monto) {
    mostrarMensajeVendedor("Saldo virtual insuficiente para enviar.", "error");
    return;
  }

  const cliente = VendedorApp.usuarios.find(function (usuario) {
    return usuario.id === clienteId;
  });

  if (!cliente) {
    mostrarMensajeVendedor("No se encontró el cliente destinatario.", "error");
    return;
  }

  const walletCliente = obtenerOCrearWalletCliente(clienteId);

  VendedorApp.walletActual.saldoVirtual = redondearDinero(
    VendedorApp.walletActual.saldoVirtual - monto
  );

  walletCliente.saldoVirtual = redondearDinero(
    walletCliente.saldoVirtual + monto
  );

  VendedorApp.walletActual.ultimaActualizacion = new Date().toISOString();
  walletCliente.ultimaActualizacion = new Date().toISOString();

  agregarMovimientoVendedor({
    tipoMovimiento: "ENVIO_VIRTUAL_A_CLIENTE",
    tipoDinero: "VIRTUAL",
    monto: monto,
    comision: 0,
    montoNeto: monto,
    descripcion: `Envío permitido de dinero virtual al cliente ${cliente.usuario}.`,
    estado: "COMPLETADO",
    referenciaId: clienteId
  });

  VendedorApp.movimientos.push({
    id: generarId("MOV"),
    usuarioId: clienteId,
    walletId: walletCliente.id,
    tipoMovimiento: "RECEPCION_VIRTUAL_DESDE_VENDEDOR",
    tipoDinero: "VIRTUAL",
    monto: monto,
    comision: 0,
    montoNeto: monto,
    descripcion: `Recepción de dinero virtual desde vendedor ${VendedorApp.usuarioActual.usuario}.`,
    fecha: new Date().toISOString(),
    estado: "COMPLETADO",
    referenciaId: VendedorApp.usuarioActual.id
  });

  guardarDatosVendedor();
  renderizarTodoVendedor();

  mostrarMensajeVendedor(
    `Envío realizado correctamente a ${cliente.nombres}.`,
    "exito"
  );
}


/* =========================================================
   28. Poblar clientes destino
   ========================================================= */

function poblarClientesDestino() {
  const select = document.querySelector("#clienteDestinoVendedor");

  if (!select) {
    return;
  }

  const clientes = VendedorApp.usuarios.filter(function (usuario) {
    return (
      usuario.id !== VendedorApp.usuarioActual.id &&
      usuario.estado === "ACTIVO" &&
      Array.isArray(usuario.roles) &&
      usuario.roles.includes("CLIENTE")
    );
  });

  const opciones = clientes
    .map(function (cliente) {
      return `
        <option value="${LB.escaparHTML(cliente.id)}">
          ${LB.escaparHTML(cliente.nombres)} ${LB.escaparHTML(cliente.apellidos)} - ${LB.escaparHTML(cliente.usuario)}
        </option>
      `;
    })
    .join("");

  select.innerHTML = `
    <option value="">Seleccione un cliente</option>
    ${opciones}
  `;
}


/* =========================================================
   29. Obtener o crear wallet de cliente
   ========================================================= */

function obtenerOCrearWalletCliente(clienteId) {
  let walletCliente = VendedorApp.wallets.find(function (wallet) {
    return wallet.usuarioId === clienteId;
  });

  if (!walletCliente) {
    walletCliente = {
      id: generarId("WAL"),
      usuarioId: clienteId,
      tipoUsuario: "CLIENTE",
      saldoReal: 0,
      saldoVirtual: 0,
      saldoRealReservado: 0,
      saldoVirtualReservado: 0,
      gananciasGeneradas: 0,
      moneda: "USD",
      estado: "ACTIVA",
      ultimaActualizacion: new Date().toISOString()
    };

    VendedorApp.wallets.push(walletCliente);
  }

  return walletCliente;
}


/* =========================================================
   30. Renderizar información del usuario
   ========================================================= */

function renderizarInfoUsuarioVendedor() {
  const usuario = VendedorApp.usuarioActual;
  const modo = VendedorApp.modoAcceso || VendedorApp.rolActivo || usuario.rolPrincipal;

  const html = `
    <div class="grid-tarjetas">
      <article class="tarjeta">
        <span class="badge badge-info">Datos personales</span>
        <h3>${LB.escaparHTML(usuario.nombres)} ${LB.escaparHTML(usuario.apellidos)}</h3>
        <p><strong>Documento:</strong> ${LB.escaparHTML(usuario.documento)}</p>
        <p><strong>Correo:</strong> ${LB.escaparHTML(usuario.correo)}</p>
        <p><strong>Teléfono:</strong> ${LB.escaparHTML(usuario.telefono)}</p>
      </article>

      <article class="tarjeta">
        <span class="badge badge-dorado">Acceso</span>
        <h3>Rol y modo</h3>
        <p><strong>Rol real:</strong> ${LB.escaparHTML(usuario.rolPrincipal)}</p>
        <p><strong>Modo actual:</strong> ${LB.escaparHTML(modo)}</p>
        <p><strong>Estado:</strong> ${LB.crearBadgeEstado(usuario.estado)}</p>
      </article>

      <article class="tarjeta">
        <span class="badge badge-cancelada">Restricciones</span>
        <h3>Reglas antifraude</h3>
        <p>No puede comprar boletos.</p>
        <p>No puede participar en sorteos.</p>
        <p>No puede atender solicitudes propias.</p>
      </article>
    </div>
  `;

  LB.renderizarHTML("#infoUsuarioVendedor", html);
}


/* =========================================================
   31. Activar eventos
   ========================================================= */

function activarEventosVendedor() {
  activarFormularioAcreditarReal();
  activarFormularioComprarVirtual();
  activarFormularioVirtualReal();
  activarFormularioRetiroReal();
  activarFormularioEnviarVirtual();
  activarFiltrosVendedor();
  activarPreviewCompraVirtual();
  activarPreviewVirtualReal();

  document.addEventListener("click", function (evento) {
    const botonTomar = evento.target.closest("[data-tomar-solicitud]");
    const botonConfirmar = evento.target.closest("[data-confirmar-solicitud]");
    const botonCancelar = evento.target.closest("[data-cancelar-solicitud]");

    if (botonTomar) {
      tomarSolicitud(botonTomar.getAttribute("data-tomar-solicitud"));
    }

    if (botonConfirmar) {
      confirmarSolicitud(botonConfirmar.getAttribute("data-confirmar-solicitud"));
    }

    if (botonCancelar) {
      cancelarSolicitud(botonCancelar.getAttribute("data-cancelar-solicitud"));
    }
  });
}


/* =========================================================
   32. Formularios
   ========================================================= */

function activarFormularioAcreditarReal() {
  const form = document.querySelector("#formAcreditarRealVendedor");

  if (!form) {
    return;
  }

  form.addEventListener("submit", function (evento) {
    evento.preventDefault();

    const monto = obtenerMonto("#montoTarjetaVendedor");

    if (monto <= 0) {
      mostrarMensajeVendedor("Ingrese un monto válido para acreditar.", "error");
      return;
    }

    acreditarDineroRealVendedor(monto);
    form.reset();
  });
}


function activarFormularioComprarVirtual() {
  const form = document.querySelector("#formComprarVirtualVendedor");

  if (!form) {
    return;
  }

  form.addEventListener("submit", function (evento) {
    evento.preventDefault();

    const montoVirtual = obtenerMonto("#montoVirtualComprar");

    if (montoVirtual <= 0) {
      mostrarMensajeVendedor("Ingrese un monto virtual válido.", "error");
      return;
    }

    comprarDineroVirtualVendedor(montoVirtual);
    form.reset();
    actualizarPreviewCompraVirtual();
  });
}


function activarFormularioVirtualReal() {
  const form = document.querySelector("#formVirtualRealVendedor");

  if (!form) {
    return;
  }

  form.addEventListener("submit", function (evento) {
    evento.preventDefault();

    const monto = obtenerMonto("#montoVirtualRealVendedor");

    if (monto <= 0) {
      mostrarMensajeVendedor("Ingrese un monto válido para convertir.", "error");
      return;
    }

    convertirVirtualARealVendedor(monto);
    form.reset();
    actualizarPreviewVirtualReal();
  });
}


function activarFormularioRetiroReal() {
  const form = document.querySelector("#formRetirarRealVendedor");

  if (!form) {
    return;
  }

  form.addEventListener("submit", function (evento) {
    evento.preventDefault();

    const monto = obtenerMonto("#montoRetiroRealVendedor");

    if (monto <= 0) {
      mostrarMensajeVendedor("Ingrese un monto válido para retirar.", "error");
      return;
    }

    retirarDineroRealVendedor(monto);
    form.reset();
  });
}


function activarFormularioEnviarVirtual() {
  const form = document.querySelector("#formEnviarVirtualVendedor");

  if (!form) {
    return;
  }

  form.addEventListener("submit", function (evento) {
    evento.preventDefault();

    const clienteId = document.querySelector("#clienteDestinoVendedor")?.value || "";
    const monto = obtenerMonto("#montoEnvioVendedor");

    if (monto <= 0) {
      mostrarMensajeVendedor("Ingrese un monto válido para enviar.", "error");
      return;
    }

    enviarVirtualACliente(clienteId, monto);
    form.reset();
  });
}


/* =========================================================
   33. Filtros
   ========================================================= */

function activarFiltrosVendedor() {
  const filtroMovimiento = document.querySelector("#filtroMovimientoVendedor");
  const filtroSolicitud = document.querySelector("#filtroEstadoSolicitudVendedor");

  if (filtroMovimiento) {
    filtroMovimiento.addEventListener("change", renderizarMovimientosVendedor);
  }

  if (filtroSolicitud) {
    filtroSolicitud.addEventListener("change", renderizarSolicitudesVendedor);
  }
}


/* =========================================================
   34. Previews de cálculo
   ========================================================= */

function activarPreviewCompraVirtual() {
  const input = document.querySelector("#montoVirtualComprar");

  if (!input) {
    return;
  }

  input.addEventListener("input", actualizarPreviewCompraVirtual);
}


function actualizarPreviewCompraVirtual() {
  const contenedor = document.querySelector("#previewCompraVirtual");

  if (!contenedor) {
    return;
  }

  const montoVirtual = obtenerMonto("#montoVirtualComprar");

  if (montoVirtual <= 0) {
    contenedor.innerHTML = "Ingresa un monto para ver cuánto pagarás en dinero real.";
    return;
  }

  const costoReal = redondearDinero(montoVirtual * 0.90);
  const ganancia = redondearDinero(montoVirtual - costoReal);

  contenedor.innerHTML = `
    Recibes virtual: ${LB.formatearMoneda(montoVirtual)}<br>
    Pagas real: ${LB.formatearMoneda(costoReal)}<br>
    Ganancia potencial: ${LB.formatearMoneda(ganancia)}
  `;
}


function activarPreviewVirtualReal() {
  const input = document.querySelector("#montoVirtualRealVendedor");

  if (!input) {
    return;
  }

  input.addEventListener("input", actualizarPreviewVirtualReal);
}


function actualizarPreviewVirtualReal() {
  const contenedor = document.querySelector("#previewVirtualRealVendedor");

  if (!contenedor) {
    return;
  }

  const monto = obtenerMonto("#montoVirtualRealVendedor");

  if (monto <= 0) {
    contenedor.innerHTML = "Ingresa un monto para ver la comisión.";
    return;
  }

  const comision = redondearDinero(monto * 0.15);
  const neto = redondearDinero(monto - comision);

  contenedor.innerHTML = `
    Monto virtual: ${LB.formatearMoneda(monto)}<br>
    Comisión 15%: ${LB.formatearMoneda(comision)}<br>
    Recibes real: ${LB.formatearMoneda(neto)}
  `;
}


/* =========================================================
   35. Movimientos
   ========================================================= */

function agregarMovimientoVendedor(datos) {
  const movimiento = {
    id: generarId("MOV"),
    usuarioId: VendedorApp.usuarioActual.id,
    walletId: VendedorApp.walletActual.id,
    tipoMovimiento: datos.tipoMovimiento,
    tipoDinero: datos.tipoDinero,
    monto: redondearDinero(datos.monto),
    comision: redondearDinero(datos.comision || 0),
    montoNeto: redondearDinero(datos.montoNeto || 0),
    descripcion: datos.descripcion,
    fecha: new Date().toISOString(),
    estado: datos.estado || "COMPLETADO",
    referenciaId: datos.referenciaId || null
  };

  if (datos.costoRealVendedor !== undefined) {
    movimiento.costoRealVendedor = redondearDinero(datos.costoRealVendedor);
  }

  if (datos.gananciaPotencial !== undefined) {
    movimiento.gananciaPotencial = redondearDinero(datos.gananciaPotencial);
  }

  VendedorApp.movimientos.push(movimiento);
}


/* =========================================================
   36. Utilidades internas
   ========================================================= */

function buscarSolicitud(solicitudId) {
  return VendedorApp.solicitudes.find(function (solicitud) {
    return solicitud.id === solicitudId;
  });
}


function obtenerMonto(selector) {
  const input = document.querySelector(selector);

  if (!input) {
    return 0;
  }

  const valor = Number(input.value);

  if (Number.isNaN(valor)) {
    return 0;
  }

  return redondearDinero(valor);
}


function redondearDinero(valor) {
  return Math.round(Number(valor) * 100) / 100;
}


function generarId(prefijo) {
  return `${prefijo}-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
}


function mostrarMensajeVendedor(mensaje, tipo) {
  LB.mostrarAlerta("#mensajeVendedor", mensaje, tipo);

  window.scrollTo({
    top: 0,
    behavior: "smooth"
  });
}