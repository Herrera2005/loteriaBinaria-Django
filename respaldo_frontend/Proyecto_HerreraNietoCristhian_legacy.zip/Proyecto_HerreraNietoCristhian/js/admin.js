/* =========================================================
   Lotería Binaria - admin.js

   Archivo encargado del panel administrador.

   Funciones principales:
   - Cargar datos desde archivos JSON separados.
   - Simular cambios con localStorage.
   - Mostrar resumen general.
   - Gestionar usuarios.
   - Gestionar sorteos por módulo.
   - Mostrar solicitudes.
   - Mostrar movimientos globales.
   - Mostrar estadísticas.

   Importante:
   - No usa backend.
   - No modifica archivos JSON.
   - Usa JavaScript puro.
   ========================================================= */


/* =========================================================
   1. Validación de dependencia
   ========================================================= */

if (typeof LB === "undefined") {
  console.error("admin.js necesita que utils.js se cargue primero.");
}


/* =========================================================
   2. Estado global del administrador
   ========================================================= */

const AdminApp = {
  usuarioActual: null,
  rolActivo: null,
  modoAcceso: null,

  usuarios: [],
  sorteos: [],
  eventos: [],
  boletos: [],
  wallets: [],
  movimientos: [],
  solicitudes: []
};


/* =========================================================
   3. Claves localStorage

   Algunas claves son compartidas con cliente.js, vendedor.js
   y solicitudes.js para mantener la simulación conectada.
   ========================================================= */

const ADMIN_STORAGE = {
  USUARIOS: "loteriaBinaria_usuariosDemo",
  SORTEOS: "loteriaBinaria_sorteosDemo",
  EVENTOS: "loteriaBinaria_eventosDemo",
  BOLETOS: "loteriaBinaria_boletosDemo",
  WALLETS: "loteriaBinaria_walletsDemo",
  MOVIMIENTOS: "loteriaBinaria_movimientosDemo",
  SOLICITUDES: "loteriaBinaria_solicitudesDemo",
  ROL_ACTIVO: "loteriaBinaria_rolActivo",
  MODO_ACCESO: "loteriaBinaria_modoAcceso"
};


/* =========================================================
   4. Inicialización
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {
  inicializarAdmin();
});


async function inicializarAdmin() {
  if (typeof LB === "undefined") {
    return;
  }

  AdminApp.usuarioActual = LB.obtenerUsuarioActual();
  AdminApp.rolActivo = localStorage.getItem(ADMIN_STORAGE.ROL_ACTIVO);
  AdminApp.modoAcceso = localStorage.getItem(ADMIN_STORAGE.MODO_ACCESO);

  if (!AdminApp.usuarioActual) {
    LB.mostrarAlerta(
      "#mensajeAdmin",
      "No hay sesión activa. Redirigiendo al login...",
      "advertencia"
    );

    setTimeout(function () {
      window.location.href = "login.html";
    }, 900);

    return;
  }

  if (!usuarioTieneAccesoAdmin()) {
    LB.mostrarAlerta(
      "#mensajeAdmin",
      "Tu usuario no tiene permisos para acceder al panel administrador.",
      "error"
    );

    setTimeout(function () {
      window.location.href = "elegir-rol.html";
    }, 1200);

    return;
  }

  activarNavegacionAdmin();

  await cargarDatosAdmin();

  renderizarTodoAdmin();
  activarEventosAdmin();
}


/* =========================================================
   5. Validar acceso como administrador
   ========================================================= */

function usuarioTieneAccesoAdmin() {
  const usuario = AdminApp.usuarioActual;

  if (!usuario || !Array.isArray(usuario.roles)) {
    return false;
  }

  return usuario.roles.includes("ADMIN");
}


/* =========================================================
   6. Cargar datos desde JSON y localStorage
   ========================================================= */

async function cargarDatosAdmin() {
  LB.renderizarCargando("#resumenGeneralAdmin", "Cargando panel administrador...");

  const [
    usuariosJSON,
    sorteosJSON,
    eventosJSON,
    boletosJSON,
    walletsJSON,
    movimientosJSON,
    solicitudesJSON
  ] = await Promise.all([
    LB.cargarJSON("usuarios.json"),
    LB.cargarJSON("sorteos.json"),
    LB.cargarJSON("eventos.json"),
    LB.cargarJSON("boletos.json"),
    LB.cargarJSON("wallets.json"),
    LB.cargarJSON("movimientos.json"),
    LB.cargarJSON("solicitudes.json")
  ]);

  AdminApp.usuarios = obtenerDatosPersistidos(ADMIN_STORAGE.USUARIOS, usuariosJSON);
  AdminApp.sorteos = obtenerDatosPersistidos(ADMIN_STORAGE.SORTEOS, sorteosJSON);
  AdminApp.eventos = obtenerDatosPersistidos(ADMIN_STORAGE.EVENTOS, eventosJSON);
  AdminApp.boletos = obtenerDatosPersistidos(ADMIN_STORAGE.BOLETOS, boletosJSON);
  AdminApp.wallets = obtenerDatosPersistidos(ADMIN_STORAGE.WALLETS, walletsJSON);
  AdminApp.movimientos = obtenerDatosPersistidos(ADMIN_STORAGE.MOVIMIENTOS, movimientosJSON);
  AdminApp.solicitudes = obtenerDatosPersistidos(ADMIN_STORAGE.SOLICITUDES, solicitudesJSON);
}


/* =========================================================
   7. Obtener datos persistidos
   ========================================================= */

function obtenerDatosPersistidos(clave, datosIniciales) {
  try {
    const datosGuardados = localStorage.getItem(clave);

    if (datosGuardados) {
      return JSON.parse(datosGuardados);
    }

    localStorage.setItem(clave, JSON.stringify(datosIniciales));
    return datosIniciales;
  } catch (error) {
    console.error("Error al leer datos persistidos:", error);
    return datosIniciales;
  }
}


/* =========================================================
   8. Guardar cambios simulados
   ========================================================= */

function guardarDatosAdmin() {
  localStorage.setItem(ADMIN_STORAGE.USUARIOS, JSON.stringify(AdminApp.usuarios));
  localStorage.setItem(ADMIN_STORAGE.SORTEOS, JSON.stringify(AdminApp.sorteos));
  localStorage.setItem(ADMIN_STORAGE.EVENTOS, JSON.stringify(AdminApp.eventos));
  localStorage.setItem(ADMIN_STORAGE.BOLETOS, JSON.stringify(AdminApp.boletos));
  localStorage.setItem(ADMIN_STORAGE.WALLETS, JSON.stringify(AdminApp.wallets));
  localStorage.setItem(ADMIN_STORAGE.MOVIMIENTOS, JSON.stringify(AdminApp.movimientos));
  localStorage.setItem(ADMIN_STORAGE.SOLICITUDES, JSON.stringify(AdminApp.solicitudes));
}


/* =========================================================
   9. Navegación interna por pestañas
   ========================================================= */

function activarNavegacionAdmin() {
  const enlaces = document.querySelectorAll("[data-tab]");
  const enlacesInternos = document.querySelectorAll("[data-tab-link]");

  enlaces.forEach(function (enlace) {
    enlace.addEventListener("click", function (evento) {
      evento.preventDefault();

      const tab = enlace.getAttribute("data-tab");
      mostrarVistaAdmin(tab);
    });
  });

  enlacesInternos.forEach(function (enlace) {
    enlace.addEventListener("click", function (evento) {
      evento.preventDefault();

      const tab = enlace.getAttribute("data-tab-link");
      mostrarVistaAdmin(tab);
    });
  });

  mostrarVistaAdmin("resumen");
}


function mostrarVistaAdmin(tab) {
  const enlaces = document.querySelectorAll("[data-tab]");
  const vistas = document.querySelectorAll(".vista-admin");

  enlaces.forEach(function (item) {
    item.classList.toggle("activo", item.getAttribute("data-tab") === tab);
  });

  vistas.forEach(function (vista) {
    const vistaActual = vista.getAttribute("data-vista");
    vista.classList.toggle("oculto", vistaActual !== tab);
  });

  /*
    Estas funciones pertenecen al menú móvil tipo overlay.
    Se validan antes de llamarlas para evitar errores si main.js
    todavía no las tiene o si no existen.
  */
  if (typeof cerrarMenuMovilApp === "function") {
    cerrarMenuMovilApp();
  } else {
    document.body.classList.remove("menu-app-abierto");
  }

  if (typeof actualizarTituloMenuMovilApp === "function") {
    actualizarTituloMenuMovilApp();
  }
}


/* =========================================================
   10. Renderizar todo el panel
   ========================================================= */

function renderizarTodoAdmin() {
  renderizarResumenGeneral();
  renderizarUsuariosAdmin();
  renderizarModulosSorteos();
  renderizarSolicitudesAdmin();
  renderizarMovimientosAdmin();
  renderizarEstadisticasAdmin();
}


/* =========================================================
   11. Resumen general
   ========================================================= */

function renderizarResumenGeneral() {
  const usuariosActivos = AdminApp.usuarios.filter(function (usuario) {
    return usuario.estado !== "ELIMINADO";
  });

  const totalClientes = contarUsuariosPorRol("CLIENTE", usuariosActivos);
  const totalVendedores = contarUsuariosPorRol("VENDEDOR", usuariosActivos);
  const totalAdmins = contarUsuariosPorRol("ADMIN", usuariosActivos);

  const boletosVendidos = AdminApp.boletos.length;

  const sorteosActivos = AdminApp.sorteos.filter(function (sorteo) {
    return normalizarEstadoSorteo(sorteo) === "ACTIVO";
  }).length;

  const dineroRealSistema = sumar(AdminApp.wallets, "saldoReal");
  const dineroVirtualSistema = sumar(AdminApp.wallets, "saldoVirtual");

  const solicitudesPendientes = AdminApp.solicitudes.filter(function (solicitud) {
    return solicitud.estado === "PENDIENTE";
  }).length;

  const html = `
    <div class="resumen-grid">
      <article class="resumen-card">
        <span>Total clientes</span>
        <strong>${totalClientes}</strong>
        <p>Usuarios con rol cliente.</p>
      </article>

      <article class="resumen-card">
        <span>Total vendedores</span>
        <strong>${totalVendedores}</strong>
        <p>Usuarios con rol vendedor.</p>
      </article>

      <article class="resumen-card">
        <span>Total administradores</span>
        <strong>${totalAdmins}</strong>
        <p>Usuarios con rol administrador.</p>
      </article>

      <article class="resumen-card">
        <span>Boletos vendidos</span>
        <strong>${boletosVendidos}</strong>
        <p>Boletos registrados en la demo.</p>
      </article>

      <article class="resumen-card">
        <span>Sorteos activos</span>
        <strong>${sorteosActivos}</strong>
        <p>Configuraciones activas.</p>
      </article>

      <article class="resumen-card">
        <span>Dinero real</span>
        <strong>${LB.formatearMoneda(dineroRealSistema)}</strong>
        <p>Suma de saldos reales.</p>
      </article>

      <article class="resumen-card">
        <span>Dinero virtual</span>
        <strong>${LB.formatearMoneda(dineroVirtualSistema)}</strong>
        <p>Suma de saldos virtuales.</p>
      </article>

      <article class="resumen-card">
        <span>Solicitudes pendientes</span>
        <strong>${solicitudesPendientes}</strong>
        <p>Solicitudes aún no atendidas.</p>
      </article>
    </div>
  `;

  LB.renderizarHTML("#resumenGeneralAdmin", html);
}


function contarUsuariosPorRol(rol, usuarios) {
  return usuarios.filter(function (usuario) {
    return Array.isArray(usuario.roles) && usuario.roles.includes(rol);
  }).length;
}


/* =========================================================
   12. Gestión de usuarios
   ========================================================= */

function renderizarUsuariosAdmin() {
  const filtroRol = document.querySelector("#filtroRolUsuario")?.value || "TODOS";
  const filtroEstado = document.querySelector("#filtroEstadoUsuario")?.value || "TODOS";

  let usuarios = [...AdminApp.usuarios];

  if (filtroRol !== "TODOS") {
    usuarios = usuarios.filter(function (usuario) {
      return Array.isArray(usuario.roles) && usuario.roles.includes(filtroRol);
    });
  }

  if (filtroEstado !== "TODOS") {
    usuarios = usuarios.filter(function (usuario) {
      return usuario.estado === filtroEstado;
    });
  }

  const tabla = LB.crearTabla(
    [
      {
        clave: "usuario",
        titulo: "Usuario"
      },
      {
        clave: "nombres",
        titulo: "Nombre",
        render: function (valor, fila) {
          return `${LB.escaparHTML(fila.nombres)} ${LB.escaparHTML(fila.apellidos)}`;
        }
      },
      {
        clave: "correo",
        titulo: "Correo"
      },
      {
        clave: "roles",
        titulo: "Roles",
        render: function (valor) {
          if (!Array.isArray(valor)) {
            return "Sin roles";
          }

          return valor.map(function (rol) {
            return LB.crearBadgeEstado(rol);
          }).join(" ");
        }
      },
      {
        clave: "estado",
        titulo: "Estado",
        render: function (valor) {
          return LB.crearBadgeEstado(valor);
        }
      },
      {
        clave: "id",
        titulo: "Acciones",
        render: function (valor, fila) {
          return crearAccionesUsuario(fila);
        }
      }
    ],
    usuarios
  );

  LB.renderizarHTML("#tablaUsuariosAdmin", tabla);
}


function crearAccionesUsuario(usuario) {
  const estaActivo = usuario.estado === "ACTIVO";

  return `
    <div class="hero-botones">
      <button
        type="button"
        class="${estaActivo ? "btn-peligro" : "btn-exito"}"
        data-toggle-usuario="${LB.escaparHTML(usuario.id)}"
      >
        ${estaActivo ? "Desactivar" : "Activar"}
      </button>

      <button
        type="button"
        class="btn-secundario"
        data-cliente-vendedor="${LB.escaparHTML(usuario.id)}"
      >
        Cliente a vendedor
      </button>

      <button
        type="button"
        class="btn-secundario"
        data-vendedor-admin="${LB.escaparHTML(usuario.id)}"
      >
        Vendedor a admin
      </button>

      <button
        type="button"
        class="btn-peligro"
        data-eliminar-visual="${LB.escaparHTML(usuario.id)}"
      >
        Eliminar visual
      </button>
    </div>
  `;
}


function activarDesactivarUsuario(usuarioId) {
  const usuario = buscarUsuario(usuarioId);

  if (!usuario) {
    mostrarMensajeAdmin("No se encontró el usuario.", "error");
    return;
  }

  if (usuario.estado === "ELIMINADO") {
    mostrarMensajeAdmin("El usuario está eliminado visualmente. Primero debería restaurarse en una versión real.", "advertencia");
    return;
  }

  usuario.estado = usuario.estado === "ACTIVO" ? "INACTIVO" : "ACTIVO";

  guardarDatosAdmin();
  renderizarTodoAdmin();

  mostrarMensajeAdmin(`Estado actualizado para ${usuario.usuario}.`, "exito");
}


function convertirClienteAVendedor(usuarioId) {
  const usuario = buscarUsuario(usuarioId);

  if (!usuario) {
    mostrarMensajeAdmin("No se encontró el usuario.", "error");
    return;
  }

  if (!Array.isArray(usuario.roles)) {
    usuario.roles = [];
  }

  if (!usuario.roles.includes("CLIENTE")) {
    mostrarMensajeAdmin("El usuario no tiene rol cliente.", "advertencia");
    return;
  }

  if (!usuario.roles.includes("VENDEDOR")) {
    usuario.roles.push("VENDEDOR");
  }

  usuario.rolPrincipal = "VENDEDOR";
  usuario.puedeComprarBoletos = false;
  usuario.puedeAtenderSolicitudes = true;

  guardarDatosAdmin();
  renderizarTodoAdmin();

  mostrarMensajeAdmin(`${usuario.usuario} ahora también puede actuar como vendedor.`, "exito");
}


function convertirVendedorAAdmin(usuarioId) {
  const usuario = buscarUsuario(usuarioId);

  if (!usuario) {
    mostrarMensajeAdmin("No se encontró el usuario.", "error");
    return;
  }

  if (!Array.isArray(usuario.roles)) {
    usuario.roles = [];
  }

  if (!usuario.roles.includes("VENDEDOR")) {
    mostrarMensajeAdmin("El usuario debe ser vendedor antes de convertirse en administrador.", "advertencia");
    return;
  }

  if (!usuario.roles.includes("ADMIN")) {
    usuario.roles.push("ADMIN");
  }

  usuario.rolPrincipal = "ADMIN";

  guardarDatosAdmin();
  renderizarTodoAdmin();

  mostrarMensajeAdmin(`${usuario.usuario} ahora tiene rol administrador.`, "exito");
}


function eliminarUsuarioVisualmente(usuarioId) {
  const usuario = buscarUsuario(usuarioId);

  if (!usuario) {
    mostrarMensajeAdmin("No se encontró el usuario.", "error");
    return;
  }

  usuario.estado = "ELIMINADO";

  guardarDatosAdmin();
  renderizarTodoAdmin();

  mostrarMensajeAdmin(`${usuario.usuario} fue eliminado visualmente en la demo.`, "advertencia");
}


/* =========================================================
   13. Módulos de sorteos
   ========================================================= */

function renderizarModulosSorteos() {
  renderizarModuloPorTipo("OCTAL", "#moduloOctal");
  renderizarModuloPorTipo("DECIMAL", "#moduloDecimal");
  renderizarModuloPorTipo("HEXADECIMAL", "#moduloHexadecimal");
}


function renderizarModuloPorTipo(tipo, selector) {
  const sorteosTipo = AdminApp.sorteos.filter(function (sorteo) {
    return sorteo.tipo === tipo;
  });

  if (sorteosTipo.length === 0) {
    LB.renderizarSinDatos(selector, `No hay sorteos configurados para ${tipo}.`);
    return;
  }

  const html = sorteosTipo.map(function (sorteo) {
    return crearFormularioSorteo(sorteo);
  }).join("");

  LB.renderizarHTML(selector, html);
}


function crearFormularioSorteo(sorteo) {
  const fechaInicial = obtenerFechaParaInput(sorteo.fechaInicial || sorteo.fechaInicio || sorteo.fechaCreacion);
  const horaInicial = obtenerHoraParaInput(sorteo.fechaInicial || sorteo.fechaInicio || sorteo.fechaCreacion);

  const precioBoleto = Number(sorteo.precioBoleto || sorteo.valorBoleto || 0);
  const premioBase = Number(sorteo.premioBase || precioBoleto * 5);

  return `
    <article class="tarjeta">
      <span class="badge badge-dorado">${LB.escaparHTML(sorteo.tipo)}</span>
      <h3>${LB.escaparHTML(sorteo.nombre)}</h3>

      <p>
        Configuración visual del sorteo. Los cambios se guardan en localStorage
        para la demostración.
      </p>

      <form class="form-sorteo-admin" data-form-sorteo="${LB.escaparHTML(sorteo.id)}" novalidate>

        <div class="grupo-formulario">
          <label for="digitos-${LB.escaparHTML(sorteo.id)}">Cantidad de dígitos</label>
          <input
            type="number"
            id="digitos-${LB.escaparHTML(sorteo.id)}"
            name="digitos"
            min="1"
            max="10"
            value="${LB.escaparHTML(sorteo.digitos || 4)}"
            required
          >
        </div>

        <div class="grupo-formulario">
          <label for="fecha-${LB.escaparHTML(sorteo.id)}">Fecha inicial</label>
          <input
            type="date"
            id="fecha-${LB.escaparHTML(sorteo.id)}"
            name="fechaInicial"
            value="${LB.escaparHTML(fechaInicial)}"
            required
          >
        </div>

        <div class="grupo-formulario">
          <label for="hora-${LB.escaparHTML(sorteo.id)}">Hora inicial</label>
          <input
            type="time"
            id="hora-${LB.escaparHTML(sorteo.id)}"
            name="horaInicial"
            value="${LB.escaparHTML(horaInicial)}"
            required
          >
        </div>

        <div class="grupo-formulario">
          <label for="anticipacion-${LB.escaparHTML(sorteo.id)}">Mostrar con anticipación</label>
          <input
            type="number"
            id="anticipacion-${LB.escaparHTML(sorteo.id)}"
            name="mostrarAnticipacion"
            min="1"
            value="${LB.escaparHTML(sorteo.mostrarAnticipacion || sorteo.horasAnticipacion || 12)}"
            required
          >
        </div>

        <div class="grupo-formulario">
          <label for="frecuencia-${LB.escaparHTML(sorteo.id)}">Frecuencia</label>
          <input
            type="number"
            id="frecuencia-${LB.escaparHTML(sorteo.id)}"
            name="frecuencia"
            min="1"
            value="${LB.escaparHTML(sorteo.frecuencia || 24)}"
            required
          >
        </div>

        <div class="grupo-formulario">
          <label for="tipoFrecuencia-${LB.escaparHTML(sorteo.id)}">Tipo de frecuencia</label>
          <select
            id="tipoFrecuencia-${LB.escaparHTML(sorteo.id)}"
            name="tipoFrecuencia"
            required
          >
            <option value="HORAS" ${normalizarTipoFrecuencia(sorteo) === "HORAS" ? "selected" : ""}>Horas</option>
            <option value="DIAS" ${normalizarTipoFrecuencia(sorteo) === "DIAS" ? "selected" : ""}>Días</option>
          </select>
        </div>

        <div class="grupo-formulario">
          <label for="cierre-${LB.escaparHTML(sorteo.id)}">Minutos de cierre antes del sorteo</label>
          <input
            type="number"
            id="cierre-${LB.escaparHTML(sorteo.id)}"
            name="minutosCierre"
            min="1"
            value="${LB.escaparHTML(sorteo.minutosCierreAntes || sorteo.minutosCierre || 10)}"
            required
          >
        </div>

        <div class="grupo-formulario">
          <label for="precio-${LB.escaparHTML(sorteo.id)}">Valor del boleto</label>
          <input
            type="number"
            id="precio-${LB.escaparHTML(sorteo.id)}"
            name="precioBoleto"
            min="0.01"
            step="0.01"
            value="${LB.escaparHTML(precioBoleto)}"
            required
          >
        </div>

        <div class="grupo-formulario">
          <label for="premioBase-${LB.escaparHTML(sorteo.id)}">Premio base</label>
          <input
            type="number"
            id="premioBase-${LB.escaparHTML(sorteo.id)}"
            name="premioBase"
            min="0.01"
            step="0.01"
            value="${LB.escaparHTML(premioBase)}"
            required
          >
        </div>

        <div class="grupo-formulario">
          <label for="acumulacion-${LB.escaparHTML(sorteo.id)}">Porcentaje de acumulación</label>
          <input
            type="number"
            id="acumulacion-${LB.escaparHTML(sorteo.id)}"
            name="porcentajeAcumulacion"
            min="0"
            max="100"
            step="1"
            value="${LB.escaparHTML(sorteo.porcentajeAcumulacion || 75)}"
            required
          >
        </div>

        <div class="grupo-formulario">
          <label for="estado-${LB.escaparHTML(sorteo.id)}">Estado</label>
          <select id="estado-${LB.escaparHTML(sorteo.id)}" name="estadoConfiguracion">
            <option value="ACTIVO" ${normalizarEstadoSorteo(sorteo) === "ACTIVO" ? "selected" : ""}>Activo</option>
            <option value="INACTIVO" ${normalizarEstadoSorteo(sorteo) === "INACTIVO" ? "selected" : ""}>Inactivo</option>
          </select>
        </div>

        <div class="alerta alerta-info">
          Premio base = valor boleto × 5. Premio secundario = devolución si acierta todo menos un número.
          El premio puede crecer con el 75% de ventas nuevas después de cubrir costos.
        </div>

        <button type="submit" class="btn-principal">
          Guardar configuración y generar evento
        </button>
      </form>
    </article>
  `;
}


function guardarConfiguracionSorteo(form) {
  const sorteoId = form.getAttribute("data-form-sorteo");
  const sorteo = AdminApp.sorteos.find(function (item) {
    return item.id === sorteoId;
  });

  if (!sorteo) {
    mostrarMensajeAdmin("No se encontró el sorteo a editar.", "error");
    return;
  }

  const datos = new FormData(form);

  const precioBoleto = redondearDinero(datos.get("precioBoleto"));
  const premioBase = redondearDinero(datos.get("premioBase"));

  sorteo.digitos = Number(datos.get("digitos"));
  sorteo.fechaInicial = `${datos.get("fechaInicial")}T${datos.get("horaInicial")}:00`;
  sorteo.mostrarAnticipacion = Number(datos.get("mostrarAnticipacion"));
  sorteo.frecuencia = Number(datos.get("frecuencia"));
  sorteo.tipoFrecuencia = datos.get("tipoFrecuencia");
  sorteo.minutosCierreAntes = Number(datos.get("minutosCierre"));
  sorteo.precioBoleto = precioBoleto;
  sorteo.premioBase = premioBase;
  sorteo.porcentajeAcumulacion = Number(datos.get("porcentajeAcumulacion"));
  sorteo.estadoConfiguracion = datos.get("estadoConfiguracion");

  const eventoGenerado = crearOActualizarEventoProximo(sorteo);

  guardarDatosAdmin();
  renderizarTodoAdmin();

  if (normalizarEstadoSorteo(sorteo) !== "ACTIVO") {
    mostrarMensajeAdmin(
      "Configuración guardada. El sorteo está inactivo, por eso sus eventos próximos fueron cerrados.",
      "advertencia"
    );
    return;
  }

  const mensajeEvento = eventoGenerado
    ? ` Evento próximo generado: ${eventoGenerado.id}.`
    : "";

  if (premioBase !== redondearDinero(precioBoleto * 5)) {
    mostrarMensajeAdmin(
      `Configuración guardada. Nota: según la regla, el premio base recomendado sería ${LB.formatearMoneda(precioBoleto * 5)}.${mensajeEvento}`,
      "advertencia"
    );
  } else {
    mostrarMensajeAdmin(
      `Configuración del sorteo guardada visualmente.${mensajeEvento}`,
      "exito"
    );
  }
}

/* =========================================================
   13.1 Crear o actualizar evento próximo del sorteo

   Objetivo:
   - Tomar la configuración del módulo Octal, Decimal o Hexadecimal.
   - Crear/actualizar un evento PROXIMO.
   - Guardarlo en AdminApp.eventos.
   - Luego guardar en localStorage con guardarDatosAdmin().
   ========================================================= */

function crearOActualizarEventoProximo(sorteo) {
  const estadoSorteo = normalizarEstadoSorteo(sorteo);

  /*
    Si el sorteo se desactiva, se bloquean sus eventos próximos.
  */
  if (estadoSorteo !== "ACTIVO") {
    desactivarEventosProximosDelSorteo(sorteo.id);
    return null;
  }

  const fechaSorteo = calcularProximaFechaSorteo(sorteo);

  const minutosCierre = Number(
    sorteo.minutosCierreAntes ||
    sorteo.minutosCierre ||
    10
  );

  const horasAnticipacion = Number(
    sorteo.mostrarAnticipacion ||
    sorteo.horasAnticipacion ||
    12
  );

  const fechaCierreVenta = new Date(fechaSorteo);
  fechaCierreVenta.setMinutes(fechaCierreVenta.getMinutes() - minutosCierre);

  const fechaInicioVenta = new Date(fechaSorteo);
  fechaInicioVenta.setHours(fechaInicioVenta.getHours() - horasAnticipacion);

  const eventoExistente = AdminApp.eventos.find(function (evento) {
    return evento.sorteoId === sorteo.id && evento.estado === "PROXIMO";
  });

  const precioBoleto = Number(sorteo.precioBoleto || 0);
  const premioBase = Number(sorteo.premioBase || precioBoleto * 5 || 0);

  const datosEvento = {
    sorteoId: sorteo.id,
    nombreEvento: `${sorteo.nombre} - Evento generado`,
    tipo: sorteo.tipo,
    fechaInicioVenta: fechaInicioVenta.toISOString(),
    fechaCierreVenta: fechaCierreVenta.toISOString(),
    fechaSorteo: fechaSorteo.toISOString(),
    estado: "PROXIMO",
    disponibleCompra: true,
    numeroGanador: null,
    premioActual: premioBase,
    totalVentas: 0,
    totalBoletosVendidos: 0
  };

  if (eventoExistente) {
    Object.assign(eventoExistente, datosEvento);
    return eventoExistente;
  }

  const nuevoEvento = {
    id: generarIdAdmin("EVE"),
    ...datosEvento
  };

  AdminApp.eventos.push(nuevoEvento);

  return nuevoEvento;
}


/* =========================================================
   13.2 Desactivar eventos próximos si el sorteo está inactivo
   ========================================================= */

function desactivarEventosProximosDelSorteo(sorteoId) {
  AdminApp.eventos.forEach(function (evento) {
    if (evento.sorteoId === sorteoId && evento.estado === "PROXIMO") {
      evento.disponibleCompra = false;
      evento.estado = "CERRADO";
    }
  });
}


/* =========================================================
   13.3 Calcular próxima fecha de sorteo

   Si la fecha inicial ya pasó, suma la frecuencia hasta
   encontrar una fecha futura.
   ========================================================= */

function calcularProximaFechaSorteo(sorteo) {
  let fecha = new Date(sorteo.fechaInicial || new Date());

  if (Number.isNaN(fecha.getTime())) {
    fecha = new Date();
    fecha.setHours(fecha.getHours() + 1);
  }

  const ahora = new Date();
  const frecuencia = Math.max(1, Number(sorteo.frecuencia || 24));
  const tipoFrecuencia = normalizarTipoFrecuencia(sorteo);

  while (fecha <= ahora) {
    if (tipoFrecuencia === "DIAS") {
      fecha.setDate(fecha.getDate() + frecuencia);
    } else {
      fecha.setHours(fecha.getHours() + frecuencia);
    }
  }

  return fecha;
}


/* =========================================================
   13.4 Generar ID para datos creados por admin
   ========================================================= */

function generarIdAdmin(prefijo) {
  return `${prefijo}-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
}

/* =========================================================
   14. Solicitudes
   ========================================================= */

function renderizarSolicitudesAdmin() {
  const filtro = document.querySelector("#filtroSolicitudAdmin")?.value || "TODOS";

  let solicitudes = [...AdminApp.solicitudes];

  if (filtro !== "TODOS") {
    solicitudes = solicitudes.filter(function (solicitud) {
      return solicitud.estado === filtro;
    });
  }

  solicitudes.sort(function (a, b) {
    return new Date(b.fechaCreacion) - new Date(a.fechaCreacion);
  });

  const tabla = LB.crearTabla(
    [
      {
        clave: "id",
        titulo: "Solicitud"
      },
      {
        clave: "clienteId",
        titulo: "Cliente",
        render: function (valor) {
          const usuario = buscarUsuario(valor);
          return usuario ? `${LB.escaparHTML(usuario.nombres)} ${LB.escaparHTML(usuario.apellidos)}` : "No encontrado";
        }
      },
      {
        clave: "vendedorId",
        titulo: "Vendedor",
        render: function (valor) {
          if (!valor) {
            return "Sin asignar";
          }

          const usuario = buscarUsuario(valor);
          return usuario ? `${LB.escaparHTML(usuario.nombres)} ${LB.escaparHTML(usuario.apellidos)}` : valor;
        }
      },
      {
        clave: "montoSolicitado",
        titulo: "Monto",
        render: function (valor) {
          return LB.formatearMoneda(valor);
        }
      },
      {
        clave: "estado",
        titulo: "Estado",
        render: function (valor) {
          return LB.crearBadgeEstado(valor);
        }
      },
      {
        clave: "fechaCreacion",
        titulo: "Fecha",
        render: function (valor) {
          return LB.formatearFechaHora(valor);
        }
      }
    ],
    solicitudes
  );

  LB.renderizarHTML("#tablaSolicitudesAdmin", tabla);
}


/* =========================================================
   15. Movimientos globales
   ========================================================= */

function renderizarMovimientosAdmin() {
  const filtro = document.querySelector("#filtroMovimientoAdmin")?.value || "TODOS";

  let movimientos = [...AdminApp.movimientos];

  if (filtro !== "TODOS") {
    movimientos = movimientos.filter(function (movimiento) {
      return String(movimiento.tipoDinero).includes(filtro);
    });
  }

  movimientos.sort(function (a, b) {
    return new Date(b.fecha) - new Date(a.fecha);
  });

  const tabla = LB.crearTabla(
    [
      {
        clave: "fecha",
        titulo: "Fecha",
        render: function (valor) {
          return LB.formatearFechaHora(valor);
        }
      },
      {
        clave: "usuarioId",
        titulo: "Usuario",
        render: function (valor) {
          const usuario = buscarUsuario(valor);
          return usuario ? LB.escaparHTML(usuario.usuario) : valor;
        }
      },
      {
        clave: "tipoMovimiento",
        titulo: "Movimiento",
        render: function (valor) {
          return LB.escaparHTML(String(valor).replaceAll("_", " "));
        }
      },
      {
        clave: "tipoDinero",
        titulo: "Tipo"
      },
      {
        clave: "monto",
        titulo: "Monto",
        render: function (valor) {
          return LB.formatearMoneda(valor);
        }
      },
      {
        clave: "comision",
        titulo: "Comisión",
        render: function (valor) {
          return LB.formatearMoneda(valor || 0);
        }
      },
      {
        clave: "montoNeto",
        titulo: "Neto",
        render: function (valor) {
          return LB.formatearMoneda(valor || 0);
        }
      },
      {
        clave: "estado",
        titulo: "Estado",
        render: function (valor) {
          return LB.crearBadgeEstado(valor);
        }
      }
    ],
    movimientos
  );

  LB.renderizarHTML("#tablaMovimientosAdmin", tabla);
}


/* =========================================================
   16. Estadísticas
   ========================================================= */

function renderizarEstadisticasAdmin() {
  const totalBoletos = AdminApp.boletos.length;

  const boletosPremiados = AdminApp.boletos.filter(function (boleto) {
    return boleto.estado === "PREMIADO" || boleto.resultado === "PREMIO_MAYOR" || boleto.resultado === "PREMIO_SECUNDARIO";
  }).length;

  const boletosPerdidos = AdminApp.boletos.filter(function (boleto) {
    return boleto.estado === "PERDIDO" || boleto.resultado === "NO_GANADOR";
  }).length;

  const boletosPendientes = AdminApp.boletos.filter(function (boleto) {
    return boleto.estado === "PENDIENTE" || boleto.resultado === "AUN_NO_PASA_EL_SORTEO";
  }).length;

  const ventaBoletos = AdminApp.boletos.reduce(function (total, boleto) {
    return total + Number(boleto.precio || 0);
  }, 0);

  const solicitudesCompletadas = AdminApp.solicitudes.filter(function (solicitud) {
    return solicitud.estado === "COMPLETADA";
  }).length;

  const solicitudesCanceladas = AdminApp.solicitudes.filter(function (solicitud) {
    return solicitud.estado === "CANCELADA";
  }).length;

  const dineroVirtualVendedores = AdminApp.wallets
    .filter(function (wallet) {
      return wallet.tipoUsuario === "VENDEDOR";
    })
    .reduce(function (total, wallet) {
      return total + Number(wallet.saldoVirtual || 0);
    }, 0);

  const gananciasVendedores = AdminApp.wallets.reduce(function (total, wallet) {
    return total + Number(wallet.gananciasGeneradas || 0);
  }, 0);

  const html = `
    <div class="resumen-grid">
      <article class="resumen-card">
        <span>Total boletos</span>
        <strong>${totalBoletos}</strong>
        <p>Boletos vendidos en la demo.</p>
      </article>

      <article class="resumen-card">
        <span>Boletos premiados</span>
        <strong>${boletosPremiados}</strong>
        <p>Incluye premio mayor y secundario.</p>
      </article>

      <article class="resumen-card">
        <span>Boletos perdidos</span>
        <strong>${boletosPerdidos}</strong>
        <p>Boletos sin premio.</p>
      </article>

      <article class="resumen-card">
        <span>Boletos pendientes</span>
        <strong>${boletosPendientes}</strong>
        <p>Aún no pasa el sorteo.</p>
      </article>

      <article class="resumen-card">
        <span>Ventas por boletos</span>
        <strong>${LB.formatearMoneda(ventaBoletos)}</strong>
        <p>Total simulado de venta.</p>
      </article>

      <article class="resumen-card">
        <span>Solicitudes completadas</span>
        <strong>${solicitudesCompletadas}</strong>
        <p>Atendidas por vendedores.</p>
      </article>

      <article class="resumen-card">
        <span>Solicitudes canceladas</span>
        <strong>${solicitudesCanceladas}</strong>
        <p>No finalizadas.</p>
      </article>

      <article class="resumen-card">
        <span>Virtual vendedores</span>
        <strong>${LB.formatearMoneda(dineroVirtualVendedores)}</strong>
        <p>Saldo virtual de vendedores.</p>
      </article>

      <article class="resumen-card">
        <span>Ganancias vendedores</span>
        <strong>${LB.formatearMoneda(gananciasVendedores)}</strong>
        <p>Ganancia potencial registrada.</p>
      </article>
    </div>

    <div class="alerta alerta-info">
      Estas estadísticas son calculadas en el navegador usando datos JSON y cambios
      simulados en localStorage.
    </div>
  `;

  LB.renderizarHTML("#estadisticasAdmin", html);
}


/* =========================================================
   17. Activar eventos
   ========================================================= */

function activarEventosAdmin() {
  document.addEventListener("click", function (evento) {
    const btnToggleUsuario = evento.target.closest("[data-toggle-usuario]");
    const btnClienteVendedor = evento.target.closest("[data-cliente-vendedor]");
    const btnVendedorAdmin = evento.target.closest("[data-vendedor-admin]");
    const btnEliminarVisual = evento.target.closest("[data-eliminar-visual]");

    if (btnToggleUsuario) {
      activarDesactivarUsuario(btnToggleUsuario.getAttribute("data-toggle-usuario"));
    }

    if (btnClienteVendedor) {
      convertirClienteAVendedor(btnClienteVendedor.getAttribute("data-cliente-vendedor"));
    }

    if (btnVendedorAdmin) {
      convertirVendedorAAdmin(btnVendedorAdmin.getAttribute("data-vendedor-admin"));
    }

    if (btnEliminarVisual) {
      eliminarUsuarioVisualmente(btnEliminarVisual.getAttribute("data-eliminar-visual"));
    }
  });

  const filtroRolUsuario = document.querySelector("#filtroRolUsuario");
  const filtroEstadoUsuario = document.querySelector("#filtroEstadoUsuario");
  const filtroSolicitudAdmin = document.querySelector("#filtroSolicitudAdmin");
  const filtroMovimientoAdmin = document.querySelector("#filtroMovimientoAdmin");

  if (filtroRolUsuario) {
    filtroRolUsuario.addEventListener("change", renderizarUsuariosAdmin);
  }

  if (filtroEstadoUsuario) {
    filtroEstadoUsuario.addEventListener("change", renderizarUsuariosAdmin);
  }

  if (filtroSolicitudAdmin) {
    filtroSolicitudAdmin.addEventListener("change", renderizarSolicitudesAdmin);
  }

  if (filtroMovimientoAdmin) {
    filtroMovimientoAdmin.addEventListener("change", renderizarMovimientosAdmin);
  }

  document.addEventListener("submit", function (evento) {
    const formSorteo = evento.target.closest("[data-form-sorteo]");

    if (formSorteo) {
      evento.preventDefault();
      guardarConfiguracionSorteo(formSorteo);
    }
  });

  document.addEventListener("input", function (evento) {
    const inputPrecio = evento.target.closest("input[name='precioBoleto']");

    if (inputPrecio) {
      actualizarPremioBaseAutomatico(inputPrecio);
    }
  });
}


/* =========================================================
   18. Premio base automático

   Cuando se cambia el valor del boleto, se actualiza visualmente
   el premio base recomendado: valor boleto × 5.
   ========================================================= */

function actualizarPremioBaseAutomatico(inputPrecio) {
  const form = inputPrecio.closest("form");

  if (!form) {
    return;
  }

  const inputPremioBase = form.querySelector("input[name='premioBase']");

  if (!inputPremioBase) {
    return;
  }

  const precio = Number(inputPrecio.value);

  if (Number.isNaN(precio) || precio <= 0) {
    return;
  }

  inputPremioBase.value = redondearDinero(precio * 5);
}


/* =========================================================
   19. Utilidades internas
   ========================================================= */

function buscarUsuario(usuarioId) {
  return AdminApp.usuarios.find(function (usuario) {
    return usuario.id === usuarioId;
  });
}


function sumar(lista, campo) {
  return lista.reduce(function (total, item) {
    return total + Number(item[campo] || 0);
  }, 0);
}


function normalizarEstadoSorteo(sorteo) {
  return sorteo.estadoConfiguracion || sorteo.estado || "INACTIVO";
}


function normalizarTipoFrecuencia(sorteo) {
  return sorteo.tipoFrecuencia || sorteo.frecuenciaTipo || "HORAS";
}


function obtenerFechaParaInput(fechaISO) {
  if (!fechaISO) {
    return "";
  }

  const fecha = new Date(fechaISO);

  if (Number.isNaN(fecha.getTime())) {
    return "";
  }

  return fecha.toISOString().split("T")[0];
}


function obtenerHoraParaInput(fechaISO) {
  if (!fechaISO) {
    return "12:00";
  }

  const fecha = new Date(fechaISO);

  if (Number.isNaN(fecha.getTime())) {
    return "12:00";
  }

  return fecha.toTimeString().slice(0, 5);
}


function redondearDinero(valor) {
  return Math.round(Number(valor) * 100) / 100;
}


function mostrarMensajeAdmin(mensaje, tipo) {
  LB.mostrarAlerta("#mensajeAdmin", mensaje, tipo);

  window.scrollTo({
    top: 0,
    behavior: "smooth"
  });
}