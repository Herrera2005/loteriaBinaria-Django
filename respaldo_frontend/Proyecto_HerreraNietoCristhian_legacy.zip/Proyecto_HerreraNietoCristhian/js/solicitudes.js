/* =========================================================
   Lotería Binaria - solicitudes.js

   Objetivo:
   Centralizar el manejo de solicitudes cliente-vendedor.

   Este archivo permite:
   - Cargar solicitudes desde data/solicitudes.json.
   - Combinar solicitudes base con cambios guardados en localStorage.
   - Crear solicitudes de cliente para cambiar dinero real a virtual.
   - Mostrar solicitudes pendientes a vendedores.
   - Filtrar solicitudes por saldo virtual suficiente del vendedor.
   - Tomar solicitud.
   - Asignar vendedor.
   - Cambiar estado a EN_PROCESO.
   - Cancelar solicitud.
   - Confirmar solicitud.
   - Completar movimiento financiero:
     vendedor pierde saldo virtual.
     cliente gana saldo virtual.
     vendedor gana saldo real.
   - Registrar movimientos relacionados.
   - Simular expiración.
   - Mostrar mensajes claros.

   Importante:
   - No usa backend.
   - No modifica archivos JSON.
   - Todo se simula con localStorage.
   - Usa JavaScript puro.
   ========================================================= */


/* =========================================================
   1. Validación de dependencia
   ========================================================= */

if (typeof LB === "undefined") {
  console.error("solicitudes.js necesita que utils.js se cargue primero.");
}


/* =========================================================
   2. Módulo global LBSolicitudes

   Se usa una función autoejecutable para encapsular el estado
   y exponer solo las funciones necesarias.
   ========================================================= */

const LBSolicitudes = (function () {

  /* =======================================================
     2.1 Estado interno del módulo
     ======================================================= */

  const estado = {
    usuarios: [],
    wallets: [],
    movimientos: [],
    solicitudesBase: [],
    solicitudes: [],
    cargado: false
  };


  /* =======================================================
     2.2 Configuración general de la demo
     ======================================================= */

  const CONFIG = {
    COMISION_TARJETA: 0.05,
    COMISION_VIRTUAL_REAL: 0.15,
    SEGUNDOS_BLOQUEO_BOTONES: 10,
    SEGUNDOS_ATENCION_VISUAL: 120,
    MINUTOS_EXPIRACION_SOLICITUD: 10
  };


  /* =======================================================
     2.3 Claves de localStorage

     Estas claves coinciden con cliente.js, vendedor.js,
     admin.js y wallets.js para mantener la demo conectada.
     ======================================================= */

  const STORAGE = {
    USUARIOS: "loteriaBinaria_usuariosDemo",
    WALLETS: "loteriaBinaria_walletsDemo",
    MOVIMIENTOS: "loteriaBinaria_movimientosDemo",
    SOLICITUDES: "loteriaBinaria_solicitudesDemo"
  };


  /* =======================================================
     3. Inicializar módulo

     Carga archivos JSON separados:
     - usuarios.json
     - wallets.json
     - movimientos.json
     - solicitudes.json

     Luego combina solicitudes base con cambios guardados.
     ======================================================= */

  async function inicializar() {
    if (estado.cargado) {
      return respuesta(true, "Solicitudes ya inicializadas.");
    }

    const [
      usuariosJSON,
      walletsJSON,
      movimientosJSON,
      solicitudesJSON
    ] = await Promise.all([
      LB.cargarJSON("usuarios.json"),
      LB.cargarJSON("wallets.json"),
      LB.cargarJSON("movimientos.json"),
      LB.cargarJSON("solicitudes.json")
    ]);

    estado.usuarios = obtenerDatosPersistidos(STORAGE.USUARIOS, usuariosJSON);
    estado.wallets = obtenerDatosPersistidos(STORAGE.WALLETS, walletsJSON);
    estado.movimientos = obtenerDatosPersistidos(STORAGE.MOVIMIENTOS, movimientosJSON);

    estado.solicitudesBase = Array.isArray(solicitudesJSON) ? solicitudesJSON : [];

    const solicitudesGuardadas = leerJSONLocalStorage(STORAGE.SOLICITUDES, []);

    estado.solicitudes = combinarSolicitudes(
      estado.solicitudesBase,
      solicitudesGuardadas
    );

    localStorage.setItem(STORAGE.SOLICITUDES, JSON.stringify(estado.solicitudes));

    simularExpiracionSolicitudes();

    estado.cargado = true;

    return respuesta(true, "Solicitudes inicializadas correctamente.");
  }


  /* =======================================================
     4. Obtener datos persistidos

     Mantiene separados:
     - usuarios
     - wallets
     - movimientos
     - solicitudes
     ======================================================= */

  function obtenerDatosPersistidos(clave, datosIniciales) {
    try {
      const datosGuardados = localStorage.getItem(clave);

      if (datosGuardados) {
        return JSON.parse(datosGuardados);
      }

      localStorage.setItem(clave, JSON.stringify(datosIniciales));
      return datosIniciales;
    } catch (error) {
      console.error("Error al leer localStorage:", error);
      return datosIniciales;
    }
  }


  function leerJSONLocalStorage(clave, valorPorDefecto) {
    try {
      const datos = localStorage.getItem(clave);

      if (!datos) {
        return valorPorDefecto;
      }

      return JSON.parse(datos);
    } catch (error) {
      console.error(`Error leyendo ${clave}:`, error);
      return valorPorDefecto;
    }
  }


  /* =======================================================
     5. Combinar solicitudes base con cambios locales

     Regla:
     - Si una solicitud del JSON existe también en localStorage,
       se usa la versión de localStorage.
     - Si localStorage tiene solicitudes nuevas creadas en la demo,
       también se conservan.
     ======================================================= */

  function combinarSolicitudes(solicitudesBase, solicitudesGuardadas) {
    const mapa = new Map();

    solicitudesBase.forEach(function (solicitud) {
      mapa.set(solicitud.id, normalizarSolicitud(solicitud));
    });

    solicitudesGuardadas.forEach(function (solicitud) {
      mapa.set(solicitud.id, normalizarSolicitud(solicitud));
    });

    return Array.from(mapa.values());
  }


  /* =======================================================
     6. Normalizar solicitud

     Permite trabajar aunque algunos JSON usen nombres distintos.
     ======================================================= */

  function normalizarSolicitud(solicitud) {
    const monto = Number(
      solicitud.montoSolicitado ??
      solicitud.monto ??
      solicitud.valor ??
      0
    );

    return {
      id: solicitud.id || generarId("SOL"),
      clienteId: solicitud.clienteId || solicitud.usuarioId || null,
      vendedorId: solicitud.vendedorId || null,
      montoSolicitado: redondearDinero(monto),
      estado: solicitud.estado || "PENDIENTE",
      fechaCreacion: solicitud.fechaCreacion || new Date().toISOString(),
      fechaAsignacion: solicitud.fechaAsignacion || null,
      fechaResolucion: solicitud.fechaResolucion || null,
      fechaExpiracion:
        solicitud.fechaExpiracion ||
        calcularFechaExpiracionDesdeFecha(solicitud.fechaCreacion || new Date().toISOString()),
      saldoRealReservado: solicitud.saldoRealReservado ?? true,
      segundosBloqueoBotones: solicitud.segundosBloqueoBotones || CONFIG.SEGUNDOS_BLOQUEO_BOTONES,
      segundosAtencionVisual: solicitud.segundosAtencionVisual || CONFIG.SEGUNDOS_ATENCION_VISUAL,
      bloqueoBotonesInicio: solicitud.bloqueoBotonesInicio || null,
      timerAtencionInicio: solicitud.timerAtencionInicio || null,
      observacion: solicitud.observacion || "Solicitud cargada correctamente."
    };
  }


  /* =======================================================
     7. Guardar cambios simulados
     ======================================================= */

  function guardarCambios() {
    localStorage.setItem(STORAGE.WALLETS, JSON.stringify(estado.wallets));
    localStorage.setItem(STORAGE.MOVIMIENTOS, JSON.stringify(estado.movimientos));
    localStorage.setItem(STORAGE.SOLICITUDES, JSON.stringify(estado.solicitudes));
  }


  /* =======================================================
     8. Sincronizar desde localStorage

     Sirve cuando otra página modificó wallets, movimientos
     o solicitudes y se necesita actualizar el estado interno.
     ======================================================= */

  function sincronizarDesdeLocalStorage() {
    estado.wallets = leerJSONLocalStorage(STORAGE.WALLETS, estado.wallets);
    estado.movimientos = leerJSONLocalStorage(STORAGE.MOVIMIENTOS, estado.movimientos);

    const solicitudesGuardadas = leerJSONLocalStorage(STORAGE.SOLICITUDES, estado.solicitudes);

    estado.solicitudes = combinarSolicitudes(
      estado.solicitudesBase,
      solicitudesGuardadas
    );

    simularExpiracionSolicitudes();
  }


  /* =======================================================
     9. Crear solicitud de cliente

     Flujo:
     1. Cliente tiene saldo real.
     2. Cliente solicita recibir saldo virtual.
     3. Se descuenta visualmente el saldo real.
     4. Se registra como saldo real reservado.
     5. La solicitud queda PENDIENTE.
     ======================================================= */

  function crearSolicitudCliente(clienteId, montoSolicitado, observacion = "") {
    sincronizarDesdeLocalStorage();

    const cliente = obtenerUsuario(clienteId);
    const walletCliente = obtenerOCrearWallet(clienteId, "CLIENTE");
    const monto = normalizarMonto(montoSolicitado);

    const modo = String(localStorage.getItem("loteriaBinaria_modoAcceso") || "")
      .trim()
      .toUpperCase();

    if (modo !== "CLIENTE") {
      return respuesta(false, "Debes estar en modo cliente para crear una solicitud.");
    }

    if (!usuarioTieneRol(cliente, "CLIENTE")) {
      return respuesta(false, "Solo un cliente puede crear solicitudes.");
    }

    if (monto <= 0) {
      return respuesta(false, "El monto solicitado debe ser mayor a cero.");
    }

    if (Number(walletCliente.saldoReal || 0) < monto) {
      return respuesta(false, "Saldo real insuficiente para crear la solicitud.");
    }

    walletCliente.saldoReal = redondearDinero(Number(walletCliente.saldoReal || 0) - monto);
    walletCliente.saldoRealReservado = redondearDinero(
      Number(walletCliente.saldoRealReservado || 0) + monto
    );
    walletCliente.ultimaActualizacion = new Date().toISOString();

    const nuevaSolicitud = {
      id: generarId("SOL"),
      clienteId: clienteId,
      vendedorId: null,
      montoSolicitado: monto,
      estado: "PENDIENTE",
      fechaCreacion: new Date().toISOString(),
      fechaAsignacion: null,
      fechaResolucion: null,
      fechaExpiracion: calcularFechaExpiracion(),
      saldoRealReservado: true,
      segundosBloqueoBotones: CONFIG.SEGUNDOS_BLOQUEO_BOTONES,
      segundosAtencionVisual: CONFIG.SEGUNDOS_ATENCION_VISUAL,
      bloqueoBotonesInicio: null,
      timerAtencionInicio: null,
      observacion: observacion || "Solicitud creada por cliente para recibir dinero virtual."
    };

    estado.solicitudes.push(nuevaSolicitud);

    registrarMovimiento({
      usuarioId: clienteId,
      walletId: walletCliente.id,
      tipoMovimiento: "RESERVA_REAL_SOLICITUD",
      tipoDinero: "REAL",
      monto: monto,
      comision: 0,
      montoNeto: 0,
      descripcion: `Reserva de saldo real para solicitud ${nuevaSolicitud.id}.`,
      estado: "PENDIENTE",
      referenciaId: nuevaSolicitud.id
    });

    guardarCambios();

    return respuesta(
      true,
      `Solicitud creada correctamente por ${LB.formatearMoneda(monto)}.`,
      {
        solicitud: nuevaSolicitud,
        walletCliente: walletCliente
      }
    );
  }


  /* =======================================================
     10. Mostrar solicitudes pendientes a vendedores

     Esta función renderiza tarjetas en un contenedor.
     Solo muestra solicitudes:
     - PENDIENTES.
     - No creadas por el mismo vendedor.
     - Con monto menor o igual al saldo virtual del vendedor.
     ======================================================= */

  function mostrarSolicitudesPendientesVendedor(selector, vendedorId) {
    sincronizarDesdeLocalStorage();

    const contenedor = document.querySelector(selector);

    if (!contenedor) {
      return respuesta(false, "No se encontró el contenedor de solicitudes.");
    }

    const solicitudes = obtenerSolicitudesPendientesParaVendedor(vendedorId);

    if (solicitudes.length === 0) {
      contenedor.innerHTML = `
        <div class="alerta alerta-info">
          No hay solicitudes pendientes disponibles para tu saldo virtual actual.
        </div>
      `;

      return respuesta(true, "No hay solicitudes pendientes disponibles.", {
        solicitudes: []
      });
    }

    const html = solicitudes.map(function (solicitud) {
      return crearTarjetaSolicitudVendedor(solicitud, vendedorId);
    }).join("");

    contenedor.innerHTML = `<div class="grid-tarjetas">${html}</div>`;
    actualizarContadoresSolicitudes();

    return respuesta(true, "Solicitudes renderizadas.", {
      solicitudes: solicitudes
    });
  }


  /* =======================================================
     11. Obtener solicitudes pendientes para vendedor
     ======================================================= */

  function obtenerSolicitudesPendientesParaVendedor(vendedorId) {
  sincronizarDesdeLocalStorage();

  const vendedor = obtenerUsuario(vendedorId);
  const walletVendedor = obtenerOCrearWallet(vendedorId, "VENDEDOR");
  const ahora = new Date();

  if (!vendedor || !usuarioTieneRol(vendedor, "VENDEDOR")) {
    return [];
  }

  return estado.solicitudes
    .filter(function (solicitud) {
      const fechaExpiracion = new Date(
        solicitud.fechaExpiracion ||
        calcularFechaExpiracionDesdeFecha(solicitud.fechaCreacion)
      );

      const noExpirada =
        !Number.isNaN(fechaExpiracion.getTime()) &&
        ahora < fechaExpiracion;

      const esPendiente = solicitud.estado === "PENDIENTE";
      const noEsPropia = solicitud.clienteId !== vendedorId;
      const saldoSuficiente =
        Number(walletVendedor.saldoVirtual || 0) >=
        Number(solicitud.montoSolicitado || 0);

      return esPendiente && noEsPropia && saldoSuficiente && noExpirada;
    })
    .sort(function (a, b) {
      const fechaA = new Date(
        a.fechaExpiracion || calcularFechaExpiracionDesdeFecha(a.fechaCreacion)
      );

      const fechaB = new Date(
        b.fechaExpiracion || calcularFechaExpiracionDesdeFecha(b.fechaCreacion)
      );

      return fechaA - fechaB;
    });
}


  /* =======================================================
     12. Crear tarjeta visual de solicitud para vendedor
     ======================================================= */

  function crearTarjetaSolicitudVendedor(solicitud, vendedorId) {
    const cliente = obtenerUsuario(solicitud.clienteId);
    const clienteTexto = cliente
      ? `${cliente.nombres} ${cliente.apellidos} (${cliente.usuario})`
      : "Cliente no encontrado";

    return `
      <article class="tarjeta">
        ${LB.crearBadgeEstado(solicitud.estado)}

        <h3>Solicitud ${LB.escaparHTML(solicitud.id)}</h3>

        <p><strong>Cliente:</strong> ${LB.escaparHTML(clienteTexto)}</p>
        <p><strong>Monto solicitado:</strong> ${LB.formatearMoneda(solicitud.montoSolicitado)}</p>
        <p><strong>Fecha:</strong> ${LB.formatearFechaHora(solicitud.fechaCreacion)}</p>
        <p><strong>Expira:</strong> ${LB.formatearFechaHora(solicitud.fechaExpiracion)}</p>
        <p>
          <strong>Caduca en:</strong>
          <span
            class="contador-solicitud"
            data-expira="${LB.escaparHTML(solicitud.fechaExpiracion || calcularFechaExpiracionDesdeFecha(solicitud.fechaCreacion))}"
          >
            Calculando...
          </span>
        </p>
        <div class="hero-botones">
          <button
            type="button"
            class="btn-principal"
            data-solicitud-tomar="${LB.escaparHTML(solicitud.id)}"
            data-vendedor-id="${LB.escaparHTML(vendedorId)}"
          >
            Tomar solicitud
          </button>

          <a
            href="solicitud-detalle.html?id=${encodeURIComponent(solicitud.id)}"
            class="btn-secundario"
          >
            Ver detalle
          </a>
        </div>
      </article>
    `;
  }


  /* =======================================================
     13. Tomar solicitud

     Reglas:
     - Debe estar PENDIENTE.
     - No debe estar tomada por otro vendedor.
     - El vendedor debe tener saldo virtual suficiente.
     - No puede ser solicitud propia.
     - Pasa a EN_PROCESO.
     - Se asigna vendedorId.
     ======================================================= */

  function tomarSolicitud(solicitudId, vendedorId) {
    sincronizarDesdeLocalStorage();

    const solicitud = buscarSolicitud(solicitudId);
    const vendedor = obtenerUsuario(vendedorId);
    const walletVendedor = obtenerOCrearWallet(vendedorId, "VENDEDOR");

    if (!solicitud) {
      return respuesta(false, "No se encontró la solicitud.");
    }
    const fechaExpiracion = new Date(
      solicitud.fechaExpiracion ||
      calcularFechaExpiracionDesdeFecha(solicitud.fechaCreacion)
    );

    if (!Number.isNaN(fechaExpiracion.getTime()) && new Date() >= fechaExpiracion) {
      completarSolicitudPorSistema(solicitud);
      guardarCambios();

      return respuesta(
        false,
        "La solicitud ya caducó y fue completada automáticamente por el sistema."
      );
    }

    if (!vendedor || !usuarioTieneRol(vendedor, "VENDEDOR")) {
      return respuesta(false, "El usuario actual no tiene permisos de vendedor.");
    }

    if (solicitud.clienteId === vendedorId) {
      return respuesta(false, "No puedes atender una solicitud creada por tu propio usuario.");
    }

    if (
      solicitud.vendedorId &&
      solicitud.vendedorId !== vendedorId &&
      solicitud.estado === "EN_PROCESO"
    ) {
      return respuesta(false, "Esta solicitud ya fue tomada por otro vendedor.");
    }

    if (solicitud.estado !== "PENDIENTE") {
      return respuesta(false, `La solicitud no está pendiente. Estado actual: ${solicitud.estado}.`);
    }

    if (Number(walletVendedor.saldoVirtual || 0) < Number(solicitud.montoSolicitado || 0)) {
      return respuesta(false, "Saldo virtual insuficiente para tomar esta solicitud.");
    }

    solicitud.estado = "EN_PROCESO";
    solicitud.vendedorId = vendedorId;
    solicitud.fechaAsignacion = new Date().toISOString();
    solicitud.fechaResolucion = null;
    solicitud.timerAtencionInicio = new Date().toISOString();
    solicitud.bloqueoBotonesInicio = new Date().toISOString();
    solicitud.observacion = "Solicitud tomada por vendedor. Está en proceso de confirmación.";

    registrarMovimiento({
      usuarioId: vendedorId,
      walletId: walletVendedor.id,
      tipoMovimiento: "TOMA_SOLICITUD",
      tipoDinero: "VIRTUAL",
      monto: solicitud.montoSolicitado,
      comision: 0,
      montoNeto: 0,
      descripcion: `Solicitud ${solicitud.id} tomada por vendedor.`,
      estado: "EN_PROCESO",
      referenciaId: solicitud.id
    });

    guardarCambios();

    return respuesta(
      true,
      "Solicitud tomada correctamente. Ahora está en proceso.",
      {
        solicitud: solicitud
      }
    );
  }


  /* =======================================================
     14. Cancelar solicitud

     Regla pedida:
     - La solicitud vuelve a PENDIENTE.
     - vendedorId se limpia.
     - No se transfiere dinero.
     - El saldo real reservado del cliente se mantiene reservado
       porque la solicitud sigue pendiente.
     ======================================================= */

  function cancelarSolicitud(solicitudId, vendedorId) {
    sincronizarDesdeLocalStorage();

    const solicitud = buscarSolicitud(solicitudId);
    const vendedor = obtenerUsuario(vendedorId);
    const walletVendedor = obtenerOCrearWallet(vendedorId, "VENDEDOR");

    if (!solicitud) {
      return respuesta(false, "No se encontró la solicitud.");
    }

    if (!vendedor || !usuarioTieneRol(vendedor, "VENDEDOR")) {
      return respuesta(false, "El usuario actual no tiene permisos de vendedor.");
    }

    if (solicitud.estado !== "EN_PROCESO") {
      return respuesta(false, "Solo se pueden cancelar solicitudes en proceso.");
    }

    if (solicitud.vendedorId !== vendedorId) {
      return respuesta(false, "No puedes cancelar una solicitud asignada a otro vendedor.");
    }

    solicitud.estado = "PENDIENTE";
    solicitud.vendedorId = null;
    solicitud.fechaAsignacion = null;
    solicitud.fechaResolucion = null;
    solicitud.timerAtencionInicio = null;
    solicitud.bloqueoBotonesInicio = null;
    solicitud.observacion = "Solicitud cancelada por el vendedor. Vuelve a estar pendiente.";

    registrarMovimiento({
      usuarioId: vendedorId,
      walletId: walletVendedor.id,
      tipoMovimiento: "CANCELACION_SOLICITUD",
      tipoDinero: "VIRTUAL",
      monto: solicitud.montoSolicitado,
      comision: 0,
      montoNeto: 0,
      descripcion: `Cancelación de solicitud ${solicitud.id}. No se realizó transferencia.`,
      estado: "CANCELADO",
      referenciaId: solicitud.id
    });

    guardarCambios();

    return respuesta(
      true,
      "Solicitud cancelada. Vuelve a estar pendiente para otro vendedor.",
      {
        solicitud: solicitud
      }
    );
  }


  /* =======================================================
     15. Confirmar solicitud

     Regla financiera:
     - vendedor pierde saldo virtual.
     - cliente gana saldo virtual.
     - vendedor gana saldo real.
     - solicitud pasa a COMPLETADA.
     ======================================================= */

  function confirmarSolicitud(solicitudId, vendedorId) {
    sincronizarDesdeLocalStorage();

    const solicitud = buscarSolicitud(solicitudId);
    const vendedor = obtenerUsuario(vendedorId);

    if (!solicitud) {
      return respuesta(false, "No se encontró la solicitud.");
    }

    if (!vendedor || !usuarioTieneRol(vendedor, "VENDEDOR")) {
      return respuesta(false, "El usuario actual no tiene permisos de vendedor.");
    }

    if (solicitud.estado !== "EN_PROCESO") {
      return respuesta(false, "La solicitud no está en proceso.");
    }

    if (solicitud.vendedorId !== vendedorId) {
      return respuesta(false, "Esta solicitud ya fue tomada por otro vendedor.");
    }

    const monto = redondearDinero(solicitud.montoSolicitado);
    const walletVendedor = obtenerOCrearWallet(vendedorId, "VENDEDOR");
    const walletCliente = obtenerOCrearWallet(solicitud.clienteId, "CLIENTE");

    if (Number(walletVendedor.saldoVirtual || 0) < monto) {
      return respuesta(false, "El vendedor no tiene saldo virtual suficiente para confirmar.");
    }

    walletVendedor.saldoVirtual = redondearDinero(Number(walletVendedor.saldoVirtual || 0) - monto);
    walletVendedor.saldoReal = redondearDinero(Number(walletVendedor.saldoReal || 0) + monto);
    walletVendedor.ultimaActualizacion = new Date().toISOString();

    walletCliente.saldoVirtual = redondearDinero(Number(walletCliente.saldoVirtual || 0) + monto);

    if (Number(walletCliente.saldoRealReservado || 0) > 0) {
      walletCliente.saldoRealReservado = redondearDinero(
        Math.max(0, Number(walletCliente.saldoRealReservado || 0) - monto)
      );
    }

    walletCliente.ultimaActualizacion = new Date().toISOString();

    solicitud.estado = "COMPLETADA";
    solicitud.fechaResolucion = new Date().toISOString();
    solicitud.timerAtencionInicio = null;
    solicitud.bloqueoBotonesInicio = null;
    solicitud.saldoRealReservado = false;
    solicitud.observacion = "Solicitud completada. El vendedor entregó virtual y recibió real equivalente.";

    registrarMovimiento({
      usuarioId: vendedorId,
      walletId: walletVendedor.id,
      tipoMovimiento: "CONFIRMACION_SOLICITUD_VENDEDOR",
      tipoDinero: "VIRTUAL_REAL",
      monto: monto,
      comision: 0,
      montoNeto: monto,
      descripcion: `Confirmación de solicitud ${solicitud.id}. El vendedor entregó virtual y recibió real.`,
      estado: "COMPLETADO",
      referenciaId: solicitud.id
    });

    registrarMovimiento({
      usuarioId: solicitud.clienteId,
      walletId: walletCliente.id,
      tipoMovimiento: "RECEPCION_VIRTUAL_SOLICITUD",
      tipoDinero: "VIRTUAL",
      monto: monto,
      comision: 0,
      montoNeto: monto,
      descripcion: `Recepción de saldo virtual por solicitud ${solicitud.id}.`,
      estado: "COMPLETADO",
      referenciaId: solicitud.id
    });

    guardarCambios();

    return respuesta(
      true,
      `Solicitud confirmada. El cliente recibió ${LB.formatearMoneda(monto)} virtuales y el vendedor recibió ${LB.formatearMoneda(monto)} reales.`,
      {
        solicitud: solicitud,
        walletVendedor: walletVendedor,
        walletCliente: walletCliente
      }
    );
  }


 /* =======================================================
   16. Simular conversión automática por sistema

   Nueva regla:
   - Si una solicitud PENDIENTE pasa de 10 minutos sin ser tomada,
     el sistema la completa automáticamente.
   - El cliente recibe saldo virtual.
   - El saldo real reservado se consume.
   - La solicitud deja de mostrarse a vendedores.
   ======================================================= */

function simularExpiracionSolicitudes() {
  const ahora = new Date();
  let huboCambios = false;

  estado.solicitudes.forEach(function (solicitud) {
    /*
      Solo convertimos automáticamente solicitudes pendientes.
      Si está EN_PROCESO, significa que un vendedor ya la tomó.
    */
    if (solicitud.estado !== "PENDIENTE") {
      return;
    }

    const fechaExpiracion = new Date(
      solicitud.fechaExpiracion ||
      calcularFechaExpiracionDesdeFecha(solicitud.fechaCreacion)
    );

    if (Number.isNaN(fechaExpiracion.getTime())) {
      return;
    }

    if (ahora < fechaExpiracion) {
      return;
    }

    completarSolicitudPorSistema(solicitud);
    huboCambios = true;
  });

  if (huboCambios) {
    guardarCambios();
  }

  return huboCambios;
}

/* =======================================================
   Completar solicitud automáticamente por sistema

   Regla:
   - El cliente ya tenía dinero real reservado.
   - Al pasar 10 minutos sin vendedor, el sistema convierte
     ese real reservado en saldo virtual.
   ======================================================= */
function completarSolicitudPorSistema(solicitud) {
  const walletCliente = obtenerOCrearWallet(solicitud.clienteId, "CLIENTE");
  const monto = redondearDinero(solicitud.montoSolicitado);

  /*
    Se consume el saldo real reservado.
    No se devuelve a saldo real porque la regla actual dice
    que el sistema convierte automáticamente a virtual.
  */
  walletCliente.saldoRealReservado = redondearDinero(
    Math.max(0, Number(walletCliente.saldoRealReservado || 0) - monto)
  );

  walletCliente.saldoVirtual = redondearDinero(
    Number(walletCliente.saldoVirtual || 0) + monto
  );

  walletCliente.ultimaActualizacion = new Date().toISOString();

  solicitud.estado = "COMPLETADA_SISTEMA";
  solicitud.vendedorId = "SISTEMA";
  solicitud.fechaResolucion = new Date().toISOString();
  solicitud.timerAtencionInicio = null;
  solicitud.bloqueoBotonesInicio = null;
  solicitud.saldoRealReservado = false;
  solicitud.observacion =
    "Solicitud completada automáticamente por el sistema al pasar 10 minutos sin vendedor.";

  registrarMovimiento({
    usuarioId: solicitud.clienteId,
    walletId: walletCliente.id,
    tipoMovimiento: "CONVERSION_AUTOMATICA_SISTEMA",
    tipoDinero: "REAL_VIRTUAL",
    monto: monto,
    comision: 0,
    montoNeto: monto,
    descripcion: `Conversión automática por sistema de la solicitud ${solicitud.id}.`,
    estado: "COMPLETADO",
    referenciaId: solicitud.id
  });
}


  /* =======================================================
     17. Liberar reserva de saldo real del cliente

     Se usa cuando una solicitud expira de verdad.
     No se usa al cancelar por vendedor, porque en ese caso
     la solicitud vuelve a estar PENDIENTE.
     ======================================================= */

  function liberarReservaCliente(solicitud) {
    const walletCliente = obtenerOCrearWallet(solicitud.clienteId, "CLIENTE");
    const monto = redondearDinero(solicitud.montoSolicitado);

    if (solicitud.saldoRealReservado === false) {
      return;
    }

    const reservadoActual = Number(walletCliente.saldoRealReservado || 0);

    if (reservadoActual <= 0) {
      return;
    }

    const montoLiberar = Math.min(reservadoActual, monto);

    walletCliente.saldoRealReservado = redondearDinero(reservadoActual - montoLiberar);
    walletCliente.saldoReal = redondearDinero(Number(walletCliente.saldoReal || 0) + montoLiberar);
    walletCliente.ultimaActualizacion = new Date().toISOString();

    solicitud.saldoRealReservado = false;
  }


  /* =======================================================
     18. Registrar movimiento
     ======================================================= */

  function registrarMovimiento(datos) {
    const movimiento = {
      id: datos.id || generarId("MOV"),
      usuarioId: datos.usuarioId,
      walletId: datos.walletId,
      tipoMovimiento: datos.tipoMovimiento,
      tipoDinero: datos.tipoDinero,
      monto: redondearDinero(datos.monto || 0),
      comision: redondearDinero(datos.comision || 0),
      montoNeto: redondearDinero(datos.montoNeto || 0),
      descripcion: datos.descripcion || "Movimiento de solicitud simulado.",
      fecha: datos.fecha || new Date().toISOString(),
      estado: datos.estado || "COMPLETADO",
      referenciaId: datos.referenciaId || null
    };

    estado.movimientos.push(movimiento);

    return movimiento;
  }


  /* =======================================================
     19. Renderizar detalle de solicitud

     Esta función sirve para pages/solicitud-detalle.html.
     ======================================================= */

  function renderizarDetalleSolicitud(selector, solicitudId, vendedorId) {
    sincronizarDesdeLocalStorage();

    const contenedor = document.querySelector(selector);

    if (!contenedor) {
      return respuesta(false, "No se encontró el contenedor de detalle.");
    }

    const solicitud = buscarSolicitud(solicitudId);

    if (!solicitud) {
      contenedor.innerHTML = `
        <div class="alerta alerta-error">
          No se encontró la solicitud solicitada.
        </div>
      `;

      return respuesta(false, "No se encontró la solicitud.");
    }

    const cliente = obtenerUsuario(solicitud.clienteId);
    const vendedorAsignado = solicitud.vendedorId ? obtenerUsuario(solicitud.vendedorId) : null;
    const walletVendedor = vendedorId ? obtenerOCrearWallet(vendedorId, "VENDEDOR") : null;

    const clienteTexto = cliente
      ? `${cliente.nombres} ${cliente.apellidos} (${cliente.usuario})`
      : "Cliente no encontrado";

    const vendedorTexto = vendedorAsignado
      ? `${vendedorAsignado.nombres} ${vendedorAsignado.apellidos} (${vendedorAsignado.usuario})`
      : "Sin vendedor asignado";

    const saldoVirtualVendedor = walletVendedor
      ? LB.formatearMoneda(walletVendedor.saldoVirtual)
      : "Sin vendedor actual";

    const costoEstimadoVirtual = redondearDinero(solicitud.montoSolicitado * 0.90);
    const gananciaPotencial = redondearDinero(solicitud.montoSolicitado - costoEstimadoVirtual);

    contenedor.innerHTML = `
      <div class="grid-tarjetas">
        <article class="tarjeta">
          ${LB.crearBadgeEstado(solicitud.estado)}
          <h3>Solicitud ${LB.escaparHTML(solicitud.id)}</h3>

          <p><strong>Cliente solicitante:</strong> ${LB.escaparHTML(clienteTexto)}</p>
          <p><strong>Monto solicitado:</strong> ${LB.formatearMoneda(solicitud.montoSolicitado)}</p>
          <p><strong>Estado:</strong> ${LB.crearBadgeEstado(solicitud.estado)}</p>
          <p><strong>Fecha:</strong> ${LB.formatearFechaHora(solicitud.fechaCreacion)}</p>
        </article>

        <article class="tarjeta">
          <span class="badge badge-info">Asignación</span>
          <h3>Vendedor asignado</h3>

          <p><strong>Vendedor:</strong> ${LB.escaparHTML(vendedorTexto)}</p>
          <p><strong>Saldo virtual vendedor actual:</strong> ${saldoVirtualVendedor}</p>
          <p><strong>Fecha asignación:</strong> ${solicitud.fechaAsignacion ? LB.formatearFechaHora(solicitud.fechaAsignacion) : "Sin asignar"}</p>
        </article>

        <article class="tarjeta">
          <span class="badge badge-dorado">Ganancia vendedor</span>
          <h3>Regla 0.90</h3>

          <p>
            Para atender ${LB.formatearMoneda(solicitud.montoSolicitado)} virtuales,
            el costo estimado del vendedor sería ${LB.formatearMoneda(costoEstimadoVirtual)}.
          </p>

          <p><strong>Real que recibe al confirmar:</strong> ${LB.formatearMoneda(solicitud.montoSolicitado)}</p>
          <p><strong>Ganancia potencial:</strong> ${LB.formatearMoneda(gananciaPotencial)}</p>
        </article>
      </div>

      <div class="alerta alerta-info">
        ${LB.escaparHTML(solicitud.observacion || "Solicitud cargada correctamente.")}
      </div>
    `;

    return respuesta(true, "Detalle renderizado.", {
      solicitud: solicitud
    });
  }


  /* =======================================================
     20. Obtener datos de temporizador visual

     Sirve para pintar cuenta regresiva de 2 minutos.
     ======================================================= */

  function obtenerTiempoAtencionRestante(solicitudId) {
    const solicitud = buscarSolicitud(solicitudId);

    if (!solicitud || solicitud.estado !== "EN_PROCESO") {
      return {
        segundosRestantes: 0,
        texto: "Finalizado"
      };
    }

    const inicio = new Date(
      solicitud.timerAtencionInicio ||
      solicitud.fechaAsignacion ||
      new Date()
    );

    const fin = new Date(inicio.getTime() + CONFIG.SEGUNDOS_ATENCION_VISUAL * 1000);
    const ahora = new Date();

    const diferencia = Math.max(0, Math.floor((fin - ahora) / 1000));
    const minutos = Math.floor(diferencia / 60);
    const segundos = diferencia % 60;

    return {
      segundosRestantes: diferencia,
      texto: `${String(minutos).padStart(2, "0")}:${String(segundos).padStart(2, "0")}`
    };
  }


  /* =======================================================
     21. Obtener datos de bloqueo visual

     Sirve para bloquear botones por 10 segundos.
     ======================================================= */

  function obtenerBloqueoBotonesRestante(solicitudId) {
    const solicitud = buscarSolicitud(solicitudId);

    if (!solicitud || solicitud.estado !== "EN_PROCESO") {
      return {
        bloqueado: true,
        segundosRestantes: 0,
        texto: "Botones no disponibles para el estado actual."
      };
    }

    const inicio = new Date(
      solicitud.bloqueoBotonesInicio ||
      solicitud.fechaAsignacion ||
      new Date()
    );

    const ahora = new Date();
    const segundosPasados = Math.floor((ahora - inicio) / 1000);
    const segundosRestantes = Math.max(0, CONFIG.SEGUNDOS_BLOQUEO_BOTONES - segundosPasados);

    return {
      bloqueado: segundosRestantes > 0,
      segundosRestantes: segundosRestantes,
      texto: segundosRestantes > 0
        ? `Botones disponibles en ${segundosRestantes} segundo(s).`
        : "Validación visual completada. Ya puede confirmar o cancelar."
    };
  }


  /* =======================================================
     22. Funciones de búsqueda
     ======================================================= */

  function buscarSolicitud(solicitudId) {
    return estado.solicitudes.find(function (solicitud) {
      return solicitud.id === solicitudId;
    }) || null;
  }


  function obtenerUsuario(usuarioId) {
    return estado.usuarios.find(function (usuario) {
      return usuario.id === usuarioId;
    }) || null;
  }


  function obtenerOCrearWallet(usuarioId, tipoUsuario = "CLIENTE") {
    let wallet = estado.wallets.find(function (item) {
      return item.usuarioId === usuarioId;
    });

    if (!wallet) {
      wallet = {
        id: generarId("WAL"),
        usuarioId: usuarioId,
        tipoUsuario: tipoUsuario,
        saldoReal: 0,
        saldoVirtual: 0,
        saldoRealReservado: 0,
        saldoVirtualReservado: 0,
        gananciasGeneradas: 0,
        moneda: "USD",
        estado: "ACTIVA",
        ultimaActualizacion: new Date().toISOString()
      };

      estado.wallets.push(wallet);
    }

    return wallet;
  }


  /* =======================================================
     23. Obtener copias de datos

     Se devuelven copias para evitar modificaciones externas
     directas sin pasar por funciones controladas.
     ======================================================= */

  function obtenerSolicitudes() {
    return JSON.parse(JSON.stringify(estado.solicitudes));
  }


  function obtenerMovimientos() {
    return JSON.parse(JSON.stringify(estado.movimientos));
  }


  function obtenerWallets() {
    return JSON.parse(JSON.stringify(estado.wallets));
  }


  /* =======================================================
     24. Utilidades internas
     ======================================================= */

  function usuarioTieneRol(usuario, rol) {
    return Array.isArray(usuario.roles) && usuario.roles.includes(rol);
  }


  function normalizarMonto(valor) {
    const numero = Number(valor);

    if (Number.isNaN(numero)) {
      return 0;
    }

    return redondearDinero(numero);
  }


  function redondearDinero(valor) {
    return Math.round(Number(valor) * 100) / 100;
  }


  function generarId(prefijo) {
    return `${prefijo}-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
  }


  function calcularFechaExpiracion() {
    const fecha = new Date();
    fecha.setMinutes(fecha.getMinutes() + CONFIG.MINUTOS_EXPIRACION_SOLICITUD);
    return fecha.toISOString();
  }


  function calcularFechaExpiracionDesdeFecha(fechaBase) {
    const fecha = new Date(fechaBase);

    if (Number.isNaN(fecha.getTime())) {
      return calcularFechaExpiracion();
    }

    fecha.setMinutes(fecha.getMinutes() + CONFIG.MINUTOS_EXPIRACION_SOLICITUD);
    return fecha.toISOString();
  }


  function respuesta(ok, mensaje, datos = {}) {
    return {
      ok: ok,
      mensaje: mensaje,
      datos: datos
    };
  }


  /* =======================================================
     25. API pública del módulo
     ======================================================= */

  return {
    inicializar,
    guardarCambios,
    sincronizarDesdeLocalStorage,

    crearSolicitudCliente,
    mostrarSolicitudesPendientesVendedor,
    obtenerSolicitudesPendientesParaVendedor,

    tomarSolicitud,
    cancelarSolicitud,
    confirmarSolicitud,
    simularExpiracionSolicitudes,
    actualizarContadoresSolicitudes,

    renderizarDetalleSolicitud,
    obtenerTiempoAtencionRestante,
    obtenerBloqueoBotonesRestante,

    buscarSolicitud,
    obtenerSolicitudes,
    obtenerMovimientos,
    obtenerWallets
  };
})();


/* =========================================================
   26. Integración automática con páginas HTML

   Este bloque permite que solicitudes.js funcione
   automáticamente si detecta elementos específicos.

   Compatible con:
   - pages/solicitud-detalle.html
   - futuras secciones de cliente para crear solicitudes
   - futuras secciones de vendedor para listar solicitudes
   ========================================================= */

document.addEventListener("DOMContentLoaded", async function () {
  if (typeof LB === "undefined") {
    return;
  }

  await LBSolicitudes.inicializar();

  activarFormularioCrearSolicitudCliente();
  activarListadoVendedorAutomatico();
  activarDetalleSolicitudAutomatico();
  activarEventosGlobalesSolicitudes();
  setInterval(function () {
  LBSolicitudes.simularExpiracionSolicitudes();
  LBSolicitudes.actualizarContadoresSolicitudes();

  const usuarioActual = LB.obtenerUsuarioActual();

  if (document.querySelector("#listaSolicitudesVendedor") && usuarioActual) {
    LBSolicitudes.mostrarSolicitudesPendientesVendedor(
      "#listaSolicitudesVendedor",
      usuarioActual.id
    );
  }
}, 1000);
});


/* =========================================================
   27. Formulario para crear solicitud desde cliente

   Para usarlo en una página:
   form id="formCrearSolicitudCliente"
   input id="montoSolicitudCliente"
   div id="mensajeSolicitudCliente"
   ========================================================= */

function activarFormularioCrearSolicitudCliente() {
  const form = document.querySelector("#formCrearSolicitudCliente");

  if (!form) {
    return;
  }

  form.addEventListener("submit", function (evento) {
    evento.preventDefault();

    const usuarioActual = LB.obtenerUsuarioActual();
    const inputMonto = document.querySelector("#montoSolicitudCliente");
    const monto = Number(inputMonto ? inputMonto.value : 0);

    if (!usuarioActual) {
      LB.mostrarAlerta("#mensajeSolicitudCliente", "Debe iniciar sesión para crear una solicitud.", "error");
      return;
    }

    const resultado = LBSolicitudes.crearSolicitudCliente(
      usuarioActual.id,
      monto,
      "Solicitud creada desde formulario de cliente."
    );

    LB.mostrarAlerta(
      "#mensajeSolicitudCliente",
      resultado.mensaje,
      resultado.ok ? "exito" : "error"
    );

    if (resultado.ok) {
      form.reset();
    }
  });
}


/* =========================================================
   28. Listado automático para vendedor

   Para usarlo en una página:
   div id="listaSolicitudesVendedor"
   ========================================================= */

function activarListadoVendedorAutomatico() {
  const contenedor = document.querySelector("#listaSolicitudesVendedor");

  if (!contenedor) {
    return;
  }

  const usuarioActual = LB.obtenerUsuarioActual();

  if (!usuarioActual) {
    contenedor.innerHTML = `
      <div class="alerta alerta-error">
        Debe iniciar sesión para ver solicitudes.
      </div>
    `;
    return;
  }

  LBSolicitudes.mostrarSolicitudesPendientesVendedor(
    "#listaSolicitudesVendedor",
    usuarioActual.id
  );
}


/* =========================================================
   29. Detalle automático de solicitud

   Compatible con:
   solicitud-detalle.html?id=SOL-001

   Contenedores esperados:
   - #detalleSolicitud
   - #mensajeSolicitudDetalle
   - #btnConfirmarSolicitud
   - #btnCancelarSolicitud
   - #temporizadorDosMinutos
   - #estadoBloqueoBotones
   ========================================================= */

function activarDetalleSolicitudAutomatico() {
  const contenedorDetalle = document.querySelector("#detalleSolicitud");

  if (!contenedorDetalle) {
    return;
  }

  const usuarioActual = LB.obtenerUsuarioActual();
  const solicitudId = LB.obtenerParametroURL("id");

  if (!usuarioActual) {
    LB.mostrarAlerta(
      "#mensajeSolicitudDetalle",
      "Debe iniciar sesión para ver el detalle de la solicitud.",
      "error"
    );
    return;
  }

  if (!solicitudId) {
    LB.renderizarHTML(
      "#detalleSolicitud",
      `
        <div class="alerta alerta-error">
          No se recibió el ID de la solicitud.
        </div>
      `
    );
    return;
  }

  const solicitud = LBSolicitudes.buscarSolicitud(solicitudId);

  if (!solicitud) {
    LB.renderizarHTML(
      "#detalleSolicitud",
      `
        <div class="alerta alerta-error">
          No se encontró la solicitud.
        </div>
      `
    );
    return;
  }

  if (
    solicitud.vendedorId &&
    solicitud.vendedorId !== usuarioActual.id &&
    solicitud.estado === "EN_PROCESO"
  ) {
    LB.mostrarAlerta(
      "#mensajeSolicitudDetalle",
      "Esta solicitud ya fue tomada por otro vendedor",
      "advertencia"
    );
  }

  if (solicitud.estado === "PENDIENTE") {
    const resultadoTomar = LBSolicitudes.tomarSolicitud(solicitudId, usuarioActual.id);

    LB.mostrarAlerta(
      "#mensajeSolicitudDetalle",
      resultadoTomar.mensaje,
      resultadoTomar.ok ? "exito" : "error"
    );
  }

  LBSolicitudes.renderizarDetalleSolicitud(
    "#detalleSolicitud",
    solicitudId,
    usuarioActual.id
  );

  actualizarTemporizadoresDetalle(solicitudId);
  setInterval(function () {
    actualizarTemporizadoresDetalle(solicitudId);
  }, 1000);
}


/* =========================================================
   30. Actualizar temporizadores en detalle
   ========================================================= */

function actualizarTemporizadoresDetalle(solicitudId) {
  const tiempo = LBSolicitudes.obtenerTiempoAtencionRestante(solicitudId);
  const bloqueo = LBSolicitudes.obtenerBloqueoBotonesRestante(solicitudId);

  const contenedorTiempo = document.querySelector("#temporizadorDosMinutos");
  const contenedorBloqueo = document.querySelector("#estadoBloqueoBotones");
  const btnConfirmar = document.querySelector("#btnConfirmarSolicitud");
  const btnCancelar = document.querySelector("#btnCancelarSolicitud");

  if (contenedorTiempo) {
    contenedorTiempo.textContent = tiempo.texto;
  }

  if (contenedorBloqueo) {
    contenedorBloqueo.textContent = bloqueo.texto;
  }

  const solicitud = LBSolicitudes.buscarSolicitud(solicitudId);
  const usuarioActual = LB.obtenerUsuarioActual();

  const botonesDisponibles =
    solicitud &&
    usuarioActual &&
    solicitud.estado === "EN_PROCESO" &&
    solicitud.vendedorId === usuarioActual.id &&
    !bloqueo.bloqueado;

  if (btnConfirmar) {
    btnConfirmar.disabled = !botonesDisponibles;
  }

  if (btnCancelar) {
    btnCancelar.disabled = !botonesDisponibles;
  }
}


/* =========================================================
   31. Eventos globales de solicitudes

   Maneja:
   - Botones para tomar solicitud.
   - Confirmar desde detalle.
   - Cancelar desde detalle.
   ========================================================= */

function activarEventosGlobalesSolicitudes() {
  document.addEventListener("click", function (evento) {
    const btnTomar = evento.target.closest("[data-solicitud-tomar]");
    const btnConfirmar = evento.target.closest("#btnConfirmarSolicitud");
    const btnCancelar = evento.target.closest("#btnCancelarSolicitud");

    if (btnTomar) {
      const solicitudId = btnTomar.getAttribute("data-solicitud-tomar");
      const vendedorId = btnTomar.getAttribute("data-vendedor-id");

      const resultado = LBSolicitudes.tomarSolicitud(solicitudId, vendedorId);

      const contenedorMensaje = document.querySelector("#mensajeVendedor")
        ? "#mensajeVendedor"
        : "#mensajeSolicitudDetalle";

      LB.mostrarAlerta(
        contenedorMensaje,
        resultado.mensaje,
        resultado.ok ? "exito" : "error"
      );

      const usuarioActual = LB.obtenerUsuarioActual();

      if (document.querySelector("#listaSolicitudesVendedor") && usuarioActual) {
        LBSolicitudes.mostrarSolicitudesPendientesVendedor(
          "#listaSolicitudesVendedor",
          usuarioActual.id
        );
      }
    }

    if (btnConfirmar) {
      const usuarioActual = LB.obtenerUsuarioActual();
      const solicitudId = LB.obtenerParametroURL("id");

      if (!usuarioActual || !solicitudId) {
        return;
      }

      const resultado = LBSolicitudes.confirmarSolicitud(solicitudId, usuarioActual.id);

      LB.mostrarAlerta(
        "#mensajeSolicitudDetalle",
        resultado.mensaje,
        resultado.ok ? "exito" : "error"
      );

      LBSolicitudes.renderizarDetalleSolicitud(
        "#detalleSolicitud",
        solicitudId,
        usuarioActual.id
      );
    }

    if (btnCancelar) {
      const usuarioActual = LB.obtenerUsuarioActual();
      const solicitudId = LB.obtenerParametroURL("id");

      if (!usuarioActual || !solicitudId) {
        return;
      }

      const resultado = LBSolicitudes.cancelarSolicitud(solicitudId, usuarioActual.id);

      LB.mostrarAlerta(
        "#mensajeSolicitudDetalle",
        resultado.mensaje,
        resultado.ok ? "advertencia" : "error"
      );

      LBSolicitudes.renderizarDetalleSolicitud(
        "#detalleSolicitud",
        solicitudId,
        usuarioActual.id
      );
    }
  });
}


/* =======================================================
   Actualizar contadores de caducidad de solicitudes
   ======================================================= */

function actualizarContadoresSolicitudes() {
  const contadores = document.querySelectorAll(".contador-solicitud");

  contadores.forEach(function (contador) {
    const fechaExpira = new Date(contador.getAttribute("data-expira"));
    const ahora = new Date();

    if (Number.isNaN(fechaExpira.getTime())) {
      contador.textContent = "Sin fecha";
      return;
    }

    const diferencia = Math.max(0, Math.floor((fechaExpira - ahora) / 1000));

    const minutos = Math.floor(diferencia / 60);
    const segundos = diferencia % 60;

    contador.textContent =
      String(minutos).padStart(2, "0") +
      ":" +
      String(segundos).padStart(2, "0");

    if (diferencia <= 0) {
      contador.textContent = "Procesando por sistema...";
    }
  });
}