# Loteria Binaria - README tecnico del proyecto

## 1. Datos generales

**Proyecto:** Loteria Binaria  
**Autor:** Cristhian Herrera Nieto  
**Entrega:** Proyecto final del primer parcial  
**Tipo:** Frontend demostrativo academico  
**Tecnologias:** HTML5, CSS3, JavaScript puro, JSON, Fetch API, DOM y localStorage  

Loteria Binaria es una plataforma web demostrativa para simular un sistema de sorteos digitales con roles de cliente, vendedor y administrador. El proyecto no usa backend, base de datos real, API real, Node.js, React, Django ni pasarela de pago. Toda la informacion inicial se carga desde archivos JSON y los cambios realizados en la interfaz se guardan de manera simulada en localStorage.

---

## 2. Alcance de la entrega

Esta entrega corresponde al primer parcial y cubre la construccion del frontend navegable del sistema. El objetivo es demostrar el flujo visual y logico de una plataforma de loterias digitales, incluyendo inicio de sesion, seleccion de rol, compra de boletos, manejo de wallets, solicitudes cliente-vendedor, administracion de sorteos y estadisticas generales.

### Incluye

- Pagina principal o landing page.
- Inicio de sesion simulado.
- Registro visual de usuarios.
- Seleccion de modo de acceso para vendedores y administradores.
- Panel de cliente.
- Panel de vendedor.
- Panel de administrador.
- Detalle de sorteo.
- Detalle de boleto.
- Detalle de solicitud.
- Datos simulados en JSON.
- Persistencia temporal con localStorage.
- Diseno responsive para escritorio, tablet y movil.

### No incluye

- Backend real.
- Base de datos real.
- Escritura real sobre archivos JSON desde el navegador.
- Autenticacion segura real.
- Pasarela de pago real.
- Servicios externos.
- Sorteos legales reales.
- Despliegue con servidor de produccion.

---

## 3. Estructura del proyecto

```text
Proyecto_HerreraNietoCristhian/
├── index.html
├── README.md
├── lista.txt
├── assets/
│   └── img/
│       └── logo-placeholder.png
├── css/
│   ├── animations.css
│   ├── responsive.css
│   └── styles.css
├── data/
│   ├── boletos.json
│   ├── eventos.json
│   ├── movimientos.json
│   ├── solicitudes.json
│   ├── sorteos.json
│   ├── usuarios.json
│   └── wallets.json
├── js/
│   ├── admin.js
│   ├── auth.js
│   ├── cliente.js
│   ├── main.js
│   ├── solicitudes.js
│   ├── sorteos.js
│   ├── utils.js
│   ├── vendedor.js
│   └── wallets.js
└── pages/
    ├── admin.html
    ├── boleto-detalle.html
    ├── cliente.html
    ├── elegir-rol.html
    ├── login.html
    ├── registro.html
    ├── solicitud-detalle.html
    ├── sorteo-detalle.html
    └── vendedor.html
```

---

## 4. Archivos HTML principales

| Archivo | Funcion |
|---|---|
| `index.html` | Landing page del proyecto. Presenta la plataforma, roles, reglas y tipos de loteria. |
| `pages/login.html` | Inicio de sesion simulado con usuarios de `data/usuarios.json`. |
| `pages/registro.html` | Formulario de registro visual de clientes. No modifica JSON real. |
| `pages/elegir-rol.html` | Pantalla para elegir modo de acceso cuando el usuario tiene permisos multiples. |
| `pages/cliente.html` | Dashboard del cliente: resumen, sorteos, wallet, solicitudes, envios y boletos. |
| `pages/vendedor.html` | Dashboard del vendedor: wallet, movimientos, compra virtual, solicitudes y envios permitidos. |
| `pages/admin.html` | Panel administrador: usuarios, sorteos, solicitudes, movimientos y estadisticas. |
| `pages/sorteo-detalle.html` | Detalle de un sorteo o evento. Permite comprar boleto si el evento esta disponible. |
| `pages/boleto-detalle.html` | Detalle de un boleto comprado. Muestra estado, resultado y sorteo asociado. |
| `pages/solicitud-detalle.html` | Detalle de solicitud cliente-vendedor con temporizadores y acciones de vendedor. |

---

## 5. Archivos CSS

| Archivo | Funcion |
|---|---|
| `css/styles.css` | Estilos base: colores, layout, botones, tarjetas, tablas, formularios, paneles y footer. |
| `css/responsive.css` | Adaptacion a tablet y movil. Incluye ajustes para tablas, sidebar y menu overlay movil. |
| `css/animations.css` | Animaciones visuales y transiciones para mejorar la experiencia. |

La paleta visual se basa en tonos oscuros, azul profundo y dorado para comunicar tecnologia, premios, seguridad y entorno digital.

---

## 6. Archivos JavaScript

| Archivo | Responsabilidad principal |
|---|---|
| `js/utils.js` | Modulo global `LB` con funciones reutilizables: cargar JSON, formatear moneda, fechas, alertas, tablas, sesion y rutas. |
| `js/main.js` | Inicializacion general, acciones comunes, resumen de sesion y menu movil tipo overlay. |
| `js/auth.js` | Login simulado, registro visual y seleccion de modo de acceso. |
| `js/cliente.js` | Logica del panel cliente: wallet, sorteos, compra de boletos, movimientos, envios y boletos comprados. |
| `js/vendedor.js` | Logica del panel vendedor: wallet, compra de virtual, conversiones, solicitudes y atencion cliente-vendedor. |
| `js/admin.js` | Logica del panel administrador: usuarios, sorteos, eventos, solicitudes, movimientos y estadisticas. |
| `js/sorteos.js` | Detalle de sorteos, validacion Octal/Decimal/Hexadecimal, compra de boleto y detalle de boleto. |
| `js/solicitudes.js` | Modulo centralizado para solicitudes cliente-vendedor, timers, expiracion y conversion automatica. |
| `js/wallets.js` | Modulo centralizado de wallets, saldos, movimientos, conversiones y validaciones financieras. |

---

## 7. Datos simulados

| Archivo | Registros | Descripcion |
|---|---:|---|
| `data/usuarios.json` | 6 | Usuarios demo con roles, credenciales y permisos. |
| `data/sorteos.json` | 4 | Configuraciones de sorteos Octal, Decimal y Hexadecimal. |
| `data/eventos.json` | 5 | Eventos de sorteo con fechas, estados, premios y disponibilidad. |
| `data/boletos.json` | 7 | Boletos comprados y sus resultados. |
| `data/wallets.json` | 6 | Wallets con saldo real, virtual y reservas. |
| `data/movimientos.json` | 10 | Historial de movimientos financieros simulados. |
| `data/solicitudes.json` | 1 | Solicitudes cliente-vendedor para convertir real a virtual. |

> Nota tecnica: al ser un frontend puro, los cambios nunca se escriben fisicamente sobre los archivos JSON. Los cambios quedan en localStorage.

---

## 8. Usuarios demo

| Rol principal | Usuario | Correo | Contrasena | Roles | Estado |
|---|---|---|---|---|---|
| CLIENTE | `cliente_demo` | `cliente@loteriabinaria.com` | `123456` | CLIENTE | ACTIVO |
| CLIENTE | `cliente_premiado` | `cliente2@loteriabinaria.com` | `123456` | CLIENTE | ACTIVO |
| VENDEDOR | `vendedor_demo` | `vendedor@loteriabinaria.com` | `123456` | VENDEDOR, CLIENTE | ACTIVO |
| VENDEDOR | `vendedora_demo` | `vendedora@loteriabinaria.com` | `123456` | VENDEDOR, CLIENTE | ACTIVO |
| ADMIN | `admin_demo` | `admin@loteriabinaria.com` | `123456` | ADMIN, VENDEDOR, CLIENTE | ACTIVO |
| CLIENTE | `cliente_inactivo` | `cliente.inactivo@loteriabinaria.com` | `123456` | CLIENTE | INACTIVO |

---

## 9. Roles y permisos

### Cliente

El cliente puede:

- Iniciar sesion.
- Consultar sorteos disponibles.
- Comprar boletos con saldo virtual.
- Consultar boletos comprados.
- Filtrar boletos por antiguedad, tipo y estado.
- Acreditar dinero real con tarjeta simulada.
- Convertir dinero virtual a real con comision del 15%.
- Crear solicitudes para recibir dinero virtual mediante vendedor o sistema automatico.
- Enviar dinero virtual a otros clientes.
- Consultar movimientos.

### Vendedor

El vendedor puede:

- Iniciar sesion y elegir modo vendedor o modo cliente.
- Consultar wallet y movimientos.
- Comprar dinero virtual con tarifa preferencial: 1 virtual cuesta 0.90 real.
- Atender solicitudes de clientes si tiene saldo virtual suficiente.
- Confirmar o cancelar solicitudes.
- Enviar dinero virtual permitido a clientes.
- Convertir virtual a real con comision del 15%.
- Retirar dinero real de forma simulada.

El vendedor no puede comprar boletos ni participar en sorteos cuando esta en modo vendedor.

### Administrador

El administrador puede:

- Gestionar usuarios.
- Activar o desactivar usuarios.
- Convertir clientes a vendedores.
- Convertir vendedores a administradores.
- Eliminar usuarios visualmente.
- Configurar sorteos Octal, Decimal y Hexadecimal.
- Generar o actualizar eventos proximos de sorteos.
- Revisar solicitudes globales.
- Revisar movimientos globales.
- Consultar estadisticas.

---

## 10. Modos de acceso

El sistema diferencia entre rol real y modo activo.

| Usuario real | Modo activo | Puede comprar boletos | Puede atender solicitudes | Puede administrar |
|---|---|---:|---:|---:|
| Cliente | CLIENTE | Si | No | No |
| Vendedor | VENDEDOR | No | Si | No |
| Vendedor | CLIENTE | Si | No | No |
| Administrador | ADMIN | No | No | Si |
| Administrador | VENDEDOR | No | Si | No |
| Administrador | CLIENTE | Si | No | No |

El modo activo se guarda en localStorage con las claves:

```text
loteriaBinaria_rolActivo
loteriaBinaria_modoAcceso
```

---

## 11. Tipos de loteria

| Tipo | Caracteres permitidos | Ejemplo | Descripcion |
|---|---|---|---|
| Octal | 0 al 7 | `1234` | Sorteo basado en numeracion octal. |
| Decimal | 0 al 9 | `57291` | Sorteo basado en numeracion decimal tradicional. |
| Hexadecimal | 0 al 9 y A-F | `A7F2` | Sorteo con caracteres hexadecimales. |

Cada sorteo puede tener configuracion de cantidad de digitos, precio de boleto, premio base, porcentaje de acumulacion, frecuencia, fecha inicial y cierre de ventas.

---

## 12. Reglas de premios

- Premio base = valor del boleto x 5.
- Premio secundario = devolucion del valor del boleto si el usuario acierta todos los caracteres menos uno.
- Premio acumulado = puede crecer con el 75% de ventas nuevas luego de cubrir costos.
- Si nadie gana, el premio puede acumularse para eventos posteriores.

---

## 13. Wallet y reglas financieras

El sistema maneja dos saldos principales:

- Saldo real.
- Saldo virtual.

### Acreditacion con tarjeta

La acreditacion con tarjeta es simulada y aplica una comision del 5%.

Ejemplo:

```text
Pago con tarjeta: $100.00
Comision 5%: $5.00
Saldo real acreditado: $95.00
```

### Conversion virtual a real

La conversion de dinero virtual a dinero real aplica una comision del 15%.

```text
Virtual convertido: $100.00
Comision 15%: $15.00
Saldo real recibido: $85.00
```

### Compra virtual del vendedor

El vendedor compra dinero virtual con tarifa preferencial:

```text
1.00 virtual = 0.90 real
100 virtual = 90 real
Ganancia potencial = 10 real
```

### Conversion real a virtual

La conversion real a virtual no se realiza directamente desde el cliente. El flujo correcto es:

1. El cliente crea una solicitud.
2. El saldo real se reserva.
3. Un vendedor puede atender la solicitud.
4. Si el vendedor confirma, el cliente recibe virtual.
5. Si pasan 10 minutos sin atencion, el sistema convierte automaticamente el saldo real reservado en saldo virtual.

---

## 14. Solicitudes cliente-vendedor

Las solicitudes permiten que un cliente convierta dinero real en dinero virtual mediante vendedores.

### Estados principales

| Estado | Descripcion |
|---|---|
| `PENDIENTE` | La solicitud esta disponible para vendedores con saldo suficiente. |
| `EN_PROCESO` | Un vendedor tomo la solicitud. |
| `COMPLETADA` | El vendedor confirmo y se realizo la transferencia. |
| `CANCELADA` | La solicitud fue cancelada. |
| `EXPIRADA` | Estado historico de solicitudes vencidas. |
| `COMPLETADA_SISTEMA` | El sistema convirtio automaticamente al pasar 10 minutos. |

### Flujo de solicitud

```text
Cliente crea solicitud
        ↓
Saldo real queda reservado
        ↓
Vendedores la ven si tienen saldo virtual suficiente
        ↓
Vendedor toma solicitud
        ↓
Estado EN_PROCESO
        ↓
Botones se bloquean visualmente por 10 segundos
        ↓
Vendedor confirma o cancela
```

### Expiracion automatica

Si la solicitud permanece pendiente durante 10 minutos:

- Desaparece de la lista de vendedores.
- Pasa a `COMPLETADA_SISTEMA`.
- El cliente recibe saldo virtual.
- Se consume el saldo real reservado.
- Se registra un movimiento `CONVERSION_AUTOMATICA_SISTEMA`.

---

## 15. localStorage

El sistema utiliza localStorage para simular persistencia. Las claves principales son:

| Clave | Contenido |
|---|---|
| `loteriaBinaria_usuarioActual` | Usuario autenticado. |
| `loteriaBinaria_rolActivo` | Rol o modo activo. |
| `loteriaBinaria_modoAcceso` | Modo seleccionado por el usuario. |
| `loteriaBinaria_usuariosDemo` | Usuarios modificados visualmente. |
| `loteriaBinaria_walletsDemo` | Wallets actualizadas. |
| `loteriaBinaria_movimientosDemo` | Movimientos generados. |
| `loteriaBinaria_sorteosDemo` | Sorteos configurados desde admin. |
| `loteriaBinaria_eventosDemo` | Eventos generados o actualizados. |
| `loteriaBinaria_boletosDemo` | Boletos comprados en la demo. |
| `loteriaBinaria_solicitudesDemo` | Solicitudes creadas o modificadas. |

Para limpiar la demo:

```js
localStorage.clear();
location.reload();
```

O limpiar solo los datos principales:

```js
localStorage.removeItem("loteriaBinaria_sorteosDemo");
localStorage.removeItem("loteriaBinaria_eventosDemo");
localStorage.removeItem("loteriaBinaria_boletosDemo");
localStorage.removeItem("loteriaBinaria_walletsDemo");
localStorage.removeItem("loteriaBinaria_movimientosDemo");
localStorage.removeItem("loteriaBinaria_solicitudesDemo");
location.reload();
```

---

## 16. Flujo de instalacion y ejecucion

### Requisitos

- Navegador moderno.
- Visual Studio Code.
- Extension Live Server.

### Ejecucion recomendada

1. Abrir la carpeta del proyecto en VS Code.
2. Verificar que `index.html` este en la raiz.
3. Clic derecho sobre `index.html`.
4. Seleccionar `Open with Live Server`.
5. Navegar desde la landing page.

No se recomienda abrir los HTML con doble clic, porque `fetch()` puede fallar por restricciones del navegador al cargar archivos JSON con protocolo `file://`.

---

## 17. Pruebas recomendadas

### Login

- Ingresar como `cliente_demo`.
- Ingresar como `vendedor_demo` y elegir modo vendedor.
- Ingresar como `vendedor_demo` y elegir modo cliente.
- Ingresar como `admin_demo` y elegir modo admin.
- Ingresar como `admin_demo` y elegir modo cliente.

### Cliente

- Revisar resumen.
- Revisar wallet.
- Acreditar dinero real.
- Crear solicitud de saldo virtual.
- Comprar boleto si tiene saldo virtual suficiente.
- Revisar boletos comprados.
- Ver detalle de boleto.
- Enviar dinero virtual a otro cliente.

### Vendedor

- Comprar dinero virtual con regla 0.90.
- Revisar solicitudes disponibles.
- Ver contador de caducidad.
- Tomar solicitud.
- Esperar bloqueo visual de botones.
- Confirmar solicitud.
- Cancelar solicitud.
- Revisar movimientos.

### Administrador

- Revisar resumen general.
- Filtrar usuarios por rol y estado.
- Activar o desactivar usuarios.
- Convertir usuario cliente a vendedor.
- Convertir vendedor a administrador.
- Configurar modulos Octal, Decimal y Hexadecimal.
- Generar eventos proximos.
- Revisar solicitudes globales.
- Revisar movimientos globales.
- Revisar estadisticas.

---

## 18. Consideraciones tecnicas

- Los archivos JSON funcionan como datos iniciales.
- localStorage funciona como almacenamiento temporal de cambios.
- Los cambios no modifican archivos fisicos.
- Si una prueba no refleja cambios recientes, se debe limpiar localStorage.
- El proyecto debe ejecutarse con Live Server para que `fetch()` cargue correctamente los JSON.
- El sistema esta separado por modulos JavaScript para evitar mezclar responsabilidades.
- El proyecto es demostrativo y academico.

---

## 19. Limitaciones

- Las contrasenas estan en texto plano dentro del JSON porque es una demo academica.
- No existe control real de seguridad.
- No existe backend que valide transacciones.
- No existe auditoria real en servidor.
- No existe sistema legal de sorteo real.
- No existe modificacion persistente fuera del navegador.
- El dinero real y virtual son valores simulados.

---

## 20. Posibles mejoras futuras

- Implementar backend con Django, Node.js u otra tecnologia.
- Migrar los datos JSON a una base de datos real.
- Implementar autenticacion segura.
- Usar roles y permisos en servidor.
- Crear API REST para usuarios, sorteos, boletos, wallets y solicitudes.
- Agregar panel de auditoria real.
- Agregar aplicacion movil que consuma las APIs.
- Implementar generacion real de resultados de sorteo.
- Agregar pruebas unitarias y pruebas de integracion.
- Agregar despliegue en servidor.

---

## 21. Autor

**Desarrollado por:** Cristhian Herrera Nieto  
**Correo:** Criaherr@espol.edu.ec  
**Proyecto academico:** ESPOL - 2026  
