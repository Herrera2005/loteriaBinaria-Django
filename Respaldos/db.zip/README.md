# Taller #3 — Lotería Binaria con Django

Proyecto académico monolítico con templates Django, Bootstrap 5.3 y cinco apps:
`accounts`, `core`, `finance`, `vendors` y `lottery`.

## Estado vigente

La implementación llega a **P-36E y reparación de auditoría integral de cierre**.
El árbol actual incluye:

- usuario personalizado, términos, login, roles y modo activo;
- CRUD administrativos de usuarios, vendedores, productos y eventos;
- wallets REAL/VIRTUAL, movimientos y operaciones simuladas;
- solicitudes Cliente–Vendedor;
- compra de boletos, resultados, premios y reembolsos;
- series automáticas limitadas o sin límite;
- resultados manuales o automáticos;
- observabilidad mediante `DrawEventSeries.last_synced_at`;
- protección de históricos, idempotencia y servicios transaccionales;
- 436 métodos de prueba inventariados y 444 casos ejecutados por Django en el árbol reparado.

Los documentos antiguos P-27/P-28 se conservan únicamente en
`docs/historico/p27_p28/`. No describen el estado ejecutable vigente.

## Bases de datos

- **Fase 1:** SQLite.
- **Fase 2:** MySQL con `utf8mb4` y modo estricto.
- PostgreSQL no forma parte de este taller.

La migración más reciente es:

```text
lottery.0011_portable_series_sequence_unique
```

No se editan migraciones ya aplicadas.

## Instalación PowerShell

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
Copy-Item .env.example .env
python manage.py migrate
python manage.py seed_baseline
python manage.py seed_demo
python manage.py runserver
```

Configure una contraseña demo local antes de ejecutar `seed_demo`:

```powershell
$env:DJANGO_DEMO_PASSWORD = "UnaClaveLocalSegura"
```

`.env`, `.venv`, bases locales, `staticfiles`, logs y bytecode no pertenecen al
ZIP de entrega.

## Verificación integral SQLite

```powershell
.\scripts\verify.ps1
```

La puerta ejecuta:

1. verificación del manifiesto;
2. auditoría estática de cierre;
3. `manage.py check`;
4. `makemigrations --check --dry-run`;
5. migración limpia;
6. seeds y comandos repetidos dos veces;
7. smoke test de `runserver`;
8. suite completa;
9. static;
10. `check --deploy` con configuración segura temporal.

Equivalente Bash:

```bash
./scripts/verify.sh
```

## Tareas temporales

Estas tareas son idempotentes y deben programarse desde el hosting, sin Celery:

```powershell
python manage.py process_expired_requests
python manage.py sync_lottery_event_states
python manage.py process_lottery_schedules
```

`process_lottery_schedules` devuelve un código de error cuando alguna serie o
resultado automático falla. Cada serie se procesa en su propia transacción, por
lo que una serie inválida no revierte las series válidas.

Las páginas GET no sincronizan ni escriben estados. Las transiciones se realizan
mediante comandos o acciones POST autorizadas.

## Validación MySQL

Primero cree una base MySQL de prueba vacía e instale:

```powershell
python -m pip install -r requirements-mysql.txt
$env:DATABASE_URL = "mysql://usuario:clave@127.0.0.1:3306/loteria_taller3_test"
.\scripts\verify_mysql.ps1
```

No se considera aprobada la fase MySQL hasta ejecutar esa puerta en un servidor
MySQL real.

## Documentación vigente

- `docs/MATRIZ_TRAZABILIDAD_FASE_ACTUAL.md`
- `docs/INVENTARIO_FINAL.md`
- `docs/RESULTADO_AUDITORIA_FINAL.md`
- `docs/REPARACION_HALLAZGOS_CIERRE.md`
- `docs/PLAN_SIGUIENTE_TRABAJO.md`

Los cinco documentos canónicos originales permanecen sin alteraciones en
`docs/referencias/`.
