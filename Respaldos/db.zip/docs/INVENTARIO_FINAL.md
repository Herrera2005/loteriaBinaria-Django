# Inventario vigente del proyecto

## Aplicación

- `apps/accounts/`: identidad, términos, autenticación, roles y modo activo.
- `apps/core/`: landing, dashboards, auditoría y utilidades transversales.
- `apps/finance/`: wallets, movimientos y operaciones simuladas.
- `apps/vendors/`: perfiles y solicitudes Cliente–Vendedor.
- `apps/lottery/`: productos, eventos, boletos, resultados y series.

## Migraciones

La secuencia de `apps/lottery/migrations/` llega a:

- `0010_draweventseries_last_synced_at.py`
- `0011_portable_series_sequence_unique.py`

La migración `0011` sustituye la constraint parcial por una unicidad portable
`(series, series_sequence)` sin reescribir `0007`.

## Comandos

- `seed_baseline`
- `seed_demo`
- `backfill_wallets`
- `process_expired_requests`
- `sync_lottery_event_states`
- `process_lottery_schedules`

## Verificación

- `scripts/audit_project.py`
- `scripts/manifest_project.py`
- `scripts/verify.ps1`
- `scripts/verify.sh`
- `scripts/verify_mysql.ps1`
- `scripts/verify_mysql.sh`
- `scripts/smoke_runserver.py`

## Interfaz

Templates Django y Bootstrap 5.3. Los cuatro templates financieros sustituidos
por pantallas unificadas fueron retirados porque no tenían consumidores en
URLs, vistas, includes, admin, comandos ni pruebas.

## Archivos excluidos de la entrega

- `.venv/`
- `.env`
- `db.sqlite3` y otras bases locales
- `__pycache__/`, `.pyc`, `.pyo`
- `staticfiles/`
- logs y respaldos temporales

La fuente reproducible son requisitos, migraciones y seeds.
