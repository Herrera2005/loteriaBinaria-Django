# Matriz de trazabilidad vigente — P-36E y cierre

| Área | Implementación vigente | Control principal | Evidencia |
|---|---|---|---|
| Identidad | usuario personalizado, términos y perfil | modelos, formularios y servicios | `apps/accounts/tests/` |
| Roles y modos | CLIENTE, VENDEDOR, ADMINISTRADOR | sesión validada y políticas backend | pruebas de permisos y vistas |
| Finanzas | wallets, movimientos, recargas, conversiones, transferencias, retiros e inventario | minor units, `operation_id`, locks e históricos | `apps/finance/tests/` |
| Solicitudes | creación, reserva, asignación, liberación, confirmación y expiración | transacciones y bloqueos | `apps/vendors/tests/` |
| Productos | oficiales y personalizados | configuración estructural protegida | pruebas de modelos, formularios y CRUD |
| Eventos | CRUD, transiciones, cancelación y cierre temporal | acciones POST, historial inmutable | pruebas de workflow y cierre |
| Boletos | compra directa e idempotente | modo CLIENTE, wallet bloqueada y unicidad | `test_ticket_purchase.py` |
| Resultados | manuales y automáticos | resultado único, liquidación y premio idempotente | `test_result_publication.py`, `test_automatic_results.py` |
| Series | pausa, archivo lógico, límites, edición futura y generación automática | lock por serie y unicidad portable | `test_event_series.py`, `test_closure_repairs.py` |
| Observabilidad | `last_synced_at` registra todo intento real de una serie existente | transacción externa del sello y savepoint de negocio | pruebas de éxito, cero eventos y fallo |
| Auditoría | append-only | manager, modelo y admin read-only | pruebas de `AuditEvent` |
| Estado de eventos | sincronización temporal | management command o POST; nunca GET | regresiones de cierre |
| SQLite | fase inicial reproducible | `scripts/verify.ps1` / `.sh` | migración limpia y suite completa |
| MySQL | segunda fase preparada | constraint portable y scripts dedicados | ejecución real todavía obligatoria |
| Entrega | paquete sin entorno, base ni secretos | auditor y manifiesto SHA-256 | `scripts/audit_project.py` |

## Estado

- SQLite: implementación y pruebas disponibles.
- MySQL: configuración y puerta preparadas; la aprobación requiere servidor real.
- Documentos P-27/P-28: históricos en `docs/historico/p27_p28/`.
