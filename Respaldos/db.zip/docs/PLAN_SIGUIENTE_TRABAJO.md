# Siguiente trabajo permitido

No se deben añadir nuevas funciones de negocio antes de cerrar estas puertas:

1. ejecutar `scripts/verify.ps1` en una copia limpia;
2. crear una base MySQL de prueba vacía;
3. ejecutar `scripts/verify_mysql.ps1`;
4. comprobar concurrencia real en compras, solicitudes, resultados y series;
5. generar el ZIP definitivo;
6. descomprimirlo en otra carpeta y repetir auditoría y manifiesto.

La siguiente fase es exclusivamente validación MySQL y entrega. No corresponde
crear PostgreSQL, API REST, Celery, Redis ni microservicios.
